//#16.0.1.0 WDChamp.js
//VersionVI: 30A160057k
// Le seul support technique disponible pour cette librairie est
// accessible a travers le service "Assistance Directe".

if (!window["WDTableauChamps"])
{
	// Classe utilitaire de gestion d'un tableau de champ indice par nom
	WDTableauChamps = function WDTableauChamps_()
	{
		// Tableau fils qui contient les champs
		// La classe n'herite pas de Array (c'est +/- inutile en plus), car sinon cela interdirai toute variable locale
		this.m_tabChamps = [];
	};

	// Nombre de champ
	WDTableauChamps.prototype.nGetNbChamps = function nGetNbChamps()
	{
		return this.m_tabChamps.length;
	};

	// Declare un champ
	WDTableauChamps.prototype.DeclareChamp = function DeclareChamp(oChamp)
	{
		this.m_tabChamps[oChamp.m_sAliasChamp] = oChamp;
	};

	// Recupere un champ
	WDTableauChamps.prototype.oGetChamp = function oGetChamp(sChamp)
	{
		return this.m_tabChamps[sChamp];
	};

	// Appele une methode sur tous les camps
	WDTableauChamps.prototype._AppelMethode = function _AppelMethode(sFonction, tabParam, oExclus)
	{
		for (var sChamp in this.m_tabChamps)
		{
			// Recupere le champ et teste sa validite
			var oChamp = this.m_tabChamps[sChamp];
			if (oChamp && (oChamp != oExclus))
			{
				// Applique alors la methode sur le champ
				oChamp[sFonction].apply(oChamp, tabParam);
			}
		}
	};
	WDTableauChamps.prototype._AppelMethodePtr = function _AppelMethodePtr(fFonction, tabParam, oExclus)
	{
		for (var sChamp in this.m_tabChamps)
		{
			// Recupere le champ et teste sa validite
			var oChamp = this.m_tabChamps[sChamp];
			if (oChamp && (oChamp != oExclus))
			{
				// Applique alors la methode sur le champ
				fFonction.apply(oChamp, tabParam);
			}
		}
	};

	// Appele une fonction booleenne sur tous les camps et utilise un operateur pour traiter le resultat
	// fFonction : fonction de prototype Resultat = f(Ancien resultat, resultat nouvel appel)
	// oResultat : resultat initial (pour le premier appel ou s'il n'y a pas de champs)
	WDTableauChamps.prototype._oAppelFonction = function _oAppelFonction(sFonction, tabParam, fFonction, oResultat)
	{
		for (var sChamp in this.m_tabChamps)
		{
			// Recupere le champ et teste sa validite
			var oChamp = this.m_tabChamps[sChamp];
			if (oChamp && oChamp[sFonction])
			{
				// Applique alors la methode sur le champ
				oResultat = fFonction(oResultat, oChamp[sFonction].apply(oChamp, tabParam));
			}
		}
		return oResultat
	};

	// Appele une methode sur un champ dont on connait le nom
	// tabParam : tableau des parametres
	WDTableauChamps.prototype._AppelMethodeChamp = function _AppelMethodeChamp(sAlias, sFonction, tabParam)
	{
		var oChamp = this.oGetChamp(sAlias);
		if (oChamp)
		{
			oChamp[sFonction].apply(oChamp, tabParam);
		}
	};
	WDTableauChamps.prototype._AppelMethodeChampPtr = function _AppelMethodeChampPtr(sAlias, fFonction, tabParam)
	{
		var oChamp = this.oGetChamp(sAlias);
		if (oChamp)
		{
			fFonction.apply(oChamp, tabParam);
		}
	};
	WDTableauChamps.prototype._oAppelFonctionChamp = function _oAppelFonctionChamp(sAlias, sFonction, tabParam)
	{
		var oChamp = this.oGetChamp(sAlias);
		if (oChamp)
		{
			return oChamp[sFonction].apply(oChamp, tabParam);
		}
		return undefined;
	};
}

if (!window["WDChamp"])
{
	// Classe de base de manipulation des champs de WebDev
	// - Gestion de l'appartenace a :
	//	- Une ZR
	//	- Un onglet
	// - Gestion des evenements AJAX (affectation etc)
	WDChamp = function WDChamp_(sAliasChamp, sAliasZR, sAliasAttribut)
	{
		// Si on est pas dans l'init d'un protoype
		if (sAliasChamp)
		{
			// L'alias du champ
			this.m_sAliasChamp = sAliasChamp;
			// La ZR eventuelle qui contient le champ si la propriete ..Valeur est liee a un attribut (sAliasChamp est alors l'alias de cet attribut)
			if (sAliasZR)
			{
				this.m_sAliasZR = sAliasZR;
				this.m_sAliasAttribut = sAliasAttribut;
			}

			// Tableau des PCodes du champ
			this.m_tabPCodes = [];

			// Le champ est actif
			this.m_eEtat = this.ms_eEtatActif;
		}
	};

	// Tableau global des champs JS de la page
	WDChamp.prototype.ms_tabChamps = new WDTableauChamps();
	// Tableau global des ZRs/Tables de la page (pour pouvoir les manipulers des les inits des champs
	WDChamp.prototype.ms_tabTablesZRs = new WDTableauChamps();
	// Numero des PCodes navigateurs
	WDChamp.prototype.ms_nEventNavBlur = 10;
	WDChamp.prototype.ms_nEventNavChange = 11;
	WDChamp.prototype.ms_nEventNavFocus = 12;
	WDChamp.prototype.ms_nEventNavSelectLigne = 20;
	WDChamp.prototype.ms_nEventNavModifSimple = 21;
	WDChamp.prototype.ms_nEventNavAffichageMois = 28;
	WDChamp.prototype.ms_nEventNavSelectionJour = 29;
	WDChamp.prototype.ms_nEventNavUploadSelection = 30;
	WDChamp.prototype.ms_nEventNavUploadAvancement = 31;
	WDChamp.prototype.ms_nEventNavAgendaRdvSelection = 32;
	WDChamp.prototype.ms_nEventNavAgendaRdvDeplacement = 33;
	WDChamp.prototype.ms_nEventNavAgendaRdvRedim = 34;
	WDChamp.prototype.ms_nEventNavAgendaPeriodeSelect = 35;
	WDChamp.prototype.ms_nEventNavAgendaRdvSupprime = 36;
	WDChamp.prototype.ms_nEventNavAgendaRdvAjoute = 37;
	WDChamp.prototype.ms_nEventNavAgendaRdvEdition = 38;
	WDChamp.prototype.ms_nEventNavAgendaRdvModifTitre = 39;
	WDChamp.prototype.ms_nEventNavPlanningRdvDeplacementRessource = 40;
	WDChamp.prototype.ms_nEventNavCalendrierChangementMois = 41;
	WDChamp.prototype.ms_nEventNavAgendaPeriodeAffiche = 45;
	// Fonction vide pour la gestion des PCodes
	WDChamp.prototype.m_pfVide = function() { return true; }
	// Etats des champs.AppelMethode Les valeurs mappent sur les valeurs WL meme si visible n'est pas utilise
	WDChamp.prototype.ms_eEtatActif = 0;
	WDChamp.prototype.ms_eEtatLectureSeule = 1;
	WDChamp.prototype.ms_eEtatGrise = 4;

	WDChamp.prototype.ID_SEPARATEUR = "_";
	WDChamp.prototype.ms_sSuffixeHote = "_HTE";

	// Nombre d'animation (compteur statique pour les champs sans animations
	WDChamp.prototype.m_nNbAnimationsActives = 0;

	// Initialisation
	WDChamp.prototype.Init = function Init()
	{
		// Si c'est l'init du premier champ
		this._vInitInitiale();

		// Si le champ est dans une ZR : notifie l'objet ZR de sa presence
		// Note : On ne peut pas faire cette declaration dans le constructeur car l'existence de l'objet de la ZR n'est pas garanti
		// En effet l'ordre actuel de creation des objets est : fils puis parent
		// Ce qui signifie que la liste comlete n'est pas complete avant la fin de tous les init. Sauf que l'init de la ZR est
		// alors pares celui de tous ces fils donc on peut considerer qu'il existe
		if (this.bGestionZR())
		{
			WDChamp.prototype.ms_tabTablesZRs._AppelMethodeChamp(this.m_sAliasZR, "DeclareChampFils", [this]);
		}

		// Se memorise comme champ dans le tableau global
		// Fait dans l'init et pas dans la construction, pour ne pas ajouter un champ invalide
		WDChamp.prototype.ms_tabChamps.DeclareChamp(this);

		// Trouve les divers elements : liaison avec le HTML
		this._vLiaisonHTML();
	};

	// Methode d'initialisation generale de la classe
	// Filtre et ne s'execute que lors de l'init du PREMIER champ
	WDChamp.prototype._vInitInitiale = function _vInitInitiale()
	{
		// Enregistre l'evenement onresize sur la fenetre
		var fOnResize = function(oEvent) { AppelMethode(WDChamp.prototype.ms_sOnResize, [oEvent ? oEvent : event], undefined) };
		HookOnXXX(window, "onresize", "resize", fOnResize);

		// Remplace les fonctions par les fonctions bIEQuirks si besoin
		if (bIEQuirks)
		{
			WDChamp.prototype._nGetOffsetWidth = WDChamp.prototype.__nGetOffsetWidthIEQuirks;
			WDChamp.prototype._nGetOffsetHeight = WDChamp.prototype.__nGetOffsetHeightIEQuirks;
		}
		else
		{
			WDChamp.prototype._nGetOffsetWidth = WDChamp.prototype.__nGetOffsetWidth;
			WDChamp.prototype._nGetOffsetHeight = WDChamp.prototype.__nGetOffsetHeight;
		}

		// S'auto efface pour ne plus etre appele
		WDChamp.prototype._vInitInitiale = WDChamp.prototype.m_pfVide;
	};

	// Methode STATIQUE : Recupere l'objet attache a un champ
	oGetObjetChamp = function oGetObjetChamp(sAlias)
	{
		return WDChamp.prototype.ms_tabChamps.oGetChamp(sAlias);
	};

	// Methode STATIQUE : Appele une methode sur tout les champs sauf le champ passe en parametre
	// Il est possible de ne pas passer le parametre
	// tabParam : tableau des parametres
	AppelMethode = function AppelMethode(sFonction, tabParam, oExclus)
	{
		WDChamp.prototype.ms_tabChamps._AppelMethode(sFonction, tabParam, oExclus);
	};
	oAppelFonction = function oAppelFonction(sFonction, tabParam, fFonction, oResultat)
	{
		return WDChamp.prototype.ms_tabChamps._oAppelFonction(sFonction, tabParam, fFonction, oResultat);
	};

	// Methode STATIQUE : Appele une methode sur un champ dont on connait le nom
	// tabParam : tableau des parametres
	AppelMethodeChamp = function AppelMethodeChamp(sAlias, sFonction, tabParam)
	{
		WDChamp.prototype.ms_tabChamps._AppelMethodeChamp(sAlias, sFonction, tabParam);
	};
	AppelMethodeChampPtr = function AppelMethodeChampPtr(sAlias, fFonction, tabParam)
	{
		WDChamp.prototype.ms_tabChamps._AppelMethodeChampPtr(sAlias, fFonction, tabParam);
	};
	oAppelFonctionChamp = function oAppelFonctionChamp(sAlias, sFonction, tabParam)
	{
		return WDChamp.prototype.ms_tabChamps._oAppelFonctionChamp(sAlias, sFonction, tabParam);
	};
	// Utile car appele depuis le .swf du champ video
	AppelFonctionChamp = oAppelFonctionChamp;

	// Appele une methode sur tout les champs sauf sur le champ courant
	// tabParam : tableau des parametres
	WDChamp.prototype.AppelMethodeAutres = function AppelMethodeAutres(sFonction, tabParam)
	{
		AppelMethode(sFonction, tabParam, this);
	};
	WDChamp.prototype.AppelMethodeAutresPtr = function AppelMethodeAutresPtr(fFonction, tabParam)
	{
		this.ms_tabChamps._AppelMethodePtr(fFonction, tabParam, this);
	};

	//////////////////////////////////////////////////////////////////////////
	// Gestion des PCodes

	// Declare un PCode navigateur au champ
	WDChamp.prototype.DeclarePCode = function DeclarePCode(ePCodeNav, pfFonction)
	{
		this.m_tabPCodes[ePCodeNav] = pfFonction;
	};

	// Recupere un PCode navigateur du champ
	// Cette fonction n'appele pas le PCode : il n'est pas possible de transformer simplement les parametres variables et en supprimant un
	// Mais cette fonction retourne une fonction vide qui permet de ne rien faire planter
	WDChamp.prototype.RecuperePCode = function RecuperePCode(ePCodeNav)
	{
		var pfFonction = this.m_tabPCodes[ePCodeNav];
		if (pfFonction)
		{
			return pfFonction;
		}
		return this.m_pfVide;
	};

	// Cree un Timeout sur le champ courant et renvoi l'id du Timeout
	// La fonction est en fait une fonction '...'. Elle concatene les parametre a partir du troisieme comme arguments de la procedure appelee
	// Seule les parametres de type chaines sont encadre par des " MAIS NE sont pas escapes
	WDChamp.prototype.nSetTimeout = function nSetTimeout(sFonction, nDuree)
	{
		var oThis = this;
		var sFonctionLocal = sFonction;
		var tabArguments = this.__tabArgumentsVersTableau(arguments, 2);
		return setTimeout(function() { oThis[sFonctionLocal].apply(oThis, tabArguments); }, nDuree);
	};

	// Cree un timer sur le champ courant et renvoi l'id du timer
	// La fonction est en fait une fonction '...'. Elle concatene les parametre a partir du troisieme comme arguments de la procedure appelee
	// Seule les parametres de type chaines sont encadre par des " MAIS NE sont pas escapes
	WDChamp.prototype.SetInterval = function SetInterval(sFonction, fFonction, nDuree)
	{
		this[this.sNomVariableTimeXXX(sFonction)] = setInterval(fFonction, nDuree);
	};


	// Recupere le tableau des arguments d'une fonction avec conversion en chaine
	WDChamp.prototype.__tabArgumentsVersTableau = function __tabArgumentsVersTableau(tabParam, nPremier)
	{
		// Construit le tableau des parametres
		var tabArguments = [];
		var i;
		var nLimiteI = tabParam.length;
		// Commence au troisieme argument
		for (i = nPremier; i < nLimiteI; i++)
		{
			// Ajoute l'argument
			tabArguments.push(tabParam[i]);
		}

		return tabArguments;
	};

	// Gestion de setTimeout avec appel unique (un seul appel en attente)
	WDChamp.prototype.nSetTimeoutUnique = function nSetTimeoutUnique(sFonction, nDuree)
	{
		// Supprime le Timeout de meme nom s'il existe
		this.AnnuleTimeXXX(sFonction, false);

		// Et cree le nouveau
		var nTimeout = this.nSetTimeout("TimeoutUnique", nDuree, sFonction, this.__tabArgumentsVersTableau(arguments, 2));
		this[this.sNomVariableTimeXXX(sFonction)] = nTimeout;
		return nTimeout;
	};

	// Callback pour la gestion des timeouts uniques
	WDChamp.prototype.TimeoutUnique = function TimeoutUnique(sFonction, tabParam)
	{
		// Supprime le timeout
		this.SupprimeTimeout(sFonction);
		// Appel la fonction
		this[sFonction].apply(this, tabParam);
	};

	// Recupere un timer
	WDChamp.prototype.bGetTimeXXXExiste = function bGetTimeXXXExiste(sFonction)
	{
		// Si le Timeout existe
		return (this[this.sNomVariableTimeXXX(sFonction)] !== undefined);
	};

	// Annule un Timeout
	WDChamp.prototype.AnnuleTimeXXX = function AnnuleTimeXXX(sFonction, bInterval)
	{
		// Si le Timeout existe
		var sVarTimeXXX = this.sNomVariableTimeXXX(sFonction);
		var nTimeXXX = this[sVarTimeXXX];
		if (nTimeXXX !== undefined)
		{
			// Le libere
			if (bInterval)
			{
				clearInterval(nTimeXXX);
			}
			else
			{
				clearTimeout(nTimeXXX);
			}
			// Et supprime la variable
			delete this[sVarTimeXXX];
		}
	};

	// Supprime la reference a un Timeout
	WDChamp.prototype.SupprimeTimeout = function SupprimeTimeout(sFonction)
	{
		// Si le Timeout existe
		var sVarTimeout = this.sNomVariableTimeXXX(sFonction);
		if (this[sVarTimeout] !== undefined)
		{
			delete this[sVarTimeout];
		}
	};

	// Calcule le nom de la variable memorisant le Timeout
	WDChamp.prototype.sNomVariableTimeXXX = function sNomVariableTimeXXX(sFonction)
	{
		return "m_nTimeXXX_" + sFonction;
	};

	WDChamp.prototype.nGetVariableTimeXXX = function nGetVariableTimeXXX(sFonction)
	{
		return this[this.sNomVariableTimeXXX(sFonction)];
	};

	//////////////////////////////////////////////////////////////////////////
	// Etat du champ

	// Etats des champs. Les valeurs mappent sur les valeurs WL meme si visible n'est pas utilise
	WDChamp.prototype.SetEtat = function SetEtat(eEtat)
	{
		this.m_eEtat = eEtat;
	};
	WDChamp.prototype.eGetEtat = function eGetEtat()
	{
		return this.m_eEtat;
	};

	// Methode predefinies nommee
	// - Tous les champs : affectation du contenu HTML pour l'AJAX
	WDChamp.prototype.PreAffecteHTML = function PreAffecteHTML(bDepuisAJAX) { this._vPreAffecteHTML.apply(this, arguments); };
	WDChamp.prototype._vPreAffecteHTML = WDChamp.prototype.m_pfVide;
	WDChamp.prototype.PostAffecteHTML = function PostAffecteHTML(bDepuisAJAX) { this._vPostAffecteHTML.apply(this, arguments); };
	WDChamp.prototype._vPostAffecteHTML = WDChamp.prototype.m_pfVide;
	// - Tous les champs : Notifie le champ le conteneur xxx est affiche via un .display = "block"
	WDChamp.prototype.OnDisplay = function OnDisplay(oElementRacine) { };
	WDChamp.prototype.ms_sOnDisplay = "OnDisplay";
	// - Tous les champs : Notifie le champ que la fenetre est redimentionnee
	WDChamp.prototype.OnResize = function OnResize(oEvent) { };
	WDChamp.prototype.ms_sOnResize = "OnResize";
	// - Tous les champs : affectation de la valeur
	WDChamp.prototype.SetValeur = function SetValeur(oEvent, sValeur, oChamp) { return sValeur; };
	WDChamp.prototype.ms_sSetValeur = "SetValeur";
	WDChamp.prototype.GetValeur = function GetValeur(oEvent, sValeur, oChamp) { return sValeur; };
	WDChamp.prototype.ms_sGetValeur = "GetValeur";
	// - Affectation des parametres du champ (pas besoin de apply ici car on transforme les parametres)
	WDChamp.prototype.DeduitParam = function DeduitParam(sParametres) { this._vDeduitParam(eval("(" + sParametres + ")")); };
	WDChamp.prototype._vDeduitParam = WDChamp.prototype.m_pfVide;
	// - Ecriture des parametres du champ dans le champ formulaire associe
	// => N'affecte rien pour le cas des valeurs vide (car des champs qui font des MAJs en direct)
	WDChamp.prototype.ConstruitParam = function ConstruitParam()
	{
		var sParam = this._vsConstruitParam.apply(this, arguments);
		if (sParam.length > 0)
		{
			this._vSetValeurChampFormulaire(sParam);
		}
	};
	// Recupere les parametres du champs (accepte des parametres variables)
	WDChamp.prototype._vsConstruitParam = function _vsConstruitParam() { return ""; };
	// - Champ table : rafraichissement du contenu
	WDChamp.prototype.Refresh = function Refresh(nReset, nNouveauDebut, sCleNouveauDebut) { this._vRefresh.apply(this, arguments) };
	WDChamp.prototype._vRefresh = WDChamp.prototype.m_pfVide;
	// - Champ avec "barre" (graphe/saisie riche)
	WDChamp.prototype.MasqueBarre = function MasqueBarre(oEvent) { this._vMasqueBarre.apply(this, arguments); };
	WDChamp.prototype._vMasqueBarre = WDChamp.prototype.m_pfVide;
	// - Tous les champs : animation
	WDChamp.prototype.AnimationDebut = function AnimationDebut(oAnimation) { this._vAnimationDebut.apply(this, arguments); };
	WDChamp.prototype._vAnimationDebut = function _vAnimationDebut(oAnimation) { this.m_nNbAnimationsActives++; };
	WDChamp.prototype.AnimationFin = function AnimationFin(oAnimation) { this._vAnimationFin.apply(this, arguments); };
	WDChamp.prototype._vAnimationFin = function _vAnimationFin(oAnimation) { this.m_nNbAnimationsActives--; };

	// Methode appele directement
	// - Champ dans une ZR : notifie le champ de l'affichage/suppression de la ligne
	WDChamp.prototype.OnLigneZRAffiche = function OnLigneZRAffiche(nLigneAbsolueBase1, bSelectionne) { this._vOnLigneZRAffiche.apply(this, arguments); };
	WDChamp.prototype._vOnLigneZRAffiche = WDChamp.prototype.m_pfVide;
	WDChamp.prototype.OnLigneZRMasque = function OnLigneZRMasque(nLigneAbsolueBase1, bSelectionne, oEvent) { this._vOnLigneZRMasque.apply(this, arguments); };
	WDChamp.prototype._vOnLigneZRMasque = WDChamp.prototype.m_pfVide;

	// - Tous les champs : ..Xxx generique
	WDChamp.prototype.XML_CHAMP_PROP_NUM_SOUSELEMENT = -2;	// Objet
	WDChamp.prototype.XML_CHAMP_PROP_NUM_CONTENU = -1;		// Chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEUR = 1;		// Chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_LIBELLE = 3;		// Chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_HAUTEUR = 5;		// Entier
	WDChamp.prototype.XML_CHAMP_PROP_NUM_LARGEUR = 6;		// Entier
	WDChamp.prototype.XML_CHAMP_PROP_NUM_COULEUR = 10;		// Formate en chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_COULEURFOND = 11;	// Formate en chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_ETAT = 12;			// Balise XML
	WDChamp.prototype.XML_CHAMP_PROP_NUM_OCCURRENCE = 14;	// Entier
	WDChamp.prototype.XML_CHAMP_PROP_NUM_VISIBLE = 18;		// Valeur formate en chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_VALEURAFFICHEE = 21; // Chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_IMAGE = 34;		// Chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_URL = 38;			// Chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_BULLE = 39;		// Chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_X = 41;			// Chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_Y = 42;			// Chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_CURSEURSOURIS = 43; // Chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICEGRAS = 47;	// Entier
	WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICEITALIQUE = 48; // Booleen formate en chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICENOM = 49;	// Chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICESOULIGNE = 50; // Booleen formate en chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICETAILLE = 51;	// Chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_OPACITE = 52;		// Entier
	WDChamp.prototype.XML_CHAMP_PROP_NUM_CADRAGEH = 53;		// Chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_CADRAGEV = 54;		// Chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_SELECTIONNEE = 55;	// Booleen formate en chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_INDICATION = 58;	// Chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_BOUTONCALENDRIER = 66; // Booleen formate en chaine
	WDChamp.prototype.XML_CHAMP_PROP_NUM_ENROULE = 72;		// Booleen formate en chaine
	WDChamp.prototype.GetProp = function GetProp(eProp, oEvent, oValeur, oChamp)
	{
		// Traite le cas de ..Valeur pour faire un rebond sur GetValeur
		switch (eProp)
		{
			case this.XML_CHAMP_PROP_NUM_SOUSELEMENT:
				return null;
			case this.XML_CHAMP_PROP_NUM_VALEUR:
				return this.GetValeur(oEvent, oValeur, oChamp);
			default:
				return oValeur;
		}
	};
	WDChamp.prototype.ms_sGetProp = "GetProp";
	WDChamp.prototype.SetProp = function SetProp(eProp, oEvent, oValeur, oChamp)
	{
		// Traite le cas de ..Valeur pour faire un rebond sur SetValeur
		switch (eProp)
		{
			case this.XML_CHAMP_PROP_NUM_VALEUR:
				return this.SetValeur(oEvent, oValeur, oChamp);
			default:
				// Retourne inchangee la valeur de la propriete
				return oValeur;
		}
	};
	WDChamp.prototype.ms_sSetProp = "SetProp";

	//////////////////////////////////////////////////////////////////////////
	// Gestion des ZRs

	// Indique si on est dans une ZR
	WDChamp.prototype.bGestionZR = function bGestionZR()
	{
		return ((this.m_sAliasZR) ? true : false);
	};
	// Indique si on est dans une ZR AJAX et si c'est le cas retourne l'objet de la ZR (sinon retourne undefined)
	WDChamp.prototype.oGetZRAjax = function oGetZRAjax()
	{
		return (this.bGestionZR() ? WDChamp.prototype.ms_tabTablesZRs.oGetChamp(this.m_sAliasZR) : undefined);
	};

	// Retourne le premier element d'une ZR (le champ DOIT etre dans une ZR)
	WDChamp.prototype.nGetZRValeur = function nGetZRValeur()
	{
		return parseInt(document.getElementsByName(this.m_sAliasZR)[0].value, 10);
	};
	WDChamp.prototype.SetZRValeur = function SetZRValeur(oEvent, nLigneAbsolueBase1)
	{
		// Si on est dans une ZR AJAX, notifie le champ
		var oZRAjax = this.oGetZRAjax();
		if (oZRAjax)
		{
			oZRAjax.OnSelectLigne(nLigneAbsolueBase1 - oZRAjax.m_nDebut - 1, 0, oEvent);
		}
		else
		{
			// Sinon ecrit directement dans le champ formulaire
			document.getElementsByName(this.m_sAliasZR)[0].value = nLigneAbsolueBase1;
		}
	};
	WDChamp.prototype.nGetZRDebut = function nGetZRDebut()
	{
		return parseInt(document.getElementsByName(this.m_sAliasZR + "_DEB")[0].value, 10);
	};
	WDChamp.prototype.nGetZROccurrence = function nGetZROccurrence()
	{
		return parseInt(document.getElementsByName("_" + this.m_sAliasZR + "_OCC")[0].value, 10);
	};

	//////////////////////////////////////////////////////////////////////////
	// Methodes "virtuelles"

	// Trouve les divers elements : liaison avec le HTML
	WDChamp.prototype._vLiaisonHTML = function _vLiaisonHTML()
	{
		// Trouve le champ formulaire s'il existe
		var oChampFormulaire = this._voGetChampFormulaire();
		if (oChampFormulaire)
		{
			this.m_oChampFormulaire = oChampFormulaire;
		}
	};

	// Trouve le champ formulaire
	WDChamp.prototype._voGetChampFormulaire = function _voGetChampFormulaire()
	{
		return this.oGetElementByName(document, "");
	};

	// Construit un parametre pour un objet (encode au format des parametres d'URL + encodage des ,)
	WDChamp.prototype._sConstruitParamObjet = function _sConstruitParamObjet(oObjet)
	{
		var tabParam = [];
		for (var sCle in oObjet)
		{
			var sValeur = oObjet[sCle];
			// Selon le type de la valeur
			switch ((typeof sValeur).toLowerCase())
			{
			case "boolean":
				sValeur = sValeur ? "1" : "0";
				break;
			case "string":
			case "number":
			default:
				sValeur = clWDEncode.sEncodePOST(sValeur);
				break;
			case "object":
				// Accepte les dates
				if ("function" == typeof sValeur.getTime)
				{
					sValeur = sValeur.getTime() + "";
					break;
				}
			case "function":
			case "undefined":
				continue;
			}
			// sCle ne contient normalement pas de ",", "=", "&"
			tabParam.push(sCle + "=" + sValeur.replace(/\,/g, "%2C"));
		}

		return tabParam.join("&");
	};

	// Lit la valeur si elle existe (sinon "")
	WDChamp.prototype._vsGetValeurChampFormulaire = function _vsGetValeurChampFormulaire()
	{
		return this.m_oChampFormulaire ? this.m_oChampFormulaire.value : "";
	};

	// Ecrit la valeur du champ formulaire si il existe
	WDChamp.prototype._vSetValeurChampFormulaire = function _vSetValeurChampFormulaire(sValeur)
	{
		if (this.m_oChampFormulaire)
		{
			this.m_oChampFormulaire.value = sValeur;
		}
	};

	//////////////////////////////////////////////////////////////////////////
	// Gestion des champs

	// Retourne le nom d'un objet en fonction de son suffixe et du nom du champ
	WDChamp.prototype.sGetNomElement = function sGetNomElement(sSuffixe)
	{
		return this.m_sAliasChamp + sSuffixe;
	};
	// Retourne un objet en fonction de son suffixe et du nom du champ
	WDChamp.prototype.oGetElementById = function oGetElementById(oDocument, sSuffixe)
	{
		return oDocument.getElementById(this.sGetNomElement(sSuffixe));
	};
	WDChamp.prototype.oGetElementByName = function oGetElementByName(oElement, sSuffixe)
	{
		return oElement.getElementsByName(this.sGetNomElement(sSuffixe))[0];
	};

	// Construit l'id d'un element par concatenation des suffixes
	WDChamp.prototype.sGetSuffixeIDElement = function sGetSuffixeIDElement()
	{
		// On doit avoir au moins un parametre
		var tabSuffixe = [];
		var i;
		var nLimiteI = arguments.length;
		for (i = 0; i < nLimiteI; i++)
		{
			tabSuffixe.push(arguments[i]);
		}
		return this.ID_SEPARATEUR + tabSuffixe.join(this.ID_SEPARATEUR);
	};

	// Recupere un element en construisant son identifiant
	// Fonction en '...' : accepte un nombre variable d'arguments
	WDChamp.prototype.oGetIDElement = function oGetIDElement()
	{
		return this.oGetElementById(document, this.sGetSuffixeIDElement.apply(this, arguments));
	};

	//////////////////////////////////////////////////////////////////////////
	// Gestion des champs dans les ZRs

	// Retourne le nom d'un objet en fonction de son suffixe, du nom du champ et de la presence d'une ZR
	WDChamp.prototype.sGetNomElementZR = function sGetNomElementZR(sSuffixe)
	{
		return this.sGetNomElementZRCalc(this.bGestionZR(), sSuffixe);
	};
	// Retourne le nom d'un objet en fonction de son suffixe, du nom du champ et de la presence d'une ZR selon le parametre
	WDChamp.prototype.sGetNomElementZRCalc = function sGetNomElementZRCalc(bDansZR, sSuffixe)
	{
		// Si on est dans une ZR
		if (bDansZR)
		{
			// Retourne _INDICEZR_ALIASCHAMP + suffixe
			return this.sGetNomElementZRIndice(this.nGetZRValeur(), sSuffixe);
		}
		else
		{
			// Pas dans une ZR : methode normale
			return this.sGetNomElement(sSuffixe);
		}
	};

	// Retourne le nom d'un objet en fonction de son suffixe, du nom du champ et de son indice dans la ZR
	WDChamp.prototype.sGetNomElementZRIndice = function sGetNomElementZRIndice(nIndice, sSuffixe)
	{
		// Retourne _INDICEZR_ALIASCHAMP + suffixe
		// Dans les ZR fichier avec rebond il faut tenir compte de this.nGetZRDebut() ?
		//	return "_" + (nIndice + this.nGetZRDebut() - 1) + "_" + this.m_sAliasAttribut + sSuffixe;
		return "_" + nIndice + "_" + this.m_sAliasAttribut + sSuffixe;
	};

	// Retourne un objet en fonction de son suffixe, du nom du champ et de la presence d'une ZR
	WDChamp.prototype.oGetElementByIdZR = function oGetElementByIdZR(oDocument, sSuffixe)
	{
		return this.oGetElementByIdZRCalc(this.bGestionZR(), oDocument, sSuffixe);
	};
	WDChamp.prototype.oGetElementByNameZR = function oGetElementByNameZR(oElement, sSuffixe)
	{
		return this.oGetElementByNameZRCalc(this.bGestionZR(), oElement, sSuffixe);
	};

	// Retourne un objet en fonction de son suffixe, du nom du champ et de la presence d'une ZR selon le parametre
	WDChamp.prototype.oGetElementByIdZRCalc = function oGetElementByIdZRCalc(bDansZR, oDocument, sSuffixe)
	{
		return oDocument.getElementById(this.sGetNomElementZRCalc(bDansZR, sSuffixe));
	};
	WDChamp.prototype.oGetElementByNameZRCalc = function oGetElementByNameZRCalc(bDansZR, oElement, sSuffixe)
	{
		return oElement.getElementsByName(this.sGetNomElementZRCalc(bDansZR, sSuffixe))[0];
	};

	// Retourne un objet en fonction de son suffixe, du nom du champ et de son indice dans la ZR
	WDChamp.prototype.oGetElementByIdZRIndice = function oGetElementByIdZRIndice(oDocument, nIndice, sSuffixe)
	{
		return oDocument.getElementById(this.sGetNomElementZRIndice(nIndice, sSuffixe));
	};
	WDChamp.prototype.oGetElementByNameZRIndice = function oGetElementByNameZRIndice(oElement, nIndice, sSuffixe)
	{
		return oElement.getElementsByName(this.sGetNomElementZRIndice(nIndice, sSuffixe))[0];
	};

	// Recupere un balise object ou embeb en fonction du navigateur
	WDChamp.prototype.oGetObjectEmbed = function oGetObjectEmbed(sNom, bAccepteObject)
	{
		var tabChamp = document.getElementsByName(sNom);
		// Uniquement sous IE (balise object manipule par IE, embed par FF)
		if (tabChamp && (tabChamp.length >= 1) && tabChamp[0] && clWDUtil.bBaliseEstTag(tabChamp[0], "object") && bAccepteObject)
		{
			return tabChamp[0];
		}
		else if (tabChamp && (tabChamp.length > 1) && tabChamp[1])
		{
			return tabChamp[1];
		}
		else
		{
			return oGetId(sNom);
		}
	};

	// Autres methodes

	// Conversion d'une valeur quelquonque en booleen
	WDChamp.prototype.bConversionValeur = function bConversionValeur(sValeur)
	{
		// Selon le type de la valeur
		switch ((typeof sValeur).toLowerCase())
		{
			case "boolean":
				return sValeur;
			case "string":
				return (sValeur != "0");
			case "number":
				return (sValeur != "0");
			case "function":
			case "object":
			case "undefined":
			default:
				return false;
		}
	};

	// Recupere tous les elements formulaire d'une cellule
	WDChamp.prototype.tabGetElements = function tabGetElements(oCellule, bAvecLien)
	{
		var tabElements = [];

		if (oCellule)
		{
			// Ajoute dans le tableau les 4 types de champ formulaire
			// La valeur retournee par getElementsByTagName n'est pas un tableau donc :
			// tabElements = tabElements.concat(oCellule.getElementsByTagName("xxx")); ne fonctionne pas

			tabElements = this._tabGetUnTypeElement(oCellule, "button", tabElements);
			tabElements = this._tabGetUnTypeElement(oCellule, "input", tabElements);
			tabElements = this._tabGetUnTypeElement(oCellule, "select", tabElements);
			tabElements = this._tabGetUnTypeElement(oCellule, "textarea", tabElements);
			if (bAvecLien)
			{
				tabElements = this._tabGetUnTypeElement(oCellule, "a", tabElements);
			}
		}

		return tabElements;
	};

	// Fusionne le retour de getElementsByTagName avec un tableau
	WDChamp.prototype._tabGetUnTypeElement = function _tabGetUnTypeElement(oCellule, sTag, tabElements)
	{
		// Trouve les elements
		var tabElementsByTagName = oCellule.getElementsByTagName(sTag);
		// Fusionne les tableaux
		var i = 0;
		var nLimiteI = tabElementsByTagName.length;
		for (i = 0; i < nLimiteI; i++)
		{
			tabElements.push(tabElementsByTagName[i]);
		}
		// Et retourne le tableau resultat
		return tabElements;
	};

	WDChamp.prototype._nGetOffset = function _nGetOffset(sVal)
	{
		var nOffset = parseInt(sVal);
		return (!isNaN(nOffset) && (nOffset > 0)) ? nOffset : 0;
	};

	// Lit le le offsetWidth/offsetHeight d'un champ (version bIEQuirks)
	// oStyle : optionnel
	WDChamp.prototype.__nGetOffsetWidthIEQuirks = function __nGetOffsetWidthIEQuirks(oElement, oStyle)
	{
		if (undefined === oStyle)
		{
			oStyle = oElement.currentStyle;
		}
		return this.__nGetOffsetWidth(oElement) - (this._nGetOffset(oStyle.borderLeftWidth) + this._nGetOffset(oStyle.borderRightWidth));
	};
	WDChamp.prototype.__nGetOffsetHeightIEQuirks = function __nGetOffsetHeightIEQuirks(oElement, oStyle)
	{
		if (undefined === oStyle)
		{
			oStyle = oElement.currentStyle;
		}
		return this.__nGetOffsetHeight(oElement) - (this._nGetOffset(oStyle.borderTopWidth) + this._nGetOffset(oStyle.borderBottomWidth));
	};

	// Lit le le offsetWidth/offsetHeight d'un champ (version selon norme)
	WDChamp.prototype.__nGetOffsetWidth = function __nGetOffsetWidth(oElement)
	{
		return oElement.offsetWidth;
	};
	WDChamp.prototype.__nGetOffsetHeight = function __nGetOffsetHeight(oElement)
	{
		return oElement.offsetHeight;
	};

	// Si le champ a des animations
	WDChamp.prototype.bAnimationsActives = function bAnimationsActives()
	{
		return (this.m_nNbAnimationsActives > 0);
	};

	// Trouve le chemin d'une image par defaut du repertoire res
	// L'appel implique la generation de _WD_
	WDChamp.prototype.sCheminImageRes = function sCheminImageRes(sImage)
	{
		return _WD_ + "res/" + sImage;
	};
}

if (!window["WDChampParametres"])
{
	// Champ avec des parametres
	WDChampParametres = function WDChampParametres_(sAliasChamp, sAliasZR, sAliasAttribut)
	{
		// Si on est pas dans l'init d'un protoype
		if (sAliasChamp)
		{
			// Appel le constructeur de la classe de base
			WDChamp.prototype.constructor.apply(this, arguments);
		}

		this.m_oParametres = null;
		this.m_oDonnees = null;
	};

	// Declare l'heritage
	WDChampParametres.prototype = new WDChamp();
	// Surcharge le constructeur qui a ete efface
	WDChampParametres.prototype.constructor = WDChampParametres;

	// Declare les fonction une par une

	// Fixe les parametres du champ (appel avant l'init ou en cas de retour AJAX)
	WDChampParametres.prototype.SetParametres = function SetParametres(oParametres, oDonnees)
	{
		// Initialise les donnees
		this.m_oParametres = oParametres;
		this.m_oDonnees = oDonnees;

		// Applique les modifications (Attention ! le champ n'est pas forcement encore initialise
		this._vAppliqueParametres();
	};

	WDChampParametres.prototype._vAppliqueParametres = WDChamp.prototype.m_pfVide;

	// Fixe les parametres du champ (retour AJAX)
	// oParametres est un tableau de la forme : [Parametres, Donnees]
	WDChampParametres.prototype._vDeduitParam = function _vDeduitParam(oParametres)
	{
		// Appel de la methode de la classe de base
		WDChamp.prototype._vDeduitParam.apply(this, arguments);

		// Les parametres sont un tableau
		this.SetParametres(oParametres[0], oParametres[1]);
	};

	// Trouve le champ formulaire
	WDChampParametres.prototype._voGetChampFormulaire = function _voGetChampFormulaire()
	{
		// On ne peut pas retourner la valeur par defaut car c'est le champ image qui a l'ID+NAME
		// On utilise donc un autre champ
		return this.oGetElementByName(document, "_DATA");
	};
}
