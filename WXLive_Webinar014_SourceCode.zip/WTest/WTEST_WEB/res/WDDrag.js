//#16.0.1.0 WDDrag.js
//VersionVI: 30A160057k
// Le seul support technique disponible pour cette librairie est
// accessible a travers le service "Assistance Directe".

// Manipulation d'un element par Drag-Drop
function WDDrag(nDelaiAvantDeplacement, nDelaiEntreDeplacement)
{
	// Si on est vraiment dans la construction d'un objet
	if (nDelaiAvantDeplacement !== undefined)
	{
		// Cree les fonctions de rappel
		var oThis = this;
		this.m_fMouseDown = function(oEvent) { oEvent = oEvent ? oEvent : event; oThis.OnMouseDown.apply(oThis, [oEvent]); return oThis._bStopPropagation(oEvent); };
		this.m_fMouseMove = function(oEvent) { oEvent = oEvent ? oEvent : event; oThis.OnMouseMove.apply(oThis, [oEvent]); return oThis._bStopPropagation(oEvent); };
		this.m_fMouseUp = function(oEvent) { oEvent = oEvent ? oEvent : event; oThis.OnMouseUp.apply(oThis, [oEvent]); return oThis._bStopPropagation(oEvent); };
		// Ne fonctionne que avec IE. On stoppe toujours la selection en cas de dragdrop sur un element cible
		this.m_fSelectStart = function(oEvent) { oEvent = oEvent ? oEvent : event; return oThis._bStopPropagation(oEvent); };

		this.m_nDelaiAvantDeplacement = nDelaiAvantDeplacement;
		this.m_nDelaiEntreDeplacement = nDelaiEntreDeplacement;
	}
};

WDDrag.prototype.ms_eDragDrop = 0;
WDDrag.prototype.ms_eDragRedimDebut = 1;
WDDrag.prototype.ms_eDragRedimFin = 2;
// + Droite + Gauche + Coins si besoin

// Initialisation
WDDrag.prototype.Init = function Init()
{
};

// Liberation
WDDrag.prototype.Libere = function Libere()
{
	this.m_fMouseDown = null;
	delete this.m_fMouseDown;
	this.m_fMouseMove = null;
	delete this.m_fMouseMove;
	this.m_fMouseUp = null;
	delete this.m_fMouseUp;
	this.m_fSelectStart = null;
	delete this.m_fSelectStart;
};

// Recupere les positions
WDDrag.prototype.nGetPosX = function nGetPosX()
{
	return this.m_nPosX;
};
WDDrag.prototype.nGetPosY = function nGetPosY()
{
	return this.m_nPosY;
};

// Recupere la variation de la position
WDDrag.prototype.nGetOffsetPosX = function nGetOffsetPosX(oEvent)
{
	var nOffsetPosX = oEvent.clientX - this.nGetPosX();
	// Prend en compte le mode ltr/rtl
	return clWDUtil.bRTL ? -nOffsetPosX : nOffsetPosX;
};
WDDrag.prototype.nGetOffsetPosY = function nGetOffsetPosY(oEvent)
{
	return oEvent.clientY - this.nGetPosY();
};

// Appel lors du debut d'un click pour le redimensionnement
// Pose les hooks
WDDrag.prototype.OnMouseDown = function OnMouseDown(oEvent)
{
	// Uniquement sur le bouton gauche
	if (oEvent.button != (bIE ? 1 : 0))
	{
		return;
	}

	// Appel de la methode surchargee
	this._vbOnMouseDown.apply(this, arguments);
};

// Stop la propagation si demande
WDDrag.prototype._bStopPropagation = function _bStopPropagation(oEvent)
{
	return bStopPropagationCond(oEvent, this._vbStopPropagation());
};

// Pa defaut stoppe la propagation
WDDrag.prototype._vbStopPropagation = function _vbStopPropagation()
{
	return true;
};

// Appel lors du debut d'un click pour le redimensionnement
// Pose les hooks
WDDrag.prototype._vbOnMouseDown = function _vbOnMouseDown(oEvent)
{
	// Sauve la position souris
	this.m_nPosX = oEvent.clientX;
	this.m_nPosY = oEvent.clientY;

	// Intercepte les evenements sur le document
	if (!this.m_bHookPoses)
	{
		this.m_bHookPoses = true;
		HookOnXXX(document, "onmousemove", "mousemove", this.m_fMouseMove);
		HookOnXXX(document, "onmouseup", "mouseup", this.m_fMouseUp);
		if (bIE)
		{
			HookOnXXX(document, "onselectstart", "selectstart", this.m_fSelectStart);
		}
	}

	// Memorise pour le premier deplacement
	this.m_nDateMouseDown = (new Date()).getTime();

	return true;
};

// Appel lors du deplacement de la souris
WDDrag.prototype.OnMouseMove = function OnMouseMove(oEvent)
{
	// Si on demande un delai avant de lancer le deplacement
	var nMaintenant = (new Date()).getTime();
	if (this.m_nDelaiAvantDeplacement > 0)
	{
		if (this.m_nDateMouseDown)
		{
			if ((nMaintenant - this.m_nDateMouseDown) < this.m_nDelaiAvantDeplacement)
			{
				return;
			}
			else
			{
				delete this.m_nDateMouseDown;
			}
		}
	}

	// Si on demande un delai entre deux deplacement
	if (this.m_nDelaiEntreDeplacement > 0)
	{
		if (this.m_nDateMouseMove && ((nMaintenant - this.m_nDateMouseMove) < this.m_nDelaiEntreDeplacement))
		{
			return;
		}
		// On memorise pour le du rafraichissement
		this.m_nDateMouseMove = nMaintenant;
	}

	// Appel de la methode surchargee
	this._vOnMouseMove.apply(this, arguments);
};

// Appel lors du deplacement de la souris
WDDrag.prototype._vOnMouseMove = function _vOnMouseMove(oEvent)
{
	// Rien
};

// Appel lors du relachement de la souris
// Restaure les fonctions hookees
WDDrag.prototype.OnMouseUp = function OnMouseUp(oEvent)
{
	// Appel de la methode surchargee
	this._vOnMouseUp.apply(this, arguments);
};

// Appel lors du relachement de la souris
// Restaure les fonctions hookees
WDDrag.prototype._vOnMouseUp = function _vOnMouseUp(oEvent)
{
	// Restaure les hook du document
	if (this.m_bHookPoses)
	{
		if (bIE)
		{
			UnhookOnXXX(document, "onselectstart", "selectstart", this.m_fSelectStart);
		}
		UnhookOnXXX(document, "onmouseup", "mouseup", this.m_fMouseUp);
		UnhookOnXXX(document, "onmousemove", "mousemove", this.m_fMouseMove);
		delete this.m_bHookPoses;
	}

	// Vire la limitation du rafriachissement
	if (this.m_nDateMouseMove !== undefined)
	{
		delete this.m_nDateMouseMove;
	}
	if (this.m_nDateMouseDown !== undefined)
	{
		delete this.m_nDateMouseDown;
	}

	// Vire la position souris
	delete this.m_nPosX;
	delete this.m_nPosY;
};
