//#16.0.1.0 WDImage.js
//VersionVI: 30A160057k
// Le seul support technique disponible pour cette librairie est
// accessible a travers le service "Assistance Directe".

// Manipulation d'un champ image (avec defilement ou vignette)
function WDImage (sAliasChamp, sAliasZR, sAliasAttribut)
{
	// Si on est pas dans l'init d'un protoype
	if (sAliasChamp)
	{
		// Appel le constructeur de la classe de base
		WDChampParametres.prototype.constructor.apply(this, arguments);
	}
};

// Declare l'heritage
WDImage.prototype = new WDChampParametres();
// Surcharge le constructeur qui a ete efface
WDImage.prototype.constructor = WDImage;

// Par defaut le defilement est inactif (= pas de timer)
WDImage.prototype.m_bDefilement = false;
WDImage.prototype.m_nImage = -1;

// Declare les fonction une par une

// Initialisation :
WDImage.prototype.Init = function Init()
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype.Init.apply(this, arguments);

	// Considere la premiere image comme affichee par le serveur) (si on a une image)
	if (0 < this.nGetNbImages())
	{
		this.m_nImage = this.m_oDonnees.m_nImage;
		this.m_sImageSrc = this.m_oImage.src;
	}
	// Si visible et demande actif, lance le defilement
	this.__DefilementActionSelonServeur();
};

// Trouve les divers elements : liaison avec le HTML
WDImage.prototype._vLiaisonHTML = function _vLiaisonHTML()
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype._vLiaisonHTML.apply(this, arguments);

	// Trouve le champ image
	this.m_oImage = this.oGetElementById(document, "");
	// Trouve la fonction d'affectation de la valeur
	// (6 propriete image en JS)
	this.m_fSetImage = window["_SET_" + this.m_sAliasChamp + "_6_S"];
};

// - Tous les champs : Notifie le champ le conteneur xxx est affiche via un .display = "block"
WDImage.prototype.OnDisplay = function OnDisplay(oElementRacine)
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype.OnDisplay.apply(this, arguments);

	if (this.m_oImage && bEstFils(this.m_oImage, oElementRacine, document))
	{
		// Arrete/Lance le defilement selon la visibilite
		this._DefilementAction();
	}
};

// Fixe les parametres du champ (retour AJAX)
// oParametres est un tableau de la forme : [Parametres, Donnees]
WDImage.prototype._vDeduitParam = function _vDeduitParam(oParametres)
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype._vDeduitParam.apply(this, arguments);

	// Affiche l'image demandee (si l'image est deja affichee, ne fait rien)
	this.AfficheImageExterne(this.m_oDonnees.m_nImage);
	// Reaffiche le champ en relancant le defilement si besoin
	this.__DefilementActionSelonServeur();
};

// Pour implementer ConstruitParam (accepte des parametres variables)
WDImage.prototype._vsConstruitParam = function _vsConstruitParam()
{
	var tabParam = [];
	// Appel de la methode de la classe de base
	var sParam = WDChampParametres.prototype._vsConstruitParam.apply(this, arguments);
	if (sParam.length > 0)
	{
		tabParam.push(sParam);
	}

	// Activite du defilement
	tabParam.push(this.bGetDefilement());
	// Position dans le defilement
	tabParam.push(this.nGetImage());

	return tabParam.join(',');
};

// - Champ image : fin de l'animation
WDImage.prototype._vAnimationFin = function _vAnimationFin(oAnimation)
{
	// Appel de la methode de la classe de base
	WDChampParametres.prototype._vAnimationFin.apply(this, arguments);

	// Tente d'afficher une image en attente
	this.__AfficheImage();
};

// Lance arrete le defilement en fonction de l'action serveur
WDImage.prototype.__DefilementActionSelonServeur = function __DefilementActionSelonServeur()
{
	this.__DefilementModifie(this.m_oDonnees.m_bActif);
};

// Action sur le defilement
WDImage.prototype.__DefilementModifie = function __DefilementModifie(bDefilement)
{
	// Force l'etat
	this.m_bDefilement = bDefilement;

	// Et appel la methode interne
	this._DefilementAction();
	this.ConstruitParam();
};

// Action sur le defilement
WDImage.prototype._DefilementAction = function _DefilementAction()
{
	// Calcule le nouvel etat effectif :
	var bDefilementEffectif = this._vGetDefilementEffectif();

	// Si le defilement effectif change, effectue l'action requise
	if (bDefilementEffectif)
	{
		this.__DefilementLance();
	}
	else
	{
		this.__DefilementArrete();
	}
};

// Lance effectivement le defilement
WDImage.prototype.__DefilementLance = function __DefilementLance()
{
	// Seulement si on a pas deja un timer (le defilement inactif)
	if (!this.bGetTimeXXXExiste("Defilement"))
	{
		// Lance le defilement
		var oThis = this;
		this.SetInterval("Defilement", function () { oThis.Defilement(); }, this.m_oParametres.m_nTemporisation * 10);
	}
};

// Arret du defilement
WDImage.prototype.__DefilementArrete = function __DefilementArrete()
{
	this.AnnuleTimeXXX("Defilement", true);
};

// Effectue le defilement
WDImage.prototype.Defilement = function Defilement()
{
	// Si le defilement est toujours actif
	if (this.bGetTimeXXXExiste("Defilement"))
	{
		// Affiche l'image suivante
		this._AfficheImage(this.nGetImage() + 1);
	}
};

// Calcule de defilement effectif
// Virtuel car surcharge par le champ vignette qui tient compte de l'ouverture
WDImage.prototype._vGetDefilementEffectif = function _vGetDefilementEffectif()
{
	return (this.bGetDefilement() && clWDUtil.bEstDisplay(this.m_oImage, document));
};

// Si le defilement est actif
WDImage.prototype.bGetDefilement = function bGetDefilement()
{
	return this.m_bDefilement;
};

// Position dans le defilement
WDImage.prototype.nGetImage = function nGetImage()
{
	return this.m_nImage;
};

// Affiche une image en relancant le defilement
WDImage.prototype.AfficheImageExterne = function AfficheImageExterne(nPosition)
{
	// Pour avoir un defilement avec le bon interval : arrete puis relance le defilement
	this.__DefilementArrete();
	this._AfficheImage(nPosition);
	this._DefilementAction();
};

// Affiche une image
WDImage.prototype._AfficheImage = function _AfficheImage(nImage)
{
	// Valide la position
	// => Si on n'a pas d'image, invalide la position et note que l'image est valide
	if (0 == this.nGetNbImages())
	{
		this.m_nImage = -1;
		delete this.m_sImageSrc;
	}
	else
	{
		if (nImage < 0)
		{
			nImage -= Math.floor(nImage / this.nGetNbImages()) * this.nGetNbImages();
		}
		else if (nImage >= this.nGetNbImages())
		{
			nImage = 0;
		}

		// Uniquement si l'image est deja affichee : ne fait rien
		if (this.nGetImage() != nImage)
		{
			this.m_nImage = nImage;
			// Invalide la position effective (force le reaffichage)
			delete this.m_sImageSrc;
		}
		// Regarde si l'image courante ne serait pas par hasard une image differente (changement de source sur le serveur)
		else if (this.m_sImageSrc && (this.m_sImageSrc != this.m_oImage.src))
		{
			delete this.m_sImageSrc;
		}

		// Affiche l'image si besoin
		this.__AfficheImage();
	}
	this.ConstruitParam();
};

// Affiche une image
WDImage.prototype.__AfficheImage = function __AfficheImage()
{
	// Si la position effective est differente de l'image affichee, l'affiche
	// Si on a une animation en cours, on n'affiche pas l'image on l'affichera a la fin de l'animation
	if ((undefined === this.m_sImageSrc) && !this.bAnimationsActives())
	{
		var oImage = this.m_oDonnees.m_tabImages[this.m_nImage];
		// Et affiche l'image (l'animation est faite automatiquement)
		this.m_fSetImage(oImage.m_sSrc);
		// Valide l'image
		this.m_sImageSrc = this.m_oImage.src;
	}
};

//////////////////////////////////////////////////////////////////////////
// Interface pour le WL

// ImageLanceDefilement
WDImage.prototype.LanceDefilement = function LanceDefilement()
{
	this.__DefilementModifie(true);
};

// ImageArreteDefilement
WDImage.prototype.ArreteDefilement = function ArreteDefilement()
{
	this.__DefilementModifie(false);
};

// ImagePremier
WDImage.prototype.AffichePremier = function AffichePremier()
{
	this.AfficheImageExterne(0);
};

// ImagePrecedent
WDImage.prototype.AffichePrecedent = function AffichePrecedent()
{
	this.AfficheImageExterne(this.nGetImage() - 1);
};

// ImageSuivant
WDImage.prototype.AfficheSuivant = function AfficheSuivant()
{
	this.AfficheImageExterne(this.nGetImage() + 1);
};

// ImageDernier
WDImage.prototype.AfficheDernier = function AfficheDernier()
{
	this.AfficheImageExterne(this.nGetNbImages() - 1);
};

// ImagePositionDefilement
WDImage.prototype.nGetPositionWL = function nGetPositionWL()
{
	return this.nGetImage() + 1;
};
WDImage.prototype.SetPositionWL = function SetPositionWL(nPositionWL)
{
	this.AfficheImageExterne(nPositionWL - 1);
};

// ImageOccurrence
WDImage.prototype.nGetNbImages = function nGetNbImages()
{
	return this.m_oDonnees.m_tabImages.length;
};
