//#16.00.02.00 WDGeoLocalisation.js
//VersionVI: 30A170078p
// Le seul support technique disponible pour cette librairie est
// accessible a travers le service "Assistance Directe".

var gpsActive=1;
var gpsDesactive=2;
var gpsErreurOK=0;
var gpsErreurDroit=1;
var gpsErreurPosition=2;
var gpsErreurTimeout=3;
var gpsPCSSuivi=null;
var gpsPCSPosition=null;

function WDGeoPosition(oPosition)
{
	if(oPosition)
	{
		WDTypeAvance.prototype.constructor.apply(this,[]);
		this.m_oPosition=oPosition;
	}
};

WDGeoPosition.prototype=new WDTypeAvance(true);

WDGeoPosition.prototype.constructor=WDGeoPosition;

function bValDef(v,n)
{
	return (v!==null)&&(v!==undefined)&&(v!==NaN)&&(n||(v>=0));
}

function sComplete0(s,n)
{
	s=""+s;
	while(s.length<n) s="0"+s;
	return s;
}

WDGeoPosition.prototype.GetProp=function GetProp(nPropriete)
{
	switch(nPropriete)
	{
		case 0:
			return this.m_oPosition.coords.latitude;
		case 1:
			return this.m_oPosition.coords.longitude;
		case 2:
			return this.m_oPosition.coords.altitude;
		case 3:
			return bValDef(this.m_oPosition.coords.altitude,true);
		case 4:
			return this.m_oPosition.coords.heading;
		case 5:
			return bValDef(this.m_oPosition.coords.heading);
		case 6:
			return this.m_oPosition.coords.accuracy;
		case 7:
			return bValDef(this.m_oPosition.coords.accuracy);
		case 8:
			return this.m_oPosition.coords.speed;
		case 9:
			return bValDef(this.m_oPosition.coords.speed);
		case 10:
			var d=new Date(this.m_oPosition.timestamp);
			return sComplete0(d.getFullYear(),4)+sComplete0(d.getMonth()+1,2)+sComplete0(d.getDate(),2)+sComplete0(d.getHours(),2)+sComplete0(d.getMinutes(),2)+sComplete0(d.getSeconds(),2)+sComplete0(Math.floor((this.m_oPosition.timestamp%1000)/10),2);
		default:
			return WDTypeAvance.prototype.GetProp.apply(this,arguments);
	}
};

function GPSEtat()
{
	return ((navigator!=null)&&(navigator.geolocation!=null))?gpsActive:gpsDesactive;
}

function GPSPCSAppelProcPosition(f,p)
{
	if(gpsPCSPosition!=null) delete gpsPCSPosition;
	gpsPCSPosition=new WDGeoPosition(p);
	f(gpsPCSPosition,gpsErreurOK);
}

function GPSPCSAppelProcErreur(f,e)
{
	f(null,e.code);
}

function GPSRecuperePosition(f,t)
{
	if(GPSEtat()!=gpsActive) return;
	navigator.geolocation.getCurrentPosition(function(p) { GPSPCSAppelProcPosition(f,p); },function(e) { GPSPCSAppelProcErreur(f,e); },{ timeout: ((t==null)?6000:t)*10 });
}

function GPSSuitDeplacement(f)
{
	if(GPSEtat()!=gpsActive) return;
	if(gpsPCSSuivi!=null)
	{
		navigator.geolocation.clearWatch(gpsPCSSuivi);
		gpsPCSSuivi=null;
	}
	if(f==null) return;
	gpsPCSSuivi=navigator.geolocation.watchPosition(function(p) { GPSPCSAppelProcPosition(f,p); },function(e) { GPSPCSAppelProcErreur(f,e); });
}

function GPSDernierePosition()
{
	return gpsPCSPosition;
}