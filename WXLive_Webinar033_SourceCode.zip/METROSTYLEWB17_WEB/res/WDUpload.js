//#17.0.1.0 WDUpload.js
//VersionVI: 30A170078p
// Le seul support technique disponible pour cette librairie est
// accessible a travers le service "Assistance Directe".

// Manipulation des champs Upload

// Manipulation d'un Upload
function WDUpload(sAliasChamp, sAliasZR, sAliasAttribut, sFiltre)
{
	// Si on est pas dans l'init d'un protoype
	if (sAliasChamp)
	{
		// Appel le constructeur de la classe de base
		WDChamp.prototype.constructor.apply(this, [sAliasChamp, sAliasZR, sAliasAttribut]);

		this.m_oFlash = null;
		this.m_sFiltre = sFiltre;
		// Init du cache du mode multifichier
		this.m_bMultiFichiers = false;
		// Tableau des fichiers recus par drag-drop
		this.m_tabFichiersDragDrop = [];
		this.m_oUploadFichierDragDrop = null;
	}
};

// Declare l'heritage
WDUpload.prototype = new WDChamp();
// Surcharge le constructeur qui a ete efface
WDUpload.prototype.constructor = WDUpload;
// Enumeration eUPLOADPROGRESSDATA
WDUpload.prototype.ms_eProgressDataEnvoyee = 0;
WDUpload.prototype.ms_eProgressDataTotal = 1;
WDUpload.prototype.ms_eProgressDataFichierEnvoyee = 2;
WDUpload.prototype.ms_eProgressDataFichierTotal = 3;
WDUpload.prototype.ms_eProgressDataFichier = 4;
// Limite pour l'upload de fichiers
WDUpload.prototype.ms_sBoundary = "WDUPLOAD";

// Initialisation
WDUpload.prototype.Init = function Init(sAliasChampDragDrop)
{
	// Appel de la methode de la classe de base
	WDChamp.prototype.Init.apply(this, arguments);

	// Init interne
	this._Init(false);

	// Initialise le drag-drop sur le champ lie si besoin
	if (sAliasChampDragDrop)
	{
		var oThis = this;
		this.m_oDnDFichiers = new WDDnDFichiers(this.m_bMultiFichiers, function(tabFichiers) { return oThis.OnDropFichiers(tabFichiers); }, _JGE(sAliasChampDragDrop, document, true, false));
		this.m_fOnLoadFile = function(oEvent) { oThis.OnLoadFile(oEvent || event); };
		this.m_fProgress = function(oEvent) { oThis.OnProgress(oEvent || event); };
		this.m_fReadyStateChange = function(oEvent) { oThis.OnReadyStateChange(oEvent || event); };
	}
};

// Methode d'initialisation generale de la classe
// Filtre et ne s'execute que lors de l'init du PREMIER champ de ce type
WDUpload.prototype._vInitInitiale = function _vInitInitiale()
{
	// Appel de la methode de la classe de base
	WDChamp.prototype._vInitInitiale.apply(this, arguments);

	// Ajoute sendAsBinary sur XMLHttpRequest
	if (XMLHttpRequest && !XMLHttpRequest.prototype.sendAsBinary)
	{
		// Contournement de la fiche 35705 : http://code.google.com/p/chromium/issues/detail?id=35705
		// Modifie pour respecter la norme de codage locale
		XMLHttpRequest.prototype.sendAsBinary = function(sRequete)
		{
			this.send((new Uint8Array(Array.prototype.map.call(sRequete, function(x) { return x.charCodeAt(0) & 0xff; }))).buffer);
		}
	}

	// S'auto efface pour ne plus etre appele
	WDUpload.prototype._vInitInitiale = clWDUtil.m_pfVide;
};

// Init interne (aussi appele lors de l'affichage)
WDUpload.prototype._Init = function _Init(bPourDisplay)
{
	// Recupere le champ flash
	this.m_oFlash = this.oGetObjectEmbed(this.m_sAliasChamp, bIE);
	// Si le flash est deplace dans le DOM, il faut refixer sa valeur sinon le lien avec les fonctions interne est perdu
	if (bFF && bPourDisplay)
	{
		this.m_oFlash.data = this.m_oFlash.data;
	}
	// Donne au flash le nom du champ
	this.nSetTimeout(this.InitFlash, 500);

	// Hack pour chrome/safari qui ne met pas le champ flash dans le formulaire
	if (bWK)
	{
		_PAGE_[this.m_sAliasChamp] = this.m_oFlash;
	}
};

// Initialise le flahs en lui donnant ses parametres
WDUpload.prototype.InitFlash = function InitFlash()
{
	// Si le champ n'est pas visible (display:none), certains navigateurs n'affichent pas le champ
	// Ce n'est pas grave de ne pas faire l'init car en cas d'affichage, on recoit un OnDisplay
	if (clWDUtil.bEstDisplay(this.m_oFlash, document))
	{
		try
		{
			// Donne le nom du champ (normalement deja fait)
			this.m_oFlash.SetAlias(this.m_sAliasChamp);
			// Et le filtre
			this.m_oFlash.SetFiltre(this.m_sFiltre);
			// Cache du mode multifichier
			this.m_bMultiFichiers = (true == this.m_oFlash.bGetMultiFichiers());
			if (this.m_oDnDFichiers)
			{
				this.m_oDnDFichiers.m_bMultiFichiers = this.m_bMultiFichiers;
			}
		}
		catch (e)
		{
			// Donne au flash le nom du champ
			this.nSetTimeout(this.InitFlash, 500);
		}
	}
};

// Interface AVEC le WL

// ..Valeur
WDUpload.prototype.GetValeur = function GetValeur(oEvent, nOccurrence, oChamp)
{
	// Rappel de la classe de base avec la bonne valeur
	return WDChamp.prototype.GetValeur.apply(this, [oEvent, this.__sGetFichiers(false), oChamp]);
};

// Lit les proprietes dont l'occurrence et []
WDUpload.prototype.GetProp = function GetProp(eProp, oEvent, oValeur, oChamp)
{
	switch (eProp)
	{
	case this.XML_CHAMP_PROP_NUM_SOUSELEMENT:
		// Nom d'un sous element (= nom d'un fichier)
		return this.__tabGetFichier(oValeur - 1)[0];
	case this.XML_CHAMP_PROP_NUM_OCCURRENCE:
		// Traite le cas de ..Occurrence
		return this.__nGetOccurrence();
	default:
		// Retourne a l'implementation de la classe de base avec la valeur eventuellement modifie
		return WDChamp.prototype.GetProp.apply(this, arguments);
	}
};

// Ecrit les proprietes dont l'occurrence : pas en ecriture
//WDUpload.prototype.SetProp = function SetProp(eProp, oEvent, oValeur, oChamp)

// Submit de la page
WDUpload.prototype.OnSubmit = function OnSubmit()
{
	// Pas d'upload dans le submit pour le moment
};

// Fonction WL UploadLance
// !!! Fonction en ellipse !!!
//WDUpload.prototype.Lance = function Lance (sFonction)
WDUpload.prototype.Lance = function Lance()
{
	// Appele la fonction interne commune avec OnSubmit
	// Prepare au passage les parametres
	this.__Lance(clWDUtil.sConstuitProcedureParams(0, arguments));
};

// Fonction principale de l'upload
WDUpload.prototype.__Lance = function __Lance(sParams)
{
	// Si on a des fichier a uploader et que l'on n'est pas deja en cours d'upload
	if ((0 == this.__nGetOccurrence()) || this.__bGetUploadEnCours())
	{
		return;
	}

	// true : ajoute la marque de session
	var sAction = clWDUtil.sGetPageAction(null, false, true, true);
	sAction += ((sAction.indexOf("?") != -1) ? "&" : "?");

	// - Prepare le parametre de session AWP
	var sParamAWP = "";
	// - Prepare le nom du champ
	var sNomChamp = "&WD_BUTTON_CLICK_=" + this.m_sAliasChamp;

	// La requete pour les fichiers normaux
	var sURL = sAction + "WD_ACTION_=UPLOADFICHIER" + sParamAWP + sNomChamp;
	// La requete pour le dernier fichier
	var sURLFinale;
	if (sParams !== undefined)
	{
		// Cas de UploadLance : avec procedure et parametre
		sURLFinale = sAction + "WD_ACTION_=UPLOADFICHIERFIN" + sParamAWP + sNomChamp + sParams;
	}
	else
	{
		// Cas du submit : upload normal
		// sURL contient deja sAction
		sURLFinale = sURL;
	}

	// Memorise le moment du lancement de l'upload pour avoir une reference pour les reveils periodiques du serveur
	this.m_nReveilDernier = (new Date()).getTime();
	// Avec l'action serveur
	this.m_sReveilURL = sAction + "WD_ACTION_=UPLOADREVEIL" + sParamAWP + sNomChamp;

	// Calcule la taille des fichiers de l'upload et du flash
	this.m_tabProgressDataDragDrop = [0, this.__nGetTailleTotale(this.__sGetFichiersDragDrop(true)), 0, 0, 0];
	this.m_tabProgressDataFlash = [0, this.__nGetTailleTotale(this.__sGetFichiersFlash(true)), 0, 0, 0];

	// Lance l'upload en commencant par les fichiers en drag-drop
	// (s'il n'y en a pas cela continura automatiquement sur l'upload flash)
	this.__LanceUploadFichierDragDrop(sURL, sURLFinale);
};

// Fonction principale de l'upload pour les fichiers en drag-drop
WDUpload.prototype.__LanceUploadFichierDragDrop = function __LanceUploadFichierDragDrop(sURL, sURLFinale)
{
	// Construit un objet upload de drag-drop
	this.m_oUploadFichierDragDrop = { m_sURL : sURL, m_sURLFinale : sURLFinale, m_nFichier : 0 };
	// Premier fichier
	this.__UploadFichierDragDrop();
};
WDUpload.prototype.__UploadFichierDragDrop = function __UploadFichierDragDrop(sDataFichierPrecedent)
{
	// Si on n'est pas sur le dernier fichier
	if (this.m_oUploadFichierDragDrop.m_nFichier < this.m_tabFichiersDragDrop.length)
	{
		var oFileReader = new FileReader();
		oFileReader.onload = this.m_fOnLoadFile;
		oFileReader.readAsBinaryString(this.m_tabFichiersDragDrop[this.m_oUploadFichierDragDrop.m_nFichier]);
	}
	else
	{
		// Fin de l'upload
		try
		{
			// Et lancement de l'upload flash si besoin
			if (0 < this.__nGetOccurrenceFlash())
			{
				this.__LanceUploadFlash(this.m_oUploadFichierDragDrop.m_sURL, this.m_oUploadFichierDragDrop.m_sURLFinale);
			}
			else
			{
				this.OnFin(sDataFichierPrecedent);
			}
		}
		finally
		{
			this.m_oUploadFichierDragDrop = null;
		}
	}
};

// Calcule la taille des fichiers du flash

// Fonction principale de l'upload pour le flash
WDUpload.prototype.__LanceUploadFlash = function __LanceUploadFlash(sURL, sURLFinale)
{
	// Notifie le flash
	this.m_oFlash.SetURLs(sURL, sURLFinale);

	// Lance l'upload
	this.m_oFlash.ActionUpload();
};

// Recupere les informations sur un fichier (nFichier est en indice C)
WDUpload.prototype.__tabGetFichier = function __tabGetFichier(nFichier)
{
	// Recupere la liste des fichiers;
	var sValeur = this.__sGetFichiers(true);
	// Transforme la chaine en tableau
	var tabValeur = sValeur.split("\r\n");

	// Recupere la valeur si l'indice est valide
	if ((nFichier >= 0) && (nFichier < tabValeur.length))
	{
		var tabFichier = tabValeur[nFichier].split("\t");
		tabFichier[1] = parseInt(tabFichier[1], 10);
		return tabFichier;
	}
	return ["", 0];
};
WDUpload.prototype.__sGetFichiers = function __sGetFichiers(bAvecTaille)
{
	var sFichiers = this.__sGetFichiersFlash(bAvecTaille);
	if (0 < this.m_tabFichiersDragDrop.length)
	{
		if (0 < sFichiers.length)
		{
			sFichiers += "\r\n";
		}
		sFichiers += this.__sGetFichiersDragDrop(bAvecTaille);
	}
	return sFichiers;
};
WDUpload.prototype.__sGetFichiersDragDrop = function __sGetFichiersDragDrop(bAvecTaille)
{
	var tabFichiers = [];
	var i;
	var nLimiteI = this.m_tabFichiersDragDrop.length;
	for (i = 0; i < nLimiteI; i++)
	{
		tabFichiers.push(this.m_tabFichiersDragDrop[i].name + (bAvecTaille ? ("\t" + this.m_tabFichiersDragDrop[i].size) : ""));
	}
	return tabFichiers.join("\r\n");
};
WDUpload.prototype.__sGetFichiersFlash = function __sGetFichiersFlash(bAvecTaille)
{
	return this.m_oFlash.sGetFichiers(bAvecTaille);
};
WDUpload.prototype.__nGetOccurrence = function __nGetOccurrence()
{
	return this.m_tabFichiersDragDrop.length + this.__nGetOccurrenceFlash();
};
WDUpload.prototype.__nGetOccurrenceFlash = function __nGetOccurrenceFlash()
{
	return parseInt(this.m_oFlash.nGetOccurrence(), 10);
};
WDUpload.prototype.__bGetUploadEnCours = function __bGetUploadEnCours()
{
	return this.m_oUploadFichierDragDrop || (true == this.m_oFlash.bGetUploadEnCours());
};

// Trouve la taille depuis la chaine avec taille
WDUpload.prototype.__nGetTailleTotale = function __nGetTailleTotale(sFichiersAvecTaille)
{
	var nTailleTotale = 0;
	if (0 < sFichiersAvecTaille.length)
	{
		// Transforme la chaine en tableau
		var tabFichiersAvecTaille = sFichiersAvecTaille.split("\r\n");
		var i;
		var nLimiteI = tabFichiersAvecTaille.length;
		for (i = 0; i < nLimiteI; i++)
		{
			var tabFichier = tabFichiersAvecTaille[i].split("\t");
			nTailleTotale += parseInt(tabFichier[1], 10);
		}
	}
	return nTailleTotale;
};

// Fonctions WL UploadTailleXXX
WDUpload.prototype.nGetProgressData = function nGetProgressData (eInformation)
{
	// Si on est dans un upload : this.m_tabProgressData est indexe sur les ms_eProgressDataXXX
	if (this.m_tabProgressData)
	{
		return this.m_tabProgressData[eInformation];
	}

	// Valeur par defaut de l'avancement de l'upload si on est pas dans un upload
	return 0;
};

// Fonction WL UploadSupprime
WDUpload.prototype.Supprime = function Supprime (nPositionWL)
{
	var nPosition = nPositionWL - 1;
	if (nPosition < this.m_tabFichiersDragDrop.length)
	{
		this.m_tabFichiersDragDrop[nPosition] = null;
		this.m_tabFichiersDragDrop.splice(nPosition, 1);
		return;
	}
	else
	{
		// Le code flash attend un indice WL sous forme de chaine
		this.m_oFlash.ActionSupprime((nPositionWL - this.m_tabFichiersDragDrop.length) + "");
	}
};

// Fonction WL UploadSupprimeTout
WDUpload.prototype.SupprimeTout = function SupprimeTout ()
{
	this.__SupprimeToutDragDrop();

	// Appel le flash
	this.m_oFlash.ActionSupprimeTout();
};
WDUpload.prototype.__SupprimeToutDragDrop = function __SupprimeToutDragDrop()
{
	var i;
	var nLimiteI = this.m_tabFichiersDragDrop.length;
	for (i = 0; i < nLimiteI; i++)
	{
		this.m_tabFichiersDragDrop[i] = null;
	}
	this.m_tabFichiersDragDrop.length = 0;
};

// Fonction WL UploadTailleFichier
WDUpload.prototype.nGetUploadTailleFichier = function nGetUploadTailleFichier(nIndiceFichierWL)
{
	if (!nIndiceFichierWL)
	{
		nIndiceFichierWL = 1;
	}
	// Passe en indice C
	return this.__tabGetFichier(nIndiceFichierWL - 1)[1];
};

// Interface pour le flash

// Appel d'une methode depuis le flash
// => Il faut utiliser AppelMethodeChamp

// Progression de l'upload (version flash non renomme car appele du flash)
WDUpload.prototype.OnAvancement = function OnAvancement(nEnvoyee, nTotal, nFichierEnvoyee, nFichierTotal, nFichier)
{
	if (isNaN(nEnvoyee))
	{
		// Affiche le message d'erreur
		alert(STD_ERREUR_MESSAGE_UPLOAD);
		// Et force une MAJ de l'affichage
		nEnvoyee = 1;
		nTotal = 1;
	}

	// Calcule qui a deja ete envoie par l'upload AJAX des fichiers drag-drop
	// Normalement this.m_tabProgressDataDragDrop[this.ms_eProgressDataTotal] == this.m_tabProgressDataDragDrop[this.ms_eProgressDataEnvoyee]
	nEnvoyee += this.m_tabProgressDataDragDrop[this.ms_eProgressDataTotal];
	nTotal += this.m_tabProgressDataDragDrop[this.ms_eProgressDataTotal];
	nFichier += this.m_tabProgressDataDragDrop[this.ms_eProgressDataFichier];

	// Memorise les donnees de la progression
	// Passe nFichier de l'indice C en indice WL
	this.m_tabProgressData = [nEnvoyee, nTotal, nFichierEnvoyee, nFichierTotal, nFichier + 1];

	// Pour eviter les messages de flash sur le script qui s'execute trop longtemp, on repouse l'appel
	// Si un appel est deja en attente : pas d'empilage
	// En revanche les dernieres donnees sont utilisees (voir la ligne au dessus)
	if (this.nGetVariableTimeXXX("OnAvancement") === undefined)
	{
		this[this.sNomVariableTimeXXX("OnAvancement")] = this.nSetTimeout(this.__OnAvancement, 1);
	}
};

// Progression de l'upload version interne
WDUpload.prototype.__OnAvancement = function __OnAvancement()
{
	// Effectue un reveil periodique de la session pour que un upload long ne la fasse pas tomber en timeout
	var nMaintenant = (new Date()).getTime();
	// Si le dernier reveil est trop ancien, en effectue un autre
	// Toutes les 3 minutes
	if (this.m_nReveilDernier && ((nMaintenant - this.m_nReveilDernier) > 180000))
	{
		// Requete AJAX vers le serveur
		var oImageTemp = (new Image()).src = this.m_sReveilURL + "&RAND=" + Math.random();
		this.m_nReveilDernier = nMaintenant;
	}

	// Appele le PCode
	// Pas d'event
	this.RecuperePCode(this.ms_nEventNavUploadAvancement)();

	// Supprime les donnees de la progression
	delete this.m_tabProgressData;
	this.SupprimeTimeout("OnAvancement");
};

// Changement du contenu de la liste des fichiers
WDUpload.prototype.OnChange = function OnChange()
{
	// Appele le PCode
	// Pas d'event
	this.RecuperePCode(this.ms_nEventNavUploadSelection)();
};

// Changement du contenu de la liste des fichiers par DragDraop
WDUpload.prototype.OnDropFichiers = function OnDropFichiers(tabFichiers)
{
	// Si on n'est pas en mode multifichiers : vide la liste courante
	if (!this.m_bMultiFichiers)
	{
		this.SupprimeTout();
	}

	// Ajoute a la liste des fichiers
	var i;
	var nLimiteI = tabFichiers.length;
	for (i = 0; i < nLimiteI; i++)
	{
		this.m_tabFichiersDragDrop.push(tabFichiers[i]);
	}

	// Changement du contenu de la liste des fichiers
	this.OnChange();
};

// Fin de l'upload
WDUpload.prototype.OnFin = function OnFin(sData)
{
	// Supprime les fichiers recus par drag-drop
	this.__SupprimeToutDragDrop();

	delete this.m_tabProgressDataDragDrop;
	delete this.m_tabProgressDataFlash;

	// Si on a des donnees : appel le traitement en AJAX
	clWDAJAXMain.bReponseGeneriqueDepuisTexte(sData, _PAGE_);

	// Appele le PCode
	// Pas d'event
	this.RecuperePCode(this.ms_nEventNavUploadFin)();
};

// Passe en mode editable les barres affichees
WDUpload.prototype.OnDisplay = function OnDisplay(oElementRacine)
{
	// Appel de la methode de la classe de base
	WDChamp.prototype.OnDisplay.apply(this, arguments);

	if (this.m_oFlash && bEstFils(this.m_oFlash, oElementRacine, document))
	{
		// Reinit les membres du flash (requis dans le cas d'un pageaffiche dialogue)
		this._Init(true);
	}
};

// Chargement du fichier sur le disque
WDUpload.prototype.OnLoadFile = function OnLoadFile(oEvent)
{
	// On ne passe pas par WDAjax qui ne fait pas pareil
	var oRequeteUpload = new XMLHttpRequest();
	var sBoundary = this.ms_sBoundary + (new Date()).getTime();
	var oFichier = this.m_tabFichiersDragDrop[this.m_oUploadFichierDragDrop.m_nFichier];
	var bDernier = (this.m_oUploadFichierDragDrop.m_nFichier == (this.m_tabFichiersDragDrop.length - 1)) && (0 == this.__nGetOccurrenceFlash());
	// Comme la requete du champ flash
	// Parametre 1 : nom du fichier
	var tabRequete = [];
	tabRequete.push("--");
	tabRequete.push(sBoundary);
	tabRequete.push("\r\n");
	tabRequete.push("Content-Disposition: form-data; name=\"Filename\"");
	tabRequete.push("\r\n\r\n");
	tabRequete.push(unescape(encodeURIComponent(oFichier.name)));
	tabRequete.push("\r\n");
	// Parametre 2 : fichier
	tabRequete.push("--");
	tabRequete.push(sBoundary);
	tabRequete.push("\r\n");
	tabRequete.push("Content-Disposition: form-data; name=\"Filedata\"; filename=\"");
	tabRequete.push(unescape(encodeURIComponent(oFichier.name)));
	tabRequete.push("\"");
	tabRequete.push("\r\n");
	tabRequete.push("Content-Type: application/octet-stream");
	tabRequete.push("\r\n\r\n");
	tabRequete.push(oEvent.target.result);
	tabRequete.push("\r\n");
	// Parametre 3
	tabRequete.push("--");
	tabRequete.push(sBoundary);
	tabRequete.push("\r\n");
	tabRequete.push("Content-Disposition: form-data; name=\"Upload\"");
	tabRequete.push("\r\n\r\n");
	tabRequete.push("Submit Query");
	tabRequete.push("\r\n");
	// Marque de fin
	tabRequete.push("--");
	tabRequete.push(sBoundary);
	tabRequete.push("--");
	var sRequete = tabRequete.join("");
	// Libere immediatement la memoire
	tabRequete = null;
	delete tabRequete;

	oRequeteUpload.open("POST", bDernier ? this.m_oUploadFichierDragDrop.m_sURLFinale : this.m_oUploadFichierDragDrop.m_sURL, true);
	oRequeteUpload.setRequestHeader("Content-Type", "multipart/form-data, boundary=" + sBoundary);
	if (!bCrm)
	{
		oRequeteUpload.setRequestHeader("Content-Length", sRequete.length);
	}
	oRequeteUpload.onreadystatechange = this.m_fReadyStateChange;
	// RAZ pour que OnReadyStateChange detecte si OnProgress a ete appele
	this.m_tabProgressDataDragDrop[this.ms_eProgressDataFichierEnvoyee] = 0;
	this.m_tabProgressDataDragDrop[this.ms_eProgressDataFichierTotal] = 0;
	if (oRequeteUpload.upload)
	{
		HookOnXXX(oRequeteUpload.upload, "onprogress", "progress", this.m_fProgress);
	}

	this.m_oRequeteUpload = oRequeteUpload;
	this.m_oRequeteUpload.m_nTailleTexteRequete = sRequete.length - oEvent.target.result.length;
	oRequeteUpload.sendAsBinary(sRequete);
};

// Maj de l'avancement depuis l'upload de fichiers
WDUpload.prototype.__OnAvancementDnD = function __OnAvancementDnD(oEvent)
{
	var nEnvoyee = this.m_tabProgressDataDragDrop[this.ms_eProgressDataEnvoyee] + this.m_tabProgressDataDragDrop[this.ms_eProgressDataFichierEnvoyee];
	var nTotal = this.m_tabProgressDataDragDrop[this.ms_eProgressDataTotal] + this.m_tabProgressDataFlash[this.ms_eProgressDataTotal];
	var nFichierEnvoyee = this.m_tabProgressDataDragDrop[this.ms_eProgressDataFichierEnvoyee];
	var nFichierTotal = this.m_tabProgressDataDragDrop[this.ms_eProgressDataFichierTotal] > 0 ? this.m_tabProgressDataDragDrop[this.ms_eProgressDataFichierTotal] : this.m_tabFichiersDragDrop[this.m_oUploadFichierDragDrop.m_nFichier].size;
	var nFichier = this.m_oUploadFichierDragDrop.m_nFichier;

	// MAJ de l'affichage
	this.m_tabProgressData = [nEnvoyee, nTotal, nFichierEnvoyee, nFichierTotal, nFichier + 1];
	this.__OnAvancement();
};

// Avancement dans l'upload d'un fichier par XMLHttpRequest
WDUpload.prototype.OnProgress = function OnProgress(oEvent)
{
	if (oEvent.lengthComputable)
	{
		this.m_tabProgressDataDragDrop[this.ms_eProgressDataFichierEnvoyee] = Math.max(oEvent.loaded - this.m_oRequeteUpload.m_nTailleTexteRequete, 0);
		this.m_tabProgressDataDragDrop[this.ms_eProgressDataFichierTotal] = oEvent.total - this.m_oRequeteUpload.m_nTailleTexteRequete;
		this.__OnAvancementDnD(oEvent);
	}
};

// Avancement de l'upload d'un fichier par XMLHttpRequest
WDUpload.prototype.OnReadyStateChange = function OnReadyStateChange(oEvent)
{
	// MAJ de l'affichage
	this.__OnAvancementDnD(oEvent);

	if (this.m_oRequeteUpload.readyState == WDAJAXRequete.prototype.readyStateComplete)
	{
		if (this.m_oRequeteUpload.upload)
		{
			UnhookOnXXX(this.m_oRequeteUpload.upload, "onprogress", "progress", this.m_fProgress);
		}
		this.m_oRequeteUpload.onreadystatechange = clWDUtil.m_pfVide;
		var sData;
		if (200 == this.m_oRequeteUpload.status)
		{
			this.m_tabProgressDataDragDrop[this.ms_eProgressDataEnvoyee] += this.m_tabFichiersDragDrop[this.m_oUploadFichierDragDrop.m_nFichier].size;

			// Trouve les datas
			sData = clWDEncode.sEncodeCharset(this.m_oRequeteUpload.responseText, false);
		}

		// Liberation dans tous les cas
		this.m_oRequeteUpload.m_nTailleTexteRequete = null;
		delete this.m_oRequeteUpload.m_nTailleTexteRequete;
		this.m_oRequeteUpload = null;
		delete this.m_oRequeteUpload;

		if (sData)
		{
			// Fichier suivant
			this.m_oUploadFichierDragDrop.m_nFichier++;
			this.__UploadFichierDragDrop(sData);
		}
	}
};
