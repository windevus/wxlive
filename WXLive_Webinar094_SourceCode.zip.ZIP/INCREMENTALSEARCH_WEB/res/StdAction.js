function _CFI(a)
{
	var i = a.indexOf("?");
	var j = a.lastIndexOf("?");

	while (j > i)
	{
		a = a.substring(0, j - 1) + "&" + a.substring(j + 1);
		j = a.lastIndexOf("?");
	}
	return a;
}
function _JCL(a,t,n,o)
{
	a=_CFI(a);
	if (t == "_blank")
	{
		if (o)
		{
			open(a, n.toUpperCase(), o);
		}
		else
		{
			open(a, n.toUpperCase());
		}
	}
	else if (t == "_top")
	{
		top.document.location = a;
	}
	else if (t == "_parent")
	{
		parent.document.location = a;
	}
	else if (t == "_self")
	{
		self.document.location = a;
	}
	else
	{
		var f = _JOF(top, t);
		if (f.parent == self) { open(a, t); }
		else { f.document.location = a; }
	}
}
function _JRL(a,t,n,o)
{
	a=_CFI(a);
	if (t == "_blank")
	{
		if (o)
		{
			open(a, n.toUpperCase(), o);
		}
		else
		{
			open(a, n.toUpperCase());
		}
	}
	else if (t == "_top")
	{
		top.document.location.replace(a);
	}
	else if (t == "_parent")
	{
		parent.document.location.replace(a);
	}
	else if (t == "_self")
	{
		self.document.location.replace(a);
	}
	else
	{
		_JOF(top, t).document.location.replace(a);
	}
}
function _JSL(p, a, t, n, o, ac)
{
	var _p = p;
	var _b = p.WD_BUTTON_CLICK_.value;
	var _t = p.target;

	a = _CFI(a);
	p.WD_ACTION_.value = (ac ? ac : "");
	p.WD_BUTTON_CLICK_.value = a;
	var s = ((navigator.appName == "Microsoft Internet Explorer") && (navigator.platform.substr(0, 3) == "Mac")) ? 200 : 1;
	switch (t)
	{
	case "_blank":
		if (o)
		{
			var e = (n != "" ? n.toUpperCase() : "_BLANK_" + Math.abs((new Date()).getTime()));
			if (o)
			{
				open("", e, o);
			}
			else
			{
				open("", e);
			}
			t = e;
			s = 1000;
		}
		// Pas de break;
	case "_self":
	case "_top":
	case "_parent":
		p.target = t;
		break;
	default:
		p.target = t.toUpperCase();
		break;
	}
	p.submit();
	setTimeout(function() { _p.target = _t; _p.WD_BUTTON_CLICK_.value = _b; }, s);
}
function _JOF(w,n)
{
	try
	{
		if(w.frames[n])
		{
			return w.frames[n];
		}
	}
	catch(e)
	{
	}
	var i;for(i=0;i<w.frames.length;i++)
	{
		try
		{
			if (w.frames[i].name.toUpperCase() == n.toUpperCase())
			{
				return w.frames[i];
			}
		}
		catch (e)
		{
		}
		var f =_JOF(w.frames[i],n);
		if(f)
		{
			return f;
		}
	}
	return null;
}
function _JGE(i,d,s,p)
{
	var clElement;
	var isu=i.replace(/_/g, "");
	if (d.getElementById)
	{
		if (!s)
		{
			if (!p)
			{
				clElement = d.getElementById(i);if (clElement) { return clElement; }
				clElement = d.getElementById(i + '_');if (clElement && (d.getElementsByName(i + "_AS").length > 0)) { return clElement; }
			}
			clElement = d.getElementById("tz" + i);if (clElement) { return clElement; }
			clElement = d.getElementById("dz" + i);if (clElement) { return clElement; }
			clElement = d.getElementById("tz" + isu);if (clElement) { return clElement; }
			clElement = d.getElementById("bz" + isu);if (clElement) { return clElement; }
			clElement = d.getElementById("dww" + isu);if (clElement) { return clElement; }
		}
		else
		{
			clElement = d.getElementById("dwwcz" + isu);if (clElement) { return clElement; }
			clElement = d.getElementById("dzcz" + i);if (clElement) { return clElement; }
			clElement = d.getElementById("cz" + i);if (clElement) { return clElement; }
			clElement = d.getElementById("dww" + isu);if (clElement) { return clElement; }
			clElement = d.getElementById("bz" + isu);if (clElement) { return clElement; }
			clElement = d.getElementById("tz" + isu);if (clElement) { return clElement; }
			clElement = d.getElementById("dz" + i);if (clElement) { return clElement; }
			clElement = d.getElementById("ctz" + i);if (clElement) { return clElement; }
			clElement = d.getElementById("con-" + i);if (clElement) { return clElement; }
			clElement = d.getElementById(i + "_HTE");if (clElement) { return clElement; }
			clElement = d.getElementById("tz" + i);if (clElement) { return clElement; }
			clElement = d.getElementById("lz" + i);if (clElement) { return clElement; }
			if (!p)
			{
				clElement = d.getElementById(i + '_');if (clElement && (d.getElementsByName(i + "_AS").length > 0)) { return clElement; }
				clElement = d.getElementById(i);if (clElement) { return clElement; }
			}
		}
	}
	else
	{
		return { style: {} };
	}
}