//#17.00.49.00 WDAnim.js
//VersionVI: 30A170078p
// Le seul support technique disponible pour cette librairie est
// accessible a travers le service "Assistance Directe".

function WDAnim(pfSetProp,nValDebut,nValFin,nType,nCourbe,nDuree,sAliasChamp)
{
	if(pfSetProp!==undefined)
	{
		// Notifie le champ du debut de l'animation
		if(sAliasChamp&&(typeof WDChamp!="undefined"))
		{
			this.m_sAliasChamp=sAliasChamp;
			AppelMethodeChampPtr(this.m_sAliasChamp,WDChamp.prototype.AnimationDebut,[this]);
		}

		this.m_pfSetProp=pfSetProp;
		this.m_nValDebut=nValDebut;
		this.m_nValDelta=nValFin-nValDebut;
		this.m_nDebut=(new Date()).getTime();
		// Centieme de secondes => millisecondes
		this.m_nType=nType;
		switch(nCourbe)
		{
			case this.ms_nCourbeLineaire:
				this.dCourbe=this.dCourbeLineaire;
				break;
			case this.ms_nCourbeAccelere:
				this.dCourbe=this.dCourbeAccelere;
				break;
			default:
			case this.ms_nCourbeDecelere:
				this.dCourbe=this.dCourbeDecelere;
				break;
		}
		this.m_nDuree=nDuree*10;
		this.m_bFini=false;
		var oThis=this;
		this.m_pfCallBack=function() { oThis.vMaj(false,(new Date()).getTime(),false); }
		// Premiere animation
		// Note cette fonction est surchargable dans les classes derivees (!!!)
		// Donc il faut bien faire attention d'appeller le constructeur en dernier dans les constructeurs derives
		this.vMaj(true,this.m_nDebut,false);
	}
};

WDAnim.prototype.ms_nCourbeLineaire=0;
WDAnim.prototype.ms_nCourbeAccelere=1;
WDAnim.prototype.ms_nCourbeDecelere=2;
WDAnim.prototype.ms_nPeriodeMs=25;

// bForceNonFini : indique qu'il faut continuer l'animation (pour les animations avec des sous animations)
WDAnim.prototype.vMaj=function vMaj(bForceNonFini,nTime,bPause)
{
	if(this.m_bFini)
	{
		return;
	}

	// Calcule l'avancement
	var nTemps=nTime-this.m_nDebut;
	var dAvancement=Math.min(1,nTemps/this.m_nDuree);
	if(!bPause)
	{
		this._Maj(dAvancement);
	}

	// Si on n'est pas arrive a la fin
	if((nTemps<this.m_nDuree)||bForceNonFini||bPause)
	{
		// Toutes les 25ms ou le temps restant (si on n'est pas en pause)
		var nTimer=this.ms_nPeriodeMs;
		if(!bPause)
		{
			nTimer=Math.min(nTimer,this.m_nDuree-nTemps);
		}
		//var r=window.requestAnimationFrame||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame||window.oRequestAnimationFrame||window.msRequestAnimationFrame||false;
		//if(r)
		//{
		//r(this.m_pfCallBack);
		//}
		//else
		//{
		this.m_nTimeout=setTimeout(this.m_pfCallBack,nTimer);
		//}
	}
	else
	{
		// Indique que l'animation est finie
		this.vFin();
	}
};

// Effectue le dessin
WDAnim.prototype._Maj=function _Maj(dAvancement)
{
	// Calcule la valeur et l'affiche
	if(this.m_pfSetProp)
	{
		var nVal=this.m_nValDebut+this.dCourbe(dAvancement)*this.m_nValDelta;
		this.m_pfSetProp(nVal);
	}
};

// Annule l'animation
// Ne met PAS dans l'etat final
WDAnim.prototype.vAnnule=function vAnnule()
{
	// Annule le timeout
	clearTimeout(this.m_nTimeout);
	delete this.m_nTimeout;

	// Fin de l'animation
	this.vFin();
};

// Marque la fin de l'animation
WDAnim.prototype.vFin=function vFin()
{
	// Memorise que l'animation est finie
	this.m_bFini=true;
	delete this.m_nTimeout;

	// Notifie le champ de la fin de l'animation (si le champ existe)
	if(this.m_sAliasChamp)
	{
		AppelMethodeChampPtr(this.m_sAliasChamp,WDChamp.prototype.AnimationFin,[this]);
	}
};

WDAnim.prototype.bFini=function bFini()
{
	return this.m_bFini;
};

WDAnim.prototype.dCourbeLineaire=function dCourbeLineaire(dAvancement)
{
	return dAvancement;
};
WDAnim.prototype.dCourbeAccelere=function dCourbeAccelere(dAvancement)
{
	return Math.sin(Math.PI/2*dAvancement);
};
WDAnim.prototype.dCourbeDecelere=function dCourbeDecelere(dAvancement)
{
	return 1-Math.cos(Math.PI/2*dAvancement);
};

function AnimationJoueSurProprieteChamp(nValDebut,nValFin,nDuree,nCourbe,pfSetProp,sAliasChamp)
{
	var nType=0;
	return new WDAnim(pfSetProp,nValDebut,nValFin,nType,nCourbe,nDuree,sAliasChamp);
};

function nHasardMinMax(a,b,f)
{
	var r=a+(Math.random()*(b-a));
	return f?r:Math.round(r);
}

function WDAnimSurImage(oBaliseImg,sImageDebut,nOpaciteDebut,nType,nCourbe,nDuree,sImageFin,sAliasChamp,bPremAffich)
{
	if(oBaliseImg!==undefined)
	{
		while(nType==this.ms_nTypeAleatoire)
		{
			nType=nHasardMinMax(this.ms_nTypeMin,this.ms_nTypeMax);
		}
		if(nType==this.ms_nTypeDeplacementDezoom)
		{
			nType=nHasardMinMax(this.ms_nTypeDeplacementDezoomGauche,this.ms_nTypeDeplacementDezoomBasDroite);
		}
		else if(nType==this.ms_nTypeDeplacement)
		{
			nType=nHasardMinMax(this.ms_nTypeDeplacementGauche,this.ms_nTypeDeplacementBasDroite);
		}
		else if(nType==this.ms_nTypeDezoom)
		{
			nType=nHasardMinMax(this.ms_nTypeDezoomGauche,this.ms_nTypeDezoomCentre);
		}
		this.m_oBaliseImg=oBaliseImg;
		this.m_nOpaciteDebut=nOpaciteDebut;
		this.m_bPremierAffichage=bPremAffich;
		this.m_nX=this.GetX(oBaliseImg);
		this.m_nY=this.GetY(oBaliseImg);
		this.m_nLargeur=this.GetLargeur(oBaliseImg);
		this.m_nHauteur=this.GetHauteur(oBaliseImg);
		var p=oBaliseImg.parentNode;
		this.m_nLargeurVisible=this.GetLargeur(p);
		this.m_nHauteurVisible=this.GetHauteur(p);
		var b=this.b2Image(nType);
		var oDiapo=this.ms_tabDiapo[sAliasChamp];
		var d=this.bGarderImageFin(nType);
		if((oDiapo==null)&&d)
		{
			oDiapo=this.ms_tabDiapo[sAliasChamp]=new WDDiapo();
		}
		this.m_oDiapo=oDiapo;
		var o=(oDiapo!=null);
		if(o&&(oDiapo.m_oDiv!=null))
		{
			this.m_oDiv=oDiapo.m_oDiv;
		}
		else
		{
			this.m_oDiv=document.createElement("div");
			this.SetSuperposable(this.m_oDiv);
			this.m_oDiv.style.overflow="hidden";
			this.AjoutFrere(this.m_oDiv);
			if(o)
			{
				oDiapo.m_oDiv=this.m_oDiv;
			}
		}
		this.SetX(this.m_oDiv,this.m_nX);
		this.SetY(this.m_oDiv,this.m_nY);
		this.SetLargeur(this.m_oDiv,this.m_nLargeur);
		this.SetHauteur(this.m_oDiv,this.m_nHauteur);
		this.m_oBaliseImgTemp=this.oAjoutImageTemp(oBaliseImg,sImageDebut,nOpaciteDebut,nType,this.bImageTempFrere(nType));
		this.m_nDistance=nDuree/4;
		this.m_bFiltre=navigator.userAgent.toLowerCase().indexOf("msie")>=0;
		var i=(o&&(oDiapo.m_oImgTempFin!=null));
		if(i)
		{
			this.SetX(this.m_oBaliseImgTemp,this.GetX(oDiapo.m_oImgTempFin));
			this.SetY(this.m_oBaliseImgTemp,this.GetY(oDiapo.m_oImgTempFin));
			this.SetLargeur(this.m_oBaliseImgTemp,this.GetLargeur(oDiapo.m_oImgTempFin));
			this.SetHauteur(this.m_oBaliseImgTemp,this.GetHauteur(oDiapo.m_oImgTempFin));
			if(this.m_bFiltre)
			{
				this.m_oBaliseImgTemp.style.filter=oDiapo.m_oImgTempFin.style.filter;
			}
		}
		this.m_oBaliseImgTempFin=null;
		this.m_sVisibilite=this.GetVisibilite(oBaliseImg);
		if(b)
		{
			this.m_oBaliseImgTempFin=this.oAjoutImageTemp(oBaliseImg,sImageFin,nOpaciteDebut,nType);
		}
		if(o)
		{
			if(i)
			{
				oDiapo.m_oDiv.removeChild(oDiapo.m_oImgTempFin)
				delete oDiapo.m_oImgTempFin;
				if(oDiapo.m_oCanva!=null)
				{
					oDiapo.m_oDiv.removeChild(oDiapo.m_oCanva);
					delete oDiapo.m_oCanva;
				}
			}
			if(d)
			{
				oDiapo.m_oImgTempFin=this.m_oBaliseImgTempFin;
			}
			else
			{
				delete oDiapo;
				this.ms_tabDiapo[sAliasChamp]=this.m_oDiapo=null;
			}
		}
		SetVisible(this.m_oBaliseImgTemp,true);
		var l=true;
		if(b)
		{
			this.SetVisibilite(oBaliseImg,"hidden");
			switch(nType)
			{
				case this.ms_nTypeDeplacementBas:
				case this.ms_nTypeDeplacementHaut:
					this.SetX(this.m_oBaliseImgTempFin,this.m_nX-Math.max(0,(this.m_nLargeur-this.m_nLargeurVisible)/2));
					break;
				case this.ms_nTypeDeplacementGauche:
				case this.ms_nTypeDeplacementDroite:
					this.SetY(this.m_oBaliseImgTempFin,this.m_nY-Math.max(0,(this.m_nHauteur-this.m_nHauteurVisible)/2));
					break;
				case this.ms_nTypeDezoomPanoramique:
					this.InitZone();
					break;
				case this.ms_nTypeDezoomDeplacement:
					this.m_oCanva=document.createElement("canvas");
					if((this.m_oCanva!=null)&&(this.m_oCanva.getContext!=null))
					{
						this.m_oDC=this.m_oCanva.getContext("2d");
					}
					if(this.m_oDC)
					{
						this.SetSuperposable(this.m_oCanva);
						this.m_oDiv.appendChild(this.m_oCanva);
						if(o)
						{
							oDiapo.m_oCanva=this.m_oCanva;
						}
						this.SetOpacite(this.m_oCanva,nOpaciteDebut)
						this.SetX(this.m_oCanva,this.m_nX);
						this.SetY(this.m_oCanva,this.m_nY);
						SetVisible(this.m_oBaliseImgTempFin,false);
					}
					if(this.bImageCharge(this.m_oBaliseImgTempFin))
					{
						this.InitDimImageTempFin();
					}
					else
					{
						this.m_nType=nType;
						this.m_sAliasChamp=sAliasChamp;
						this.m_nDuree=nDuree;
						var c=nCourbe;
						var oThis=this;
						this.m_oBaliseImgTempFin.onload=function()
						{
							oThis.m_oBaliseImgTempFin.onload=null;
							oThis.InitDimImageTempFin();
							WDAnim.prototype.constructor.apply(oThis,[oThis._fGetAnimFonction(oThis.m_nType),0,oThis.ms_nAvancementMax,oThis.m_nType,c,oThis.m_nDuree,oThis.m_sAliasChamp]);
						};
						l=false;
					}
					break;
				default:
					break;
			}
			if(l)
			{
				SetVisible(this.m_oBaliseImgTempFin,true);
			}
		}
		if(this.ms_nTypeFondu==nType)
		{
			this.SetOpacite(oBaliseImg,0);
		}

		// Appel de la classe de base (lance l'animation)
		if(l)
		{
			WDAnim.prototype.constructor.apply(this,[this._fGetAnimFonction(nType),0,this.ms_nAvancementMax,nType,nCourbe,nDuree,sAliasChamp]);
		}
	}
};

WDAnimSurImage.prototype=new WDAnim();
WDAnimSurImage.prototype.constructor=WDAnimSurImage;

WDAnimSurImage.prototype.ms_nAvancementMax=1000;
WDAnimSurImage.prototype.ms_nTypeMin=1;
WDAnimSurImage.prototype.ms_nTypeFondu=1;
WDAnimSurImage.prototype.ms_nTypeBalayageBas=2;
WDAnimSurImage.prototype.ms_nTypeBalayageHaut=3;
WDAnimSurImage.prototype.ms_nTypeBalayageDroite=4;
WDAnimSurImage.prototype.ms_nTypeBalayageGauche=5;
WDAnimSurImage.prototype.ms_nTypeRecouvrementHaut=6;
WDAnimSurImage.prototype.ms_nTypeRecouvrementBas=7;
WDAnimSurImage.prototype.ms_nTypeRecouvrementGauche=8;
WDAnimSurImage.prototype.ms_nTypeRecouvrementDroite=9;
WDAnimSurImage.prototype.ms_nTypeRecouvrement=10;
WDAnimSurImage.prototype.ms_nTypeRecouvrementZoom=11;
WDAnimSurImage.prototype.ms_nTypeDecouvrement=12;
WDAnimSurImage.prototype.ms_nTypeDecouvrementZoom=13;
WDAnimSurImage.prototype.ms_nTypeAleatoire=14;
WDAnimSurImage.prototype.ms_nTypeDeplacement=44;
WDAnimSurImage.prototype.ms_nTypeDeplacementGauche=16;
WDAnimSurImage.prototype.ms_nTypeDeplacementDroite=17;
WDAnimSurImage.prototype.ms_nTypeDeplacementHaut=18;
WDAnimSurImage.prototype.ms_nTypeDeplacementBas=19;
WDAnimSurImage.prototype.ms_nTypeDeplacementHautGauche=20;
WDAnimSurImage.prototype.ms_nTypeDeplacementHautDroite=21;
WDAnimSurImage.prototype.ms_nTypeDeplacementBasGauche=22;
WDAnimSurImage.prototype.ms_nTypeDeplacementBasDroite=23;
WDAnimSurImage.prototype.ms_nTypeDeplacementDezoomGauche=24;
WDAnimSurImage.prototype.ms_nTypeDeplacementDezoomDroite=25;
WDAnimSurImage.prototype.ms_nTypeDeplacementDezoomHaut=26;
WDAnimSurImage.prototype.ms_nTypeDeplacementDezoomBas=27;
WDAnimSurImage.prototype.ms_nTypeDeplacementDezoomHautGauche=28;
WDAnimSurImage.prototype.ms_nTypeDeplacementDezoomHautDroite=29;
WDAnimSurImage.prototype.ms_nTypeDeplacementDezoomBasGauche=30;
WDAnimSurImage.prototype.ms_nTypeDeplacementDezoomBasDroite=31;
WDAnimSurImage.prototype.ms_nTypeDeplacementDezoom=32;
WDAnimSurImage.prototype.ms_nTypeDezoomGauche=33;
WDAnimSurImage.prototype.ms_nTypeDezoomDroite=34;
WDAnimSurImage.prototype.ms_nTypeDezoomHaut=35;
WDAnimSurImage.prototype.ms_nTypeDezoomBas=36;
WDAnimSurImage.prototype.ms_nTypeDezoomHautGauche=37;
WDAnimSurImage.prototype.ms_nTypeDezoomHautDroite=38;
WDAnimSurImage.prototype.ms_nTypeDezoomBasGauche=39;
WDAnimSurImage.prototype.ms_nTypeDezoomBasDroite=40;
WDAnimSurImage.prototype.ms_nTypeDezoomCentre=41;
WDAnimSurImage.prototype.ms_nTypeDezoom=42;
WDAnimSurImage.prototype.ms_nTypeDezoomPanoramique=43;
WDAnimSurImage.prototype.ms_nTypeDezoomDeplacement=15;
WDAnimSurImage.prototype.ms_nTypeFin=44;
WDAnimSurImage.prototype.ms_nTypeMax=15;
WDAnimSurImage.prototype.ms_nTypeMouvementAutomatique=WDAnimSurImage.prototype.ms_nTypeDezoomDeplacement;
WDAnimSurImage.prototype.ms_tabAnimations=[];
WDAnimSurImage.prototype.ms_nZoom=1;
WDAnimSurImage.prototype.ms_tabDiapo=[];
WDAnimSurImage.prototype.InitDimImageTempFin=function InitDimImageTempFin()
{
	if((!this.m_oDC)&&this.m_bFiltre)
	{
		this.m_oBaliseImgTempFin.style.filter="progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";
	}
	else
	{
		this.SetOpacite(this.m_oBaliseImgTempFin,0);
	}
	SetVisible(this.m_oBaliseImgTempFin,true);
	//this.SetLargeur(this.m_oBaliseImgTempFin,this.GetLargeur(this.m_oBaliseImgTempFin));
	//SetVisible(this.m_oBaliseImgTemp,false);
	if(this.bImageCharge(this.m_oBaliseImgTempFin))
	{
		this.m_nLargeur=this.GetLargeur(this.m_oBaliseImgTempFin);
		this.m_nHauteur=this.GetHauteur(this.m_oBaliseImgTempFin);
	}
	this.SetLargeur(this.m_oDiv,this.m_nLargeur);
	this.SetHauteur(this.m_oDiv,this.m_nHauteur);
	this.InitZone();
	this.InitZone(true);
	if(this.m_oDC)
	{
		this.m_oCanva.width=this.m_nLargeur;
		this.m_oCanva.height=this.m_nHauteur;
		try { this.m_oDC.drawImage(this.m_oBaliseImgTempFin,this.GetX(this.m_oBaliseImgTempFin)-this.m_nX,this.GetY(this.m_oBaliseImgTempFin)-this.m_nY,this.GetLargeur(this.m_oBaliseImgTempFin),this.GetHauteur(this.m_oBaliseImgTempFin)/*,this.m_nLargeur,this.m_nHauteur,0,0,this.m_nLargeur,this.m_nHauteur*/); } catch(e) { };
	}
};

WDAnimSurImage.prototype.nInitZoneCoord=function nInitZoneCoord(d,g,f,i)
{
	return nHasardMinMax((i!=null)?i:0,d*g)*f;
};

WDAnimSurImage.prototype.InitZone1=function InitZone1(b)
{
	var z=nHasardMinMax(0.8,0.9,true);
	var g=1-z;
	var f=1/z;
	var h=f-1;
	if(b)
	{
		this.m_nZoomFin=h;
	}
	else
	{
		this.m_nZoom=h;
	}
	var x=this.nInitZoneCoord(this.m_nLargeur,g,f);
	if(b)
	{
		this.m_nXFin=x;
	}
	else
	{
		this.m_nXDepart=x;
	}
	var i=0;
	if(b)
	{
		var r=(0.05*Math.min(this.m_nLargeur,this.m_nHauteur))-Math.abs(this.m_nZoom-this.m_nZoomFin)*(this.m_nLargeur+this.m_nHauteur)-Math.abs(this.m_nXDepart-this.m_nXFin);
		if(r>0)
		{
			var a=this.m_nYDepart/(1+this.m_nZoom);
			var m=a-r;
			var l=g*this.m_nHauteur;
			var n=l-a-r;
			if(m>n)
			{
				g=m/this.m_nHauteur;
			}
			else
			{
				i=(a+r)/this.m_nHauteur;
			}
		}
		//var trc="zd:"+this.m_nZoom+";zf:"+this.m_nZoomFin+";xd:"+this.m_nXDepart+";xf:"+this.m_nXFin+";l:"+this.m_nLargeur+";h:"+this.m_nHauteur+";min:"+0.05*Math.min(this.m_nLargeur,this.m_nHauteur)+";r:"+r+";yd:"+this.m_nYDepart;
	}
	var y=this.nInitZoneCoord(this.m_nHauteur,g,f,i);
	if(b)
	{
		this.m_nYFin=y;
	}
	else
	{
		this.m_nYDepart=y;
	}
};

WDAnimSurImage.prototype.InitZone2=function InitZone2(b)
{
	var z=nHasardMinMax(0.8,0.9,true);
	var g=1-z;
	var f=1/z;
	var h=f-1;
	if(b)
	{
		this.m_nZoomFin=h;
	}
	else
	{
		this.m_nZoom=h;
	}
	var x=this.nInitZoneCoord(this.m_nLargeur,g,f);
	if(b)
	{
		this.m_nXFin=x;
	}
	else
	{
		this.m_nXDepart=x;
	}
	if(b)
	{
		var r=this.m_nDistance-Math.abs(((this.m_nZoomFin-this.m_nZoom)*(this.m_nLargeur+this.m_nHauteur)/2)+(this.m_nXDepart-this.m_nXFin));
		var l=g*this.m_nHauteur;
		if(r>0)
		{
			var a=this.m_nYDepart/(1+this.m_nZoom);
			var m=a-r;
			var n=l-a-r;
			if(m>n)
			{
				this.m_nYFin=Math.max(m,0);
			}
			else
			{
				this.m_nYFin=Math.min(this.m_nYDepart+r,l);
			}
		}
		else
		{
			this.m_nYFin=Math.min(this.m_nYDepart,l*f);
		}
	}
	else
	{
		this.m_nYDepart=this.nInitZoneCoord(this.m_nHauteur,g,f);
	}
};

WDAnimSurImage.prototype.InitZone3=function InitZone3(b)
{
	var l=0.9;
	if(b)
	{
		var m=Math.sqrt(Math.pow(this.m_nLargeur,2)+Math.pow(this.m_nHauteur,2));
		l=Math.min(l,(this.m_nDistance+m)/m);
	}
	var z=nHasardMinMax(l-0.1,l,true);
	var g=1-z;
	var f=1/z;
	var h=f-1;
	if(b)
	{
		this.m_nZoomFin=h;
		var r=this.m_nDistance;
		var c=Math.acos(Math.max(Math.min(this.m_nXDepart/r,1),-1));
		var d=Math.acos(Math.max(Math.min((this.m_nXDepart-(g*f*this.m_nLargeur))/r,1),-1));
		var e=Math.min(c,d);
		var i=Math.max(c,d);
		c=Math.asin(Math.max(Math.min(-this.m_nYDepart/r,1),-1));
		d=Math.asin(Math.max(Math.min(((g*f*this.m_nHauteur)-this.m_nYDepart)/r,1),-1));
		var j=Math.min(c,d);
		var k=Math.max(c,d);
		c=Math.max(e,j);
		d=Math.min(i,k);
		var a=0;
		if(c>d)
		{
			this.m_nXFin=0;
			this.m_nYFin=0;
		}
		else
		{
			a=nHasardMinMax(c,d,true);
			this.m_nXFin=this.m_nXDepart-(r*Math.cos(a));
			this.m_nYFin=this.m_nYDepart+(r*Math.sin(a));
		}
	}
	else
	{
		this.m_nZoom=h;
		this.m_nXDepart=this.nInitZoneCoord(this.m_nLargeur,g,f);
		this.m_nYDepart=this.nInitZoneCoord(this.m_nHauteur,g,f);
	}
};

WDAnimSurImage.prototype.InitZone4=function InitZone4(b)
{
	var z=nHasardMinMax(0.8,0.9,true);
	var g=1-z;
	var f=1/z;
	var h=f-1;
	if(b)
	{
		this.m_nZoomFin=h;
	}
	else
	{
		this.m_nZoom=h;
	}
	var i=0;
	var l=g;
	if(b&&(this.m_nZoomFin!=this.m_nZoom))
	{
		if(this.m_nZoomFin>this.m_nZoom)
		{
			l=Math.min(g,this.m_nXDepart/f/this.m_nLargeur);
		}
		else
		{
			i=Math.min(g*this.m_nLargeur*f,this.m_nXDepart)/f;
		}
	}
	var x=this.nInitZoneCoord(this.m_nLargeur,l,f,i);
	if(b)
	{
		this.m_nXFin=x;
	}
	else
	{
		this.m_nXDepart=x;
	}
	if(b&&(this.m_nZoomFin!=this.m_nZoom))
	{
		if(this.m_nZoomFin>this.m_nZoom)
		{
			l=Math.min(g,this.m_nYDepart/f/this.m_nHauteur);
		}
		else
		{
			i=Math.min(g*this.m_nHauteur*f,this.m_nYDepart)/f;
		}
	}
	else
	{
		i=0;
		l=g;
	}
	var y=this.nInitZoneCoord(this.m_nHauteur,l,f,i);
	if(b)
	{
		this.m_nYFin=y;
	}
	else
	{
		this.m_nYDepart=y;
	}
};

WDAnimSurImage.prototype.InitZone=function InitZone(b)
{
	var z=nHasardMinMax(0.8,0.9,true);
	var g=1-z;
	var f=1/z;
	var h=f-1;
	if(b)
	{
		this.m_nZoomFin=h;
	}
	else
	{
		this.m_nZoom=h;
	}
	var x=this.nInitZoneCoord(this.m_nLargeur,g,f);
	if(b)
	{
		this.m_nXFin=x;
	}
	else
	{
		this.m_nXDepart=x;
	}
	var y=this.nInitZoneCoord(this.m_nHauteur,g,f);
	if(b)
	{
		this.m_nYFin=y;
	}
	else
	{
		this.m_nYDepart=y;
	}
};

WDAnimSurImage.prototype.InitZone5=function InitZone5(b)
{
	if(b)
	{
		this.m_nZoomFin=0.24223918141145928;
		this.m_nXFin=27.329261991052103;
		this.m_nYFin=1.2422391814114593;
	}
	else
	{
		this.m_nZoom=0.23311965686232106;
		this.m_nXDepart=28.361752107833386;
		this.m_nYDepart=19.729914509797137;
	}
};

// Les fonctions d'animation

WDAnimSurImage.prototype._fGetAnimFonction=function _fGetAnimFonction(nType)
{
	// Note : on ne fait pas une closure, on manipulera donc la fonction actuelle (et pas la fonction de meme nom au moment de l'appel)
	// mais normalement elles ne changent pas
	switch(nType)
	{
		case this.ms_nTypeFondu:
			return this._AnimFondu;
		case this.ms_nTypeBalayageHaut:
			return this._AnimBalayageHaut;
		case this.ms_nTypeBalayageBas:
			return this._AnimBalayageBas;
		case this.ms_nTypeRecouvrementHaut:
			return this._AnimRecouvrementHaut;
		case this.ms_nTypeRecouvrementBas:
			return this._AnimRecouvrementBas;
		case this.ms_nTypeBalayageGauche:
			return this._AnimBalayageGauche;
		case this.ms_nTypeBalayageDroite:
			return this._AnimBalayageDroite;
		case this.ms_nTypeRecouvrementGauche:
			return this._AnimRecouvrementGauche;
		case this.ms_nTypeRecouvrementDroite:
			return this._AnimRecouvrementDroite;
		case this.ms_nTypeRecouvrement:
			return this._AnimRecouvrement;
		case this.ms_nTypeRecouvrementZoom:
			return this._AnimRecouvrementZoom;
		case this.ms_nTypeDecouvrement:
			return this._AnimDecouvrement;
		case this.ms_nTypeDecouvrementZoom:
			return this._AnimDecouvrementZoom;
		case this.ms_nTypeDeplacementHaut:
			return this._AnimDeplacementHaut;
		case this.ms_nTypeDeplacementBas:
			return this._AnimDeplacementBas;
		case this.ms_nTypeDeplacementGauche:
			return this._AnimDeplacementGauche;
		case this.ms_nTypeDeplacementDroite:
			return this._AnimDeplacementDroite;
		case this.ms_nTypeDeplacementHautGauche:
			return this._AnimDeplacementHautGauche;
		case this.ms_nTypeDeplacementHautDroite:
			return this._AnimDeplacementHautDroite;
		case this.ms_nTypeDeplacementBasGauche:
			return this._AnimDeplacementBasGauche;
		case this.ms_nTypeDeplacementBasDroite:
			return this._AnimDeplacementBasDroite;
		case this.ms_nTypeDezoomDroite:
			return this._AnimDezoomDroite;
		case this.ms_nTypeDezoomGauche:
			return this._AnimDezoomGauche;
		case this.ms_nTypeDezoomBas:
			return this._AnimDezoomBas;
		case this.ms_nTypeDezoomHaut:
			return this._AnimDezoomHaut;
		case this.ms_nTypeDezoomBasDroite:
			return this._AnimDezoomBasDroite;
		case this.ms_nTypeDezoomHautGauche:
			return this._AnimDezoomHautGauche;
		case this.ms_nTypeDezoomBasGauche:
			return this._AnimDezoomBasGauche;
		case this.ms_nTypeDezoomHautDroite:
			return this._AnimDezoomHautDroite;
		case this.ms_nTypeDezoomCentre:
			return this._AnimDezoomCentre;
		case this.ms_nTypeDeplacementDezoomGauche:
			return this._AnimDeplacementDezoomGauche;
		case this.ms_nTypeDeplacementDezoomDroite:
			return this._AnimDeplacementDezoomDroite;
		case this.ms_nTypeDeplacementDezoomHaut:
			return this._AnimDeplacementDezoomHaut;
		case this.ms_nTypeDeplacementDezoomBas:
			return this._AnimDeplacementDezoomBas;
		case this.ms_nTypeDeplacementDezoomHautGauche:
			return this._AnimDeplacementDezoomHautGauche;
		case this.ms_nTypeDeplacementDezoomHautDroite:
			return this._AnimDeplacementDezoomHautDroite;
		case this.ms_nTypeDeplacementDezoomBasGauche:
			return this._AnimDeplacementDezoomBasGauche;
		case this.ms_nTypeDeplacementDezoomBasDroite:
			return this._AnimDeplacementDezoomBasDroite;
		case this.ms_nTypeDezoomPanoramique:
			return this._AnimDezoomPanoramique;
		case this.ms_nTypeDezoomDeplacement:
			return this._AnimDezoomDeplacement;
		default:
			return undefined;
	}
};

WDAnimSurImage.prototype._AnimFondu=function _AnimFondu(nAvancement)
{
	this.SetOpacite(this.m_oBaliseImg,this.__nAvancement(nAvancement,this.m_nOpaciteDebut));
	this.SetOpacite(this.m_oBaliseImgTemp,this.__nAvancementInverse(nAvancement,this.m_nOpaciteDebut));
};

WDAnimSurImage.prototype._AnimBalayageHaut=function _AnimBalayageHaut(nAvancement)
{
	this.__AnimBalayageVertical(nAvancement,false);
};

WDAnimSurImage.prototype._AnimBalayageBas=function _AnimBalayageBas(nAvancement)
{
	this.__AnimBalayageVertical(nAvancement,true);
};

WDAnimSurImage.prototype.__AnimBalayageVertical=function __AnimBalayageVertical(nAvancement,bBas)
{
	this.SetY(this.m_oBaliseImgTemp,this.m_nY+this.__nAvancement(nAvancement,this.m_nHauteur)*(bBas?1:-1));
	this.__AnimRecouvrementVertical(nAvancement,!bBas);
};

WDAnimSurImage.prototype._AnimRecouvrementHaut=function _AnimRecouvrementHaut(nAvancement)
{
	this.__AnimRecouvrementVertical(nAvancement,false);
};

WDAnimSurImage.prototype._AnimRecouvrementBas=function _AnimRecouvrementBas(nAvancement)
{
	this.__AnimRecouvrementVertical(nAvancement,true);
};

WDAnimSurImage.prototype.__AnimRecouvrementVertical=function __AnimRecouvrementVertical(nAvancement,bBas)
{
	this.SetY(this.m_oBaliseImgTempFin,this.m_nY+this.__nAvancementInverse(nAvancement,this.m_nHauteur)*(bBas?1:-1));
};

WDAnimSurImage.prototype._AnimBalayageGauche=function _AnimBalayageGauche(nAvancement)
{
	this.__AnimBalayageHorizontal(nAvancement,false);
};

WDAnimSurImage.prototype._AnimBalayageDroite=function _AnimBalayageDroite(nAvancement)
{
	this.__AnimBalayageHorizontal(nAvancement,true);
};

WDAnimSurImage.prototype.__AnimBalayageHorizontal=function __AnimBalayageHorizontal(nAvancement,bDroite)
{
	this.SetX(this.m_oBaliseImgTemp,this.m_nX+this.__nAvancement(nAvancement,this.m_nLargeur)*(bDroite?1:-1));
	this.__AnimRecouvrementHorizontal(nAvancement,!bDroite);
};

WDAnimSurImage.prototype._AnimRecouvrementGauche=function _AnimRecouvrementGauche(nAvancement)
{
	this.__AnimRecouvrementHorizontal(nAvancement,false);
};

WDAnimSurImage.prototype._AnimRecouvrementDroite=function _AnimRecouvrementDroite(nAvancement)
{
	this.__AnimRecouvrementHorizontal(nAvancement,true);
};

WDAnimSurImage.prototype.__AnimRecouvrementHorizontal=function __AnimRecouvrementHorizontal(nAvancement,bDroite)
{
	this.SetX(this.m_oBaliseImgTempFin,this.m_nX+this.__nAvancementInverse(nAvancement,this.m_nLargeur)*(bDroite?1:-1));
};

WDAnimSurImage.prototype._AnimRecouvrement=function _AnimRecouvrement(nAvancement)
{
	this.__AnimXXcouvrementInterne(this.__nAvancementInverseVal(nAvancement),this.m_oDiv);
	this.SetX(this.m_oBaliseImgTempFin,this.m_nX);
	this.SetY(this.m_oBaliseImgTempFin,this.m_nY);
};

WDAnimSurImage.prototype._AnimRecouvrementZoom=function _AnimRecouvrementZoom(nAvancement)
{
	this.__AnimXXcouvrementInterne(this.__nAvancementInverseVal(nAvancement),this.m_oBaliseImgTempFin);
};

WDAnimSurImage.prototype._AnimDecouvrement=function _AnimDecouvrement(nAvancement)
{
	this.__AnimXXcouvrementInterne(nAvancement,this.m_oDiv);
	this.SetX(this.m_oBaliseImgTemp,this.m_nX);
	this.SetY(this.m_oBaliseImgTemp,this.m_nY);
};

WDAnimSurImage.prototype._AnimDecouvrementZoom=function _AnimDecouvrementZoom(nAvancement)
{
	this.__AnimXXcouvrementInterne(nAvancement,this.m_oBaliseImgTemp);
};

WDAnimSurImage.prototype._AnimDeplacementOpacite=function _AnimDeplacementOpacite(nAvancement)
{
	this.SetOpacite(this.m_oBaliseImgTempFin,this.__nAvancement(Math.min(3*nAvancement,this.ms_nAvancementMax),this.m_nOpaciteDebut));
};

WDAnimSurImage.prototype._AnimDeplacementHaut=function _AnimDeplacementHaut(nAvancement)
{
	this._AnimDeplacementOpacite(nAvancement);
	if(this.m_nHauteur>this.m_nHauteurVisible)
	{
		this.SetY(this.m_oBaliseImgTempFin,this.m_nY-this.__nAvancementInverse(nAvancement,this.m_nHauteur-this.m_nHauteurVisible));
	}
};

WDAnimSurImage.prototype._AnimDeplacementBas=function _AnimDeplacementBas(nAvancement)
{
	this._AnimDeplacementOpacite(nAvancement);
	if(this.m_nHauteur>this.m_nHauteurVisible)
	{
		this.SetY(this.m_oBaliseImgTempFin,this.m_nY-this.__nAvancement(nAvancement,this.m_nHauteur-this.m_nHauteurVisible));
	}
};

WDAnimSurImage.prototype._AnimDeplacementGaucheX=function _AnimDeplacementGaucheX(nAvancement)
{
	if(this.m_nLargeur>this.m_nLargeurVisible)
	{
		this.SetX(this.m_oBaliseImgTempFin,this.m_nX-this.__nAvancementInverse(nAvancement,this.m_nLargeur-this.m_nLargeurVisible));
	}
};

WDAnimSurImage.prototype._AnimDeplacementGauche=function _AnimDeplacementGauche(nAvancement)
{
	this._AnimDeplacementOpacite(nAvancement);
	this._AnimDeplacementGaucheX(nAvancement);
};

WDAnimSurImage.prototype._AnimDeplacementDroiteX=function _AnimDeplacementDroiteX(nAvancement)
{
	if(this.m_nLargeur>this.m_nLargeurVisible)
	{
		this.SetX(this.m_oBaliseImgTempFin,this.m_nX-this.__nAvancement(nAvancement,this.m_nLargeur-this.m_nLargeurVisible));
	}
};

WDAnimSurImage.prototype._AnimDeplacementDroite=function _AnimDeplacementDroite(nAvancement)
{
	this._AnimDeplacementOpacite(nAvancement);
	this._AnimDeplacementDroiteX(nAvancement);
};

WDAnimSurImage.prototype._AnimDeplacementHautGauche=function _AnimDeplacementHautGauche(nAvancement)
{
	this._AnimDeplacementHaut(nAvancement);
	this._AnimDeplacementGaucheX(nAvancement);
};

WDAnimSurImage.prototype._AnimDeplacementHautDroite=function _AnimDeplacementHautDroite(nAvancement)
{
	this._AnimDeplacementHaut(nAvancement);
	this._AnimDeplacementDroiteX(nAvancement);
};

WDAnimSurImage.prototype._AnimDeplacementBasGauche=function _AnimDeplacementBasGauche(nAvancement)
{
	this._AnimDeplacementBas(nAvancement);
	this._AnimDeplacementGaucheX(nAvancement);
};

WDAnimSurImage.prototype._AnimDeplacementBasDroite=function _AnimDeplacementBasDroite(nAvancement)
{
	this._AnimDeplacementBas(nAvancement);
	this._AnimDeplacementDroiteX(nAvancement);
};

WDAnimSurImage.prototype._nAnimDezoomDimension=function _nAnimDezoomDimension(nAvancement,nDimension)
{
	return this.__nAvancementInverse(nAvancement,nDimension*this.ms_nZoom);
};

WDAnimSurImage.prototype._nAnimDezoomLargeur=function _nAnimDezoomLargeur(nAvancement)
{
	return this._nAnimDezoomDimension(nAvancement,this.m_nLargeur);
};

WDAnimSurImage.prototype._nAnimDezoomHauteur=function _nAnimDezoomHauteur(nAvancement)
{
	return this._nAnimDezoomDimension(nAvancement,this.m_nHauteur);
};

WDAnimSurImage.prototype._AnimDezoomBasDroite=function _AnimDezoomBasDroite(nAvancement)
{
	this._AnimDeplacementOpacite(nAvancement);
	this.SetLargeur(this.m_oBaliseImgTempFin,this.m_nLargeur+this._nAnimDezoomLargeur(nAvancement));
	this.SetHauteur(this.m_oBaliseImgTempFin,this.m_nHauteur+this._nAnimDezoomHauteur(nAvancement));
};

WDAnimSurImage.prototype._AnimDezoomGaucheX=function _AnimDezoomGaucheX(nAvancement)
{
	this.SetX(this.m_oBaliseImgTempFin,this.m_nX-this._nAnimDezoomLargeur(nAvancement));
};

WDAnimSurImage.prototype._AnimDezoomVertical=function _AnimDezoomVertical(nAvancement)
{
	this.SetY(this.m_oBaliseImgTempFin,this.m_nY-(this._nAnimDezoomHauteur(nAvancement)/2));
};

WDAnimSurImage.prototype._AnimDezoomGauche=function _AnimDezoomGauche(nAvancement)
{
	this._AnimDezoomGaucheX(nAvancement);
	this._AnimDezoomVertical(nAvancement);
	this._AnimDezoomBasDroite(nAvancement);
};

WDAnimSurImage.prototype._AnimDezoomDroite=function _AnimDezoomDroite(nAvancement)
{
	this._AnimDezoomVertical(nAvancement);
	this._AnimDezoomBasDroite(nAvancement);
};

WDAnimSurImage.prototype._AnimDezoomHautY=function _AnimDezoomHautY(nAvancement)
{
	this.SetY(this.m_oBaliseImgTempFin,this.m_nY-this._nAnimDezoomHauteur(nAvancement));
};

WDAnimSurImage.prototype._AnimDezoomHorizontal=function _AnimDezoomHorizontal(nAvancement)
{
	this.SetX(this.m_oBaliseImgTempFin,this.m_nX-(this._nAnimDezoomLargeur(nAvancement)/2));
};

WDAnimSurImage.prototype._AnimDezoomHaut=function _AnimDezoomHaut(nAvancement)
{
	this._AnimDezoomHorizontal(nAvancement);
	this._AnimDezoomHautY(nAvancement);
	this._AnimDezoomBasDroite(nAvancement);
};

WDAnimSurImage.prototype._AnimDezoomBas=function _AnimDezoomBas(nAvancement)
{
	this._AnimDezoomHorizontal(nAvancement);
	this._AnimDezoomBasDroite(nAvancement);
};

WDAnimSurImage.prototype._AnimDezoomHautGauche=function _AnimDezoomHautGauche(nAvancement)
{
	this._AnimDezoomGaucheX(nAvancement);
	this._AnimDezoomHautY(nAvancement);
	this._AnimDezoomBasDroite(nAvancement);
};

WDAnimSurImage.prototype._AnimDezoomBasGauche=function _AnimDezoomBasGauche(nAvancement)
{
	this._AnimDezoomGaucheX(nAvancement);
	this._AnimDezoomBasDroite(nAvancement);
};

WDAnimSurImage.prototype._AnimDezoomHautDroite=function _AnimDezoomHautDroite(nAvancement)
{
	this._AnimDezoomHautY(nAvancement);
	this._AnimDezoomBasDroite(nAvancement);
};

WDAnimSurImage.prototype._AnimDezoomCentre=function _AnimDezoomCentre(nAvancement)
{
	this._AnimDezoomHorizontal(nAvancement);
	this._AnimDezoomVertical(nAvancement);
	this._AnimDezoomBasDroite(nAvancement);
};

WDAnimSurImage.prototype._AnimDeplacementDezoomY=function _AnimDeplacementDezoomY(nAvancement)
{
	this.SetY(this.m_oBaliseImgTempFin,this.m_nY-this.__nAvancementInverse(nAvancement,this.m_nHauteur*this.ms_nZoom/2));
	this._AnimDezoomBasDroite(nAvancement);
};

WDAnimSurImage.prototype._AnimDeplacementDezoomX=function _AnimDeplacementDezoomX(nAvancement)
{
	this.SetX(this.m_oBaliseImgTempFin,this.m_nX-this.__nAvancementInverse(nAvancement,this.m_nLargeur*this.ms_nZoom/2));
	this._AnimDezoomBasDroite(nAvancement);
};

WDAnimSurImage.prototype._nAnimDeplacementDezoomAngle=function _nAnimDeplacementDezoomAngle(nAvancement)
{
	return (Math.PI/2)*(nAvancement/this.ms_nAvancementMax);
};

WDAnimSurImage.prototype._AnimDeplacementDezoomGaucheX=function _AnimDeplacementDezoomGaucheX(nAvancement)
{
	this.SetX(this.m_oBaliseImgTempFin,this.m_nX-(this._nAnimDezoomLargeur(nAvancement)*Math.sin(this._nAnimDeplacementDezoomAngle(nAvancement))));
};

WDAnimSurImage.prototype._AnimDeplacementDezoomGauche=function _AnimDeplacementDezoomGauche(nAvancement)
{
	this._AnimDeplacementDezoomGaucheX(nAvancement);
	this._AnimDeplacementDezoomY(nAvancement);
};

WDAnimSurImage.prototype._AnimDeplacementDezoomDroiteX=function _AnimDeplacementDezoomDroiteX(nAvancement)
{
	this.SetX(this.m_oBaliseImgTempFin,this.m_nX-(this._nAnimDezoomLargeur(nAvancement)*Math.cos(this._nAnimDeplacementDezoomAngle(nAvancement))));
};

WDAnimSurImage.prototype._AnimDeplacementDezoomDroite=function _AnimDeplacementDezoomDroite(nAvancement)
{
	this._AnimDeplacementDezoomDroiteX(nAvancement);
	this._AnimDeplacementDezoomY(nAvancement);
};

WDAnimSurImage.prototype._AnimDeplacementDezoomHautY=function _AnimDeplacementDezoomHautY(nAvancement)
{
	this.SetY(this.m_oBaliseImgTempFin,this.m_nY-(this._nAnimDezoomHauteur(nAvancement)*Math.sin(this._nAnimDeplacementDezoomAngle(nAvancement))));
};

WDAnimSurImage.prototype._AnimDeplacementDezoomHaut=function _AnimDeplacementDezoomHaut(nAvancement)
{
	this._AnimDeplacementDezoomX(nAvancement);
	this._AnimDeplacementDezoomHautY(nAvancement);
};

WDAnimSurImage.prototype._AnimDeplacementDezoomBasY=function _AnimDeplacementDezoomBasY(nAvancement)
{
	this.SetY(this.m_oBaliseImgTempFin,this.m_nY-(this._nAnimDezoomHauteur(nAvancement)*Math.cos(this._nAnimDeplacementDezoomAngle(nAvancement))));
};

WDAnimSurImage.prototype._AnimDeplacementDezoomBas=function _AnimDeplacementDezoomBas(nAvancement)
{
	this._AnimDeplacementDezoomX(nAvancement);
	this._AnimDeplacementDezoomBasY(nAvancement);
};

WDAnimSurImage.prototype._AnimDeplacementDezoomHautGauche=function _AnimDeplacementDezoomHautGauche(nAvancement)
{
	this._AnimDeplacementDezoomGaucheX(nAvancement);
	this._AnimDeplacementDezoomHautY(nAvancement);
	this._AnimDezoomBasDroite(nAvancement);
};

WDAnimSurImage.prototype._AnimDeplacementDezoomHautDroite=function _AnimDeplacementDezoomHautDroite(nAvancement)
{
	this._AnimDeplacementDezoomDroiteX(nAvancement);
	this._AnimDeplacementDezoomHautY(nAvancement);
	this._AnimDezoomBasDroite(nAvancement);
};

WDAnimSurImage.prototype._AnimDeplacementDezoomBasGauche=function _AnimDeplacementDezoomBasGauche(nAvancement)
{
	this._AnimDeplacementDezoomGaucheX(nAvancement);
	this._AnimDeplacementDezoomBasY(nAvancement);
	this._AnimDezoomBasDroite(nAvancement);
};

WDAnimSurImage.prototype._AnimDeplacementDezoomBasDroite=function _AnimDeplacementDezoomBasDroite(nAvancement)
{
	this._AnimDeplacementDezoomDroiteX(nAvancement);
	this._AnimDeplacementDezoomBasY(nAvancement);
	this._AnimDezoomBasDroite(nAvancement);
};

WDAnimSurImage.prototype.nAnimDezoomPanoramiqueCoord=function nAnimDezoomPanoramiqueCoord(nAvancement,c,d)
{
	return c-this.__nAvancementInverse(nAvancement,d);
};

WDAnimSurImage.prototype.nAnimDezoomPanoramiqueDimension=function nAnimDezoomPanoramiqueDimension(nAvancement,d)
{
	return d+this.__nAvancementInverse(nAvancement,d*this.m_nZoom);
};

WDAnimSurImage.prototype._AnimDezoomPanoramique=function _AnimDezoomPanoramique(nAvancement)
{
	this.SetX(this.m_oBaliseImgTempFin,this.nAnimDezoomPanoramiqueCoord(nAvancement,this.m_nX,this.m_nXDepart));
	this.SetY(this.m_oBaliseImgTempFin,this.nAnimDezoomPanoramiqueCoord(nAvancement,this.m_nY,this.m_nYDepart));
	this.SetLargeur(this.m_oBaliseImgTempFin,this.nAnimDezoomPanoramiqueDimension(nAvancement,this.m_nLargeur));
	this.SetHauteur(this.m_oBaliseImgTempFin,this.nAnimDezoomPanoramiqueDimension(nAvancement,this.m_nHauteur));
};

WDAnimSurImage.prototype.nAnimDezoomDeplacementCoord=function nAnimDezoomDeplacementCoord(nAvancement,c,d,f)
{
	return c-f-this.__nAvancementInverse(nAvancement,d-f);
};

WDAnimSurImage.prototype.nAnimDezoomDeplacementDimension=function nAnimDezoomDeplacementDimension(nAvancement,d)
{
	return (d*(1+this.m_nZoomFin))+this.__nAvancementInverse(nAvancement,d*(this.m_nZoom-this.m_nZoomFin));
};

WDAnimSurImage.prototype._AnimDezoomDeplacement=function _AnimDezoomDeplacement(nAvancement)
{
	if(this.m_bPremierAffichage)
	{
		this.SetOpacite(this.m_oBaliseImgTempFin,this.m_nOpaciteDebut);
		this.SetOpacite(this.m_oBaliseImg,this.m_nOpaciteDebut);
	}
	else
	{
		this._AnimDeplacementOpacite(nAvancement);
	}
	var x=this.nAnimDezoomDeplacementCoord(nAvancement,this.m_nX,this.m_nXDepart,this.m_nXFin);
	var y=this.nAnimDezoomDeplacementCoord(nAvancement,this.m_nY,this.m_nYDepart,this.m_nYFin);
	var l=this.nAnimDezoomDeplacementDimension(nAvancement,this.m_nLargeur);
	var h=this.nAnimDezoomDeplacementDimension(nAvancement,this.m_nHauteur);
	if(this.m_oDC||(!this.m_bFiltre))
	{
		this.SetX(this.m_oBaliseImgTempFin,x);
		this.SetY(this.m_oBaliseImgTempFin,y);
		this.SetLargeur(this.m_oBaliseImgTempFin,l);
		this.SetHauteur(this.m_oBaliseImgTempFin,h);
		if(this.m_oDC)
		{
			this.SetOpacite(this.m_oCanva,this.__nAvancement(Math.min(3*nAvancement,this.ms_nAvancementMax),this.m_nOpaciteDebut));
			try { this.m_oDC.drawImage(this.m_oBaliseImgTempFin,x-this.m_nX,y-this.m_nY,l,h/*,this.m_nLargeur,this.m_nHauteur,0,0,this.m_nLargeur,this.m_nHauteur*/); } catch(e) { };
		}
	}
	else
	{
		this.m_oBaliseImgTempFin.style.filter="progid:DXImageTransform.Microsoft.Alpha(Opacity="+this.GetOpacite(this.m_oBaliseImgTempFin)+') progid:DXImageTransform.Microsoft.Matrix(FilterType="bilinear",M11='+(l/this.m_nLargeur)+",M12=0,M21=0,M22="+(h/this.m_nHauteur)+",Dx="+(x-this.m_nX)+",Dy="+(y-this.m_nY)+")";
		//this.m_oBaliseImgTempFin.style.zIndex=1000;
		//SetVisible(this.m_oBaliseImgTempFin,true);
		//this.SetLargeur(this.m_oBaliseImgTempFin,this.GetLargeur(this.m_oBaliseImgTempFin));
	}
};

// Code interne pour le Recouvrement/Decouvrement
// Donner Max-Avancement pour le recouvrement
WDAnimSurImage.prototype.__AnimXXcouvrementInterne=function __AnimXXcouvrementInterne(nAvancement,oCible)
{
	this.SetX(oCible,this.m_nX+this.__nAvancement(nAvancement,this.m_nLargeur)/2);
	this.SetY(oCible,this.m_nY+this.__nAvancement(nAvancement,this.m_nHauteur)/2);
	this.SetLargeur(oCible,this.__nAvancementInverse(nAvancement,this.m_nLargeur));
	this.SetHauteur(oCible,this.__nAvancementInverse(nAvancement,this.m_nHauteur));
};

WDAnimSurImage.prototype.__nAvancement=function __nAvancement(nAvancement,nValeur)
{
	return (nValeur*nAvancement/this.ms_nAvancementMax);
};

WDAnimSurImage.prototype.__nAvancementInverse=function __nAvancementInverse(nAvancement,nValeur)
{
	return this.__nAvancement(this.__nAvancementInverseVal(nAvancement),nValeur);
};

WDAnimSurImage.prototype.__nAvancementInverseVal=function __nAvancementInverseVal(nAvancement)
{
	return (this.ms_nAvancementMax-nAvancement);
};

// Les fonctions de manipulation des proprietes

// Opacite
WDAnimSurImage.prototype.GetOpacite=function GetOpacite(oBaliseImg)
{
	return _JCPOR(oBaliseImg.style.opacity,oBaliseImg);
};
WDAnimSurImage.prototype.SetOpacite=function SetOpacite(oBaliseImg,nVal)
{
	oBaliseImg.style.opacity=_JCPO(nVal,oBaliseImg);
};

// X
WDAnimSurImage.prototype.GetX=function GetX(oBaliseImg)
{
	return _JCCP(oBaliseImg.offsetLeft,oBaliseImg,true,true);
};
WDAnimSurImage.prototype.SetX=function SetX(oBaliseImg,nVal)
{
	oBaliseImg.style.left=_JCCP(nVal,oBaliseImg,true,false)+"px";
};

// Y
WDAnimSurImage.prototype.GetY=function GetY(oBaliseImg)
{
	return _JCCP(oBaliseImg.offsetTop,oBaliseImg,false,true);
};
WDAnimSurImage.prototype.SetY=function SetY(oBaliseImg,nVal)
{
	oBaliseImg.style.top=_JCCP(nVal,oBaliseImg,false,false)+"px";
};

// Largeur
WDAnimSurImage.prototype.GetLargeur=function GetLargeur(oBaliseImg)
{
	return oBaliseImg.offsetWidth;
};
WDAnimSurImage.prototype.SetLargeur=function SetLargeur(oBaliseImg,nVal)
{
	oBaliseImg.style.width=nVal+"px";
};

// Hauteur
WDAnimSurImage.prototype.GetHauteur=function GetHauteur(oBaliseImg)
{
	return oBaliseImg.offsetHeight;
};
WDAnimSurImage.prototype.SetHauteur=function SetHauteur(oBaliseImg,nVal)
{
	oBaliseImg.style.height=nVal+"px";
};

// Visibilite
WDAnimSurImage.prototype.GetVisibilite=function GetVisibilite(oBaliseImg)
{
	return oBaliseImg.style.visibility;
};
WDAnimSurImage.prototype.SetVisibilite=function SetVisibilite(oBaliseImg,sVal)
{
	oBaliseImg.style.visibility=sVal;
};

// Superposable
WDAnimSurImage.prototype.SetSuperposable=function SetSuperposable(oBalise)
{
	oBalise.style.position="absolute";
};

WDAnimSurImage.prototype.bClip=function bClip(o)
{
	return (o!=null)&&(_JGCS(o).overflow=="hidden");
};

WDAnimSurImage.prototype.bImageCharge=function bImageCharge(i)
{
	if(i.readyState!=null)
	{
		return i.readyState=="complete";
	}
	return i.complete;
};

WDAnimSurImage.prototype.sBalise=function sBalise(n)
{
	return ((n==null)||(n.nodeName==null))?"":n.nodeName.toLowerCase();
};

WDAnimSurImage.prototype.b2Image=function b2Image(nType)
{
	return ((nType>this.ms_nTypeFondu)&&(nType<this.ms_nTypeDecouvrement))||((nType>=this.ms_nTypeMax)&&(nType<=this.ms_nTypeFin));
};

WDAnimSurImage.prototype.bDeplacement=function bDeplacement(nType)
{
	return (nType>=this.ms_nTypeDeplacementGauche)&&(nType<=this.ms_nTypeDeplacementBasDroite);
};

WDAnimSurImage.prototype.bGarderImageFin=function bGarderImageFin(nType)
{
	return this.bDeplacement(nType)||(nType==this.ms_nTypeDezoomDeplacement);
};

WDAnimSurImage.prototype.bImageTempFrere=function bImageTempFrere(nType)
{
	return (nType==this.ms_nTypeRecouvrement);
};

WDAnimSurImage.prototype.AjoutFrere=function AjoutFrere(oBalise)
{
	if(this.m_oBaliseImg.nextSibling)
	{
		this.m_oBaliseImg.parentNode.insertBefore(oBalise,this.m_oBaliseImg.nextSibling);
	}
	else
	{
		this.m_oBaliseImg.parentNode.appendChild(oBalise);
	}
};

WDAnimSurImage.prototype.oAjoutImageTemp=function oAjoutImageTemp(oBaliseImg,sImage,nOpacite,nType,bFrere)
{
	var oBaliseImgTemp=new Image();
	this.SetSuperposable(oBaliseImgTemp);
	SetVisible(oBaliseImgTemp,false);
	if(bFrere)
	{
		this.AjoutFrere(oBaliseImgTemp);
		this.SetX(oBaliseImgTemp,this.m_nX);
		this.SetY(oBaliseImgTemp,this.m_nY);
	}
	else
	{
		this.m_oDiv.appendChild(oBaliseImgTemp);
	}
	oBaliseImgTemp.src=sImage;
	oBaliseImgTemp.style.border="0";
	var l=this.GetLargeur(oBaliseImgTemp);
	var h=this.GetHauteur(oBaliseImgTemp);
	if((nType!=this.ms_nTypeDezoomDeplacement)||((this.m_oBaliseImg.outerHTML!=null)?(this.m_oBaliseImg.outerHTML.indexOf("width=")>=0):((this.m_oBaliseImg.attributes!=null)&&(this.m_oBaliseImg.attributes["width"]!=null))))
	{
		this.SetLargeur(oBaliseImgTemp,this.m_nLargeur);
		this.SetHauteur(oBaliseImgTemp,this.m_nHauteur);
	}
	if((nOpacite<100)&&(nType!=this.ms_nTypeDecouvrement))
	{
		this.SetOpacite(oBaliseImgTemp,nOpacite);
	}
	if(this.bDeplacement(nType)&&(this.m_oBaliseImgTemp!=null))
	{
		var z=1.2;
		var f=Math.max((this.m_nLargeurVisible*z)/l,(this.m_nHauteurVisible*z)/h);
		this.m_nLargeur=l*f;
		this.m_nHauteur=h*f;
		this.SetLargeur(oBaliseImgTemp,this.m_nLargeur);
		this.SetHauteur(oBaliseImgTemp,this.m_nHauteur);
	}

	// Copie si besoin le handler de menu contextuel (pour l'option qui protege contre la sauvegarde directe de l'image)
	if(oBaliseImg.oncontextmenu)
	{
		oBaliseImgTemp.oncontextmenu=clWDUtil.bStopPropagation;
	}

	return oBaliseImgTemp;
};

WDAnimSurImage.prototype.vFin=function vFin()
{
	if(this.b2Image(this.m_nType))
	{
		this.SetVisibilite(this.m_oBaliseImg,this.m_sVisibilite);
	}
	// Supprime l'image temporaire du document
	if(this.m_oBaliseImgTemp!=null)
	{
		(this.bImageTempFrere(this.m_nType)?this.m_oBaliseImg.parentNode:this.m_oDiv).removeChild(this.m_oBaliseImgTemp);
		delete this.m_oBaliseImgTemp;
	}
	if(this.m_oDiapo==null)
	{
		this.m_oDiv.parentNode.removeChild(this.m_oDiv);
		delete this.m_oDiv;
		if(this.m_oBaliseImgTempFin!=null)
		{
			delete this.m_oBaliseImgTempFin;
		}
		if(this.m_oCanva!=null)
		{
			delete this.m_oCanva;
		}
	}

	// Supprime l'animation du tableau
	delete this.ms_tabAnimations[this.m_sAliasChamp];

	// Appel de la classe de base
	WDAnim.prototype.vFin.apply(this,arguments);
};

function sAnimationJoueSurImage(sValeur,oImage,sImageDebut,nOpaciteDebut,nType,nCourbe,nDuree,sAliasChamp,bPremAffich)
{
	// Dans le cas des images avec transition et defilement automatique, il y a un probleme de reentrance s'il y a deja une animation
	// sAnimationJoueSurImage => _vAnnule => vFin (qui se supprime du tableau) => vFin => AnimationFin => _vAnimationFin => __AfficheImage => fonction de set => sAnimationJoueSurImage
	// On bloque donc via une marque dans la fonction
	if(sAnimationJoueSurImage.prototype.ms_tabAntiReentrance[sAliasChamp]!==undefined)
	{
		return;
	}
	// La marque est place dans un try avec finally pour etre sur de bien supprimer la marque en cas d'erreur
	try
	{
		sAnimationJoueSurImage.prototype.ms_tabAntiReentrance[sAliasChamp]=true;

		// Si on a deja une animation sur l'image, la termine
		var oAnimationOld=WDAnimSurImage.prototype.ms_tabAnimations[sAliasChamp];
		if(oAnimationOld)
		{
			nOpaciteDebut=oAnimationOld.m_nOpaciteDebut;
			// Force un dernier dessin puis annule
			if(nType!=WDAnimSurImage.prototype.ms_nTypeMouvementAutomatique)
			{
				oAnimationOld._Maj(1);
			}
			oAnimationOld.vAnnule();
		}
		// Lance l'animation
		WDAnimSurImage.prototype.ms_tabAnimations[sAliasChamp]=new WDAnimSurImage(oImage,sImageDebut,nOpaciteDebut,nType,nCourbe,nDuree,sValeur,sAliasChamp,bPremAffich);
		// Et retourne la valeur (pour le .src)
		return sValeur;
	}
	finally
	{
		delete sAnimationJoueSurImage.prototype.ms_tabAntiReentrance[sAliasChamp];
	}
};
sAnimationJoueSurImage.prototype.ms_tabAntiReentrance=[];

function SetVisible(o,v)
{
	WDAnimSurImage.prototype.SetVisibilite(o,v?"visible":"hidden");
}

function oCreerDivSuperposable(p,o,i)
{
	var oDiv=document.createElement("div");
	WDAnimSurImage.prototype.SetSuperposable(oDiv);
	if(o)
	{
		oDiv.style.overflow="hidden";
	}
	if(i)
	{
		SetVisible(oDiv,false);
	}
	p.appendChild(oDiv);
	WDAnimSurImage.prototype.SetX(oDiv,0);
	WDAnimSurImage.prototype.SetY(oDiv,0);
	return oDiv;
}

function WDDiapo()
{
	this.m_oDiv=null;
	this.m_oImgTempFin=null;
	this.m_oCanva=null;
}

function WDImageAnim(a,d)
{
	this.m_oImg=_JGEN(a,document,false);
	this.m_nOpaciteDebut=WDAnimSurImage.prototype.GetOpacite(this.m_oImg);
	WDAnimSurImage.prototype.SetOpacite(this.m_oImg,0);
	this.m_nDuree=d;
	this.m_sAlias=a;
	var oImgAnim=this;
	this.m_pfCallBack=function() { oImgAnim.Maj(); }
	this.Maj();
};

WDImageAnim.prototype.Maj=function Maj()
{
	var t=100;
	if(WDAnimSurImage.prototype.ms_tabAnimations[this.m_sAlias]==null)
	{
		sAnimationJoueSurImage(this.m_oImg.src,this.m_oImg,this.m_oImg.src,this.m_nOpaciteDebut,WDAnimSurImage.prototype.ms_nTypeMouvementAutomatique,0,this.m_nDuree,this.m_sAlias,true);
		t=this.m_nDuree*10;
	}
	setTimeout(this.m_pfCallBack,t);
};

WDImageZoom.prototype.ms_nPositionGauche=0;
WDImageZoom.prototype.ms_nPositionDroite=1;
WDImageZoom.prototype.ms_nPositionHaut=2;
WDImageZoom.prototype.ms_nPositionBas=3;
WDImageZoom.prototype.ms_nNbPosition=4;

function WDImageZoom(a,z,i,j,v,h,d,b,x)
{
	this.m_oObjet=document.getElementById(a);
	if(this.m_oObjet==null)
	{
		this.m_oObjet=document.getElementsByName(a)[0];
	}
	this.m_sSourceImageVignette=h;
	this.m_bVignette=(this.m_sSourceImageVignette!=null)&&(this.m_sSourceImageVignette!="");
	this.m_oParentImage=this.oParentImage();
	this.m_oLimite=oCreerDivSuperposable(this.m_oParentImage,true);
	WDAnimSurImage.prototype.SetOpacite(this.m_oLimite,50);
	this.m_oPopup=(d!=null)?_JGEN(d,document,true):null;
	if(this.m_oPopup!=null)
	{
		SetVisible(this.m_oPopup,false);
		WDAnimSurImage.prototype.SetX(this.m_oPopup,0);
		WDAnimSurImage.prototype.SetY(this.m_oPopup,0);
		if(this.m_oPopup.style.display=="none")
		{
			this.m_oPopup.style.display="block";
		}
		this.m_oPopup.className=this.m_oPopup.className;
	}
	this.m_oImagePopup=null;
	this.m_bPopupPersoOK=this.m_oPopup!=null;
	if(this.m_bPopupPersoOK)
	{
		this.m_oImagePopup=document.getElementById(b);
		this.m_bPopupPersoOK=this.m_oImagePopup!=null;
	}
	if(this.m_bPopupPersoOK)
	{
		SetVisible(this.m_oImagePopup,false);
	}
	this.m_bPopupPerso=x&&this.m_bPopupPersoOK;
	this.m_oParentImagePopup=this.m_bPopupPersoOK?this.oParentImage(this.m_oImagePopup,true):null;
	if((this.m_oParentImagePopup!=null)&&(WDAnimSurImage.prototype.sBalise(this.m_oParentImagePopup)=="div")&&(this.m_oParentImagePopup.parentNode!=null)&&(WDAnimSurImage.prototype.sBalise(this.m_oParentImagePopup.parentNode)=="div"))
	{
		this.m_oParentImagePopup=this.m_oParentImagePopup.parentNode;
	}
	this.m_nParamLargeurZoom=i;
	this.m_nParamHauteurZoom=j;
	this.m_bPopupNonPerso=this.m_bPopupPersoOK&&(!this.m_bPopupPerso);
	if(this.m_bPopupNonPerso)
	{
		this.m_oParentImage.parentNode.appendChild(this.m_oPopup.parentNode.removeChild(this.m_oPopup));
	}
	this.m_oZoom=oCreerDivSuperposable(this.m_bPopupPersoOK?this.m_oImagePopup.parentNode:document.body,true,!this.m_bPopupPersoOK);
	if(!this.m_bPopupPersoOK)
	{
		this.m_oPopup=this.m_oZoom;
		this.m_oZoom.style.zIndex=100;
		this.m_oZoom.style.border="solid 1px";
		WDAnimSurImage.prototype.SetLargeur(this.m_oZoom,0);
		WDAnimSurImage.prototype.SetHauteur(this.m_oZoom,0);
	}
	this.m_oLoupe=oCreerDivSuperposable(this.m_oLimite,true,true);
	//this.m_oLoupe.style.border="solid 1px black";
	this.m_oImageLoupe=new Image();
	this.m_oLoupe.appendChild(this.m_oImageLoupe);
	WDAnimSurImage.prototype.SetSuperposable(this.m_oImageLoupe);
	this.m_nZoom=z;
	this.m_sSourceImage="";
	this.InitImage();
	this.m_nPosition=v;
	this.m_bAffiche=false;
	this.m_nTimer=null;
	var oThis=this;
	this.m_pfCallTimer=function() { oThis.TimerAffiche(); };
	this.m_pfCallMouseMove=function(oEvent) { oThis.OnMouseMove(oEvent||event); };
	this.m_pfCallMouseOut=function(oEvent) { oThis.OnMouseOut(oEvent||event); };
	this.m_pfCallMouseWheel=function(oEvent) { oThis.OnMouseWheel(oEvent||event); };
	this.m_oTabObjetSouris=[this.m_oObjet,this.m_oLimite,this.m_oLoupe,this.m_oImageLoupe];
	var o=0;
	for(o=0;o<this.m_oTabObjetSouris.length;o++)
	{
		this.m_oTabObjetSouris[o].onmousemove=this.m_pfCallMouseMove;
		this.m_oTabObjetSouris[o].onmouseout=this.m_pfCallMouseOut;
		if((this.m_oTabObjetSouris[o].onmousewheel===undefined)&&(this.m_oTabObjetSouris[o].addEventListener!=null))
		{
			this.m_oTabObjetSouris[o].addEventListener("DOMMouseScroll",this.m_pfCallMouseWheel,false);
		}
		else
		{
			this.m_oTabObjetSouris[o].onmousewheel=this.m_pfCallMouseWheel;
		}
	}
};

WDImageZoom.prototype.InitImage=function InitImage()
{
	if((this.m_sSourceImage==this.m_oObjet.src)&&((this.m_nLargeur+this.m_nHauteur)>0))
	{
		return;
	}
	var c=(this.m_sSourceImage.length>0);
	this.m_sSourceImage=this.m_oObjet.src;
	var o=WDAnimSurImage.prototype.bClip(this.m_oParentImage)?this.m_oParentImage:this.m_oObjet;
	this.m_nLargeur=WDAnimSurImage.prototype.GetLargeur(o);
	WDAnimSurImage.prototype.SetLargeur(this.m_oLimite,this.m_nLargeur);
	this.m_nHauteur=WDAnimSurImage.prototype.GetHauteur(o);
	WDAnimSurImage.prototype.SetHauteur(this.m_oLimite,this.m_nHauteur);
	this.m_nLargeurImageZoom=this.nDimensionInitImageZoom(this.m_nParamLargeurZoom,this.m_nLargeur);
	this.m_nHauteurImageZoom=this.nDimensionInitImageZoom(this.m_nParamHauteurZoom,this.m_nHauteur);
	if(this.m_bPopupPerso)
	{
		this.m_nLargeurImageZoom=this.nDimensionInitImageZoomPopup(WDAnimSurImage.prototype.GetLargeur(this.m_oParentImagePopup),this.m_nParamLargeurZoom,this.m_nLargeurImageZoom);
		this.m_nHauteurImageZoom=this.nDimensionInitImageZoomPopup(WDAnimSurImage.prototype.GetHauteur(this.m_oParentImagePopup),this.m_nParamHauteurZoom,this.m_nHauteurImageZoom);
	}
	if(this.m_bPopupNonPerso)
	{
		WDAnimSurImage.prototype.SetLargeur(this.m_oImagePopup,this.m_nLargeurImageZoom);
		WDAnimSurImage.prototype.SetHauteur(this.m_oImagePopup,this.m_nHauteurImageZoom);
	}
	this.m_nLargeurZoom=this.m_bPopupPersoOK?WDAnimSurImage.prototype.GetLargeur(this.m_oParentImagePopup):this.m_nLargeurImageZoom;
	this.m_nHauteurZoom=this.m_bPopupPersoOK?WDAnimSurImage.prototype.GetHauteur(this.m_oParentImagePopup):this.m_nHauteurImageZoom;
	WDAnimSurImage.prototype.SetLargeur(this.m_oZoom,this.m_nLargeurImageZoom);
	WDAnimSurImage.prototype.SetHauteur(this.m_oZoom,this.m_nHauteurImageZoom);
	this.m_oImageLoupe.src=this.m_oObjet.src;
	WDAnimSurImage.prototype.SetLargeur(this.m_oImageLoupe,this.m_nLargeur);
	WDAnimSurImage.prototype.SetHauteur(this.m_oImageLoupe,this.m_nHauteur);
	if(this.m_oImageZoom!=null)
	{
		this.m_oZoom.removeChild(this.m_oImageZoom);
		delete this.m_oImageZoom;
	}
	this.m_oImageZoom=new Image();
	this.m_oZoom.appendChild(this.m_oImageZoom);
	WDAnimSurImage.prototype.SetSuperposable(this.m_oImageZoom);
	var oThis=this;
	this.m_oImageZoom.onload=function() { oThis.InitDimensionImage(); };
	this.m_bInitImage=false;
	this.m_oImageZoom.src=(this.m_bVignette&&(!c))?this.m_sSourceImageVignette:this.m_oObjet.src;
	this.InitDimensionImage(true);
};

WDImageZoom.prototype.InitDimensionImage=function InitDimensionImage(i)
{
	if(this.m_bInitImage)
	{
		return;
	}
	this.m_nFacteurImageLargeur=this.nFacteurImageDimension(WDAnimSurImage.prototype.GetLargeur(this.m_oImageZoom),this.m_nLargeur);
	this.m_nFacteurImageHauteur=this.nFacteurImageDimension(WDAnimSurImage.prototype.GetHauteur(this.m_oImageZoom),this.m_nHauteur);
	this.InitZoom(this.m_nZoom,i);
	if(!i)
	{
		this.m_bInitImage=true;
	}
};

WDImageZoom.prototype.InitZoom=function InitZoom(z,i)
{
	this.m_nZoom=(z!=null)?Math.max(z,1):2;
	this.m_nLargeurLoupe=this.nDimensionLoupe(this.m_nLargeurImageZoom,this.m_nFacteurImageLargeur);
	WDAnimSurImage.prototype.SetLargeur(this.m_oLoupe,this.m_nLargeurLoupe);
	this.m_nHauteurLoupe=this.nDimensionLoupe(this.m_nHauteurImageZoom,this.m_nFacteurImageHauteur);
	WDAnimSurImage.prototype.SetHauteur(this.m_oLoupe,this.m_nHauteurLoupe);
	if(!i)
	{
		WDAnimSurImage.prototype.SetLargeur(this.m_oImageZoom,this.nDimensionImageZoom(this.m_nLargeur,this.m_nFacteurImageLargeur));
		WDAnimSurImage.prototype.SetHauteur(this.m_oImageZoom,this.nDimensionImageZoom(this.m_nHauteur,this.m_nFacteurImageHauteur));
	}
};

WDImageZoom.prototype.oParentImage=function oParentImage(i,s)
{
	var p=((i!=null)?i:this.m_oObjet).parentNode;
	if((!s)&&(this.m_bVignette||(p.href!=null)))
	{
		p=p.parentNode;
	}
	var g=p.parentNode;
	return (WDAnimSurImage.prototype.bClip(g)&&(g.parentNode!=null))?g:p;
};

WDImageZoom.prototype.nDimensionInitImageZoom=function nDimensionInitImageZoom(i,j)
{
	return (i!=null)?i:j;
};

WDImageZoom.prototype.nDimensionInitImageZoomPopup=function nDimensionInitImageZoomPopup(p,z,i)
{
	return (z===null)?p:Math.min(p,i);
};


WDImageZoom.prototype.nFacteurImageDimension=function nFacteurImageDimension(i,d)
{
	return (d!=0)?(d/i):1;
};

WDImageZoom.prototype.nDimensionLoupe=function nDimensionLoupe(z,f)
{
	return (z/this.m_nZoom)*f;
};

WDImageZoom.prototype.nDimensionImageZoom=function nDimensionImageZoom(d,f)
{
	return d*this.m_nZoom/f;
};

WDImageZoom.prototype.nTestPosition=function nTestPosition(p,f)
{
	var b=document.body;
	var l=b.clientWidth;
	var h=b.clientHeight;
	var x=0;
	var y=0;
	var d=false;
	var e=false;
	var m=5;
	var n=m;
	var o=m;
	switch(p)
	{
		case this.ms_nPositionBas:
			x=this.m_nX;
			y=this.m_nY+this.m_nHauteur;
			n=0;
			break;
		case this.ms_nPositionGauche:
			x=this.m_nX-this.m_nLargeurZoom;
			d=true;
			y=this.m_nY;
			o=0;
			break;
		case this.ms_nPositionHaut:
			x=this.m_nX;
			y=this.m_nY-this.m_nHauteurZoom;
			e=true;
			n=0;
			break;
		default:
			x=this.m_nX+this.m_nLargeur;
			y=this.m_nY;
			o=0;
			break;
	}
	var s=d?-x:x+this.m_nLargeurZoom-l;
	var t=e?-y:y+this.m_nHauteurZoom-h;
	var r=Math.max(s,t);
	if(f||(r<=0))
	{
		this.m_nXZoom=x+(d?-1:1)*Math.min(n,-Math.min(s,0));
		WDAnimSurImage.prototype.SetX(this.m_oPopup,this.m_nXZoom);
		this.m_nYZoom=y+(e?-1:1)*Math.min(o,-Math.min(t,0));
		WDAnimSurImage.prototype.SetY(this.m_oPopup,this.m_nYZoom);
	}
	return r;
};

WDImageZoom.prototype.nCoordCoinLoupe=function nDistanceCoinLoupe(c,d,o,m)
{
	return Math.min(Math.max(c-(d/2),o),o+m-d);
};

WDImageZoom.prototype.nCoordImageZoom=function nCoordImageZoom(z,c,o,f)
{
	return z-((c-o)*this.m_nZoom/f);
};

WDImageZoom.prototype.TimerAffiche=function TimerAffiche()
{
	this.m_nTimer=null;
	this.m_bAffiche=true;
	this.OnMouseMove();
};

WDImageZoom.prototype.AnnuleTimerAffiche=function AnnuleTimerAffiche()
{
	if(this.m_nTimer!=null)
	{
		clearTimeout(this.m_nTimer);
		this.m_nTimer=null;
	}
};

WDImageZoom.prototype.sObj=function sObj(o)
{
	if(o==null)
	{
		return "";
	}
	var s=o.nodeName+" ";
	switch(o)
	{
		case this.m_oImagePopup:
			s+="image popup";
			break;
		case this.m_oImageZoom:
			s+="image zoomee";
			break;
		case this.m_oLimite:
			s+="limite";
			break;
		case this.m_oLoupe:
			s+="loupe";
			break;
		case this.m_oObjet:
			s+="image affichee";
			break;
		case this.m_oZoom:
			s+="div zoom";
			break;
		case this.m_oPopup:
			s+="popup";
			break;
	}
	s+="(x:"+WDAnimSurImage.prototype.GetX(o)+",y:"+WDAnimSurImage.prototype.GetY(o)+",l:"+WDAnimSurImage.prototype.GetLargeur(o)+",h:"+WDAnimSurImage.prototype.GetHauteur(o)+")";
	return s;
};

WDImageZoom.prototype.OnMouseMove=function OnMouseMove(oEvent)
{
	this.InitImage();
	if(oEvent!=null)
	{
		this.m_nXSouris=oEvent.clientX+document.body.scrollLeft;
		this.m_nYSouris=oEvent.clientY+document.body.scrollTop;
	}
	if(!this.m_bAffiche)
	{
		this.AnnuleTimerAffiche();
		this.m_nTimer=setTimeout(this.m_pfCallTimer,100);
		return;
	}
	this.m_oLimite.style.backgroundColor="white";
	var a=this.oParentImage();
	this.m_nX=WDAnimSurImage.prototype.GetX(a);
	WDAnimSurImage.prototype.SetX(this.m_oLimite,this.m_nX);
	this.m_nY=WDAnimSurImage.prototype.GetY(a);
	WDAnimSurImage.prototype.SetY(this.m_oLimite,this.m_nY);
	var m=0;
	var p=0;
	var i=0;
	for(i=0;i<this.ms_nNbPosition;i++)
	{
		var q=(this.m_nPosition+i)%this.ms_nNbPosition;
		var r=this.nTestPosition(q);
		if(r<=0)
		{
			break;
		}
		if((i==0)||(r<m))
		{
			m=r;
			p=q;
		}
	}
	if(i==this.ms_nNbPosition)
	{
		this.nTestPosition(p,true);
	}
	var x=this.nCoordCoinLoupe(this.m_nXSouris,this.m_nLargeurLoupe,this.m_nX,this.m_nLargeur);
	WDAnimSurImage.prototype.SetX(this.m_oLoupe,x);
	WDAnimSurImage.prototype.SetX(this.m_oImageLoupe,this.m_nX);
	var y=this.nCoordCoinLoupe(this.m_nYSouris,this.m_nHauteurLoupe,this.m_nY,this.m_nHauteur);
	WDAnimSurImage.prototype.SetY(this.m_oLoupe,y);
	WDAnimSurImage.prototype.SetY(this.m_oImageLoupe,this.m_nY);
	SetVisible(this.m_oLoupe,true);
	var b=this.m_oImagePopup!=null;
	var c=b?WDAnimSurImage.prototype.GetX(this.m_oImagePopup):this.m_nXZoom;
	var d=b?WDAnimSurImage.prototype.GetY(this.m_oImagePopup):this.m_nYZoom;
	if(b)
	{
		WDAnimSurImage.prototype.SetX(this.m_oZoom,c);
		WDAnimSurImage.prototype.SetY(this.m_oZoom,d);
	}
	WDAnimSurImage.prototype.SetX(this.m_oImageZoom,this.nCoordImageZoom(c,x,this.m_nX,this.m_nFacteurImageLargeur));
	WDAnimSurImage.prototype.SetY(this.m_oImageZoom,this.nCoordImageZoom(d,y,this.m_nY,this.m_nFacteurImageHauteur));
	SetVisible(this.m_oPopup,true);
};

WDImageZoom.prototype.OnMouseOut=function OnMouseOut(oEvent)
{
	var t=(oEvent!=null)?(oEvent.toElement?oEvent.toElement:oEvent.relatedTarget):null;
	if(clWDUtil.nElementInconnu!=clWDUtil.nDansTableau(this.m_oTabObjetSouris,t))
	{
		return;
	}
	this.m_oLimite.style.backgroundColor="";
	this.AnnuleTimerAffiche();
	this.m_bAffiche=false;
	SetVisible(this.m_oLoupe,false);
	SetVisible(this.m_oPopup,false);
};

WDImageZoom.prototype.OnMouseWheel=function OnMouseWheel(oEvent)
{
	var w=oEvent.wheelDelta;
	var d=(w!=null)?w:-oEvent.detail;
	this.InitZoom(this.m_nZoom+((d/Math.abs(d))*0.1));
	this.OnMouseMove();
	clWDUtil.bStopPropagation(oEvent);
};

if(window["WDImage"])
{

	function WDImageDiaporama(a)
	{
		if(!a)
		{
			return;
		}
		WDImage.prototype.constructor.apply(this,arguments);
	};

	WDImageDiaporama.prototype=new WDImage();
	WDImageDiaporama.prototype.constructor=WDImageDiaporama;

	WDImageDiaporama.prototype.Init=function Init()
	{
		WDImage.prototype.Init.apply(this,arguments);
		var p=this.m_oImage.parentNode;
		this.m_oBarre=oCreerDivSuperposable(p,false,true);
		this.AjoutBouton("|&lt;",this.OnPremier);
		this.AjoutBouton("&lt;",this.OnPrecedent);
		this.m_oBoutonJouePause=this.AjoutBouton("||",this.OnJouePause);
		this.AjoutBouton(">",this.OnSuivant);
		this.AjoutBouton(">|",this.OnDernier);
		SetX(this.m_oBarre,Math.max(GetX(this.m_oImage)+((GetLargeur(this.m_oImage)-GetLargeur(this.m_oBarre))/2),0));
		SetY(this.m_oBarre,GetY(this.m_oImage)+GetHauteur(this.m_oImage)-GetHauteur(this.m_oBarre));
		var oThis=this;
		p.onmouseover=function(oEvent) { oThis.OnMouseOver(oEvent||event); };
		p.onmouseout=function(oEvent) { oThis.OnMouseOut(oEvent||event); };
	};

	WDImageDiaporama.prototype.AjoutBouton=function AjoutBouton(l,f)
	{
		var oBouton=document.createElement("button");
		oBouton.value=l;
		oBouton.style.backgroundColor="black";
		oBouton.style.color="white";
		oBouton.style.fontSize="20px";
		oBouton.style.fontWeight="bold";
		oBouton.style.width="30px";
		oBouton.style.border="none";
		oBouton.onmouseover=function() { SetOpacite(this,100); };
		oBouton.onmouseout=function() { SetOpacite(this,50); };
		oBouton.onmouseout();
		var t=this;
		oBouton.onclick=function() { f.apply(t); };
		this.m_oBarre.appendChild(oBouton);
		return oBouton;
	};

	WDImageDiaporama.prototype.OnMouseOver=function OnMouseOver(oEvent)
	{
		SetVisible(this.m_oBarre,true);
	};

	WDImageDiaporama.prototype.OnMouseOut=function OnMouseOut(oEvent)
	{
		SetVisible(this.m_oBarre,false);
	};

	WDImageDiaporama.prototype.OnPremier=function OnPremier()
	{
		this.AffichePremier();
	};

	WDImageDiaporama.prototype.OnPrecedent=function OnPrecedent()
	{
		this.AffichePrecedent();
	};

	WDImageDiaporama.prototype.OnJouePause=function OnJouePause()
	{
		var b=this.bGetDefilement();
		if(b)
		{
			this.ArreteDefilement();
		}
		else
		{
			this.LanceDefilement();
		}
		this.m_oBoutonJouePause.value=b?"|>":"||";
	};

	WDImageDiaporama.prototype.OnSuivant=function OnSuivant()
	{
		this.AfficheSuivant();
	};

	WDImageDiaporama.prototype.OnDernier=function OnDernier()
	{
		this.AfficheDernier();
	};
}

// Animation des popups
function WDAnimSurPopup(oPopup,oCible,oCibleExterne,sAliasCible,nHauteurCible,oPopupPrecedente,oDocument,nAnimation,nDuree)
{
	if(oPopup)
	{
		// Sauve les membres
		this.m_oCibleExterne=oCibleExterne;
		this.m_oCible=oCible;
		this.m_oPopup=oPopup;
		this.m_oPopupPrecedente=oPopupPrecedente;
		this.m_oDocument=oDocument;
		this.m_sAliasCible=sAliasCible;

		this.m_sCibleExterneHeight=oCibleExterne.style.height;
		this.m_sCibleExterneOverflowY=oCibleExterne.style.overflowY;
		this.m_sCiblePosition=oCible.style.position;
		this.m_sPopupPosition=oPopup.style.position;
		this.m_sPopupZIndex=oPopup.style.zIndex;

		// Initialise la position des elements
		oCibleExterne.style.height=nHauteurCible+"px";
		oCibleExterne.style.overflowY="hidden";
		oCible.style.position="relative";
		oPopupPrecedente.style.position="absolute";
		oPopupPrecedente.style.zIndex=this.__nGetZIndex(nAnimation,true);
		oPopup.style.position="absolute";
		oPopup.style.zIndex=this.__nGetZIndex(nAnimation,false);
		oPopupPrecedente.style.visibility="inherit";
		oPopup.style.visibility="inherit";
		clWDUtil.SetDisplay(oPopupPrecedente,true);
		clWDUtil.SetDisplay(oPopup,true);
		// Les positions des deux popups sont initialises par le premier appel de la fonction d'avancement lors de la construction

		WDAnim.prototype.constructor.apply(this,[this.__pfGetAvancement(nAnimation),0,this.__nGetDeplacement(nAnimation,oCibleExterne),0,this.ms_nCourbeLineaire,nDuree,sAliasCible]);

		this.ms_tabAnimSurPopup.push(this);
	}
};

WDAnimSurPopup.prototype=new WDAnim();
WDAnimSurPopup.prototype.constructor=WDAnimSurPopup;

// Constantes
WDAnimSurPopup.prototype.ms_nAnimDefilementDroite=2;
WDAnimSurPopup.prototype.ms_nAnimDefilementGauche=3;
WDAnimSurPopup.prototype.ms_nAnimRecouvrementHaut=8;
WDAnimSurPopup.prototype.ms_nAnimDevoilementHaut=17;

// Globales
WDAnimSurPopup.prototype.ms_tabCibles=[];
WDAnimSurPopup.prototype.ms_tabAnimSurPopup=[];
WDAnimSurPopup.prototype.ms_nNbPauses=0;

// Marque la fin de l'animation
WDAnimSurPopup.prototype.vMaj=function vMaj(bForceNonFini,nTime,bPause)
{
	bPause=bPause||(0<WDAnimSurPopup.prototype.ms_nNbPauses);
	WDAnim.prototype.vMaj.apply(this,arguments);
};
WDAnimSurPopup.prototype.vFin=function vFin()
{
	clWDUtil.SupprimeDansTableau(this.ms_tabAnimSurPopup,this);

	this.m_oCibleExterne.style.overflowY=this.m_sCibleExterneOverflowY;
	this.m_oCibleExterne.style.height=this.m_sCibleExterneHeight;
	this.m_oCible.style.position=this.m_sCiblePosition;

	this.s_FinAffiche(this.m_oPopup,this.m_oCible,this.m_oDocument,this.m_sAliasCible,this.m_sPopupPosition,this.m_sPopupZIndex);

	// Liberation
	this.m_oPopup=null;
	delete this.m_oPopup;
	this.m_oCible=null;
	delete this.m_oCible;
	this.m_oCibleExterne=null;
	delete this.m_oCibleExterne;
	this.m_oPopupPrecedente=null;
	delete this.m_oPopupPrecedente;
	this.m_oDocument=null;
	delete this.m_oDocument;

	WDAnim.prototype.vFin.apply(this,arguments);
};

// Trouve le zIndex des elements
WDAnimSurPopup.prototype.__nGetZIndex=function __nGetZIndex(nAnimation,bPrecedente)
{
	switch(nAnimation)
	{
		case this.ms_nAnimDefilementDroite:
		case this.ms_nAnimDevoilementHaut:
			return bPrecedente?"2":"1";
		default:
		case this.ms_nAnimDefilementGauche:
		case this.ms_nAnimRecouvrementHaut:
			return bPrecedente?"1":"2";
	}
};
// Calcule la fonction d'avancement
WDAnimSurPopup.prototype.__pfGetAvancement=function __pfGetAvancement(nAnimation)
{
	switch(nAnimation)
	{
		case this.ms_nAnimDefilementDroite:
			return this.__OnDefilementDroite;
		default:
		case this.ms_nAnimDefilementGauche:
			return this.__OnDefilementGauche;
		case this.ms_nAnimRecouvrementHaut:
			return this.__OnRecouvrementHaut;
		case this.ms_nAnimDevoilementHaut:
			return this.__OnDevoilementHaut;
	}
};
// Calcule le deplacement maximal
WDAnimSurPopup.prototype.__nGetDeplacement=function __nGetDeplacement(nAnimation,oCibleExterne)
{
	switch(nAnimation)
	{
		default:
		case this.ms_nAnimDefilementDroite:
		case this.ms_nAnimDefilementGauche:
			return oCibleExterne.offsetWidth;
		case this.ms_nAnimRecouvrementHaut:
		case this.ms_nAnimDevoilementHaut:
			return Math.min(this.m_oDocument.body.offsetHeight+Math.min(0,this.m_oDocument.body.scrollTop-_JCCP(this.m_oCible.offsetTop,this.m_oCible,false,true)),oCibleExterne.offsetHeight);
	}
};

// Fonctions d'avancement
WDAnimSurPopup.prototype.__OnDefilementGauche=function __OnDefilementGauche(nAvancement)
{
	this.__OnDefilementDroiteGauche(nAvancement,true);
};
WDAnimSurPopup.prototype.__OnDefilementDroite=function __OnDefilementDroite(nAvancement)
{
	this.__OnDefilementDroiteGauche(nAvancement,false);
};
WDAnimSurPopup.prototype.__OnDefilementDroiteGauche=function __OnDefilementDroiteGauche(nAvancement,bGauche)
{
	var nInverse=bGauche?-1:1;
	if(0==nAvancement)
	{
		// Sur le premier appel place correctement les elements
		this.m_oPopupPrecedente.style.top="0px";
		this.m_oPopup.style.top=this.__nGetPositionVerticalFinal()+"px";
	}
	// Place les elements en largeur
	this.m_oPopupPrecedente.style.left=(nInverse*nAvancement)+"px";
	this.m_oPopup.style.left=(nInverse*(nAvancement-this.m_nValDelta))+"px";

	// Force le reflow avec IE
	this.m_oPopup.className+="";
};
WDAnimSurPopup.prototype.__OnRecouvrementHaut=function __OnRecouvrementHaut(nAvancement)
{
	this.__OnRecouvrementDevoilementHaut(nAvancement,true);
};
WDAnimSurPopup.prototype.__OnDevoilementHaut=function __OnDevoilementHaut(nAvancement)
{
	this.__OnRecouvrementDevoilementHaut(nAvancement,false);
};
WDAnimSurPopup.prototype.__OnRecouvrementDevoilementHaut=function __OnRecouvrementDevoilementHaut(nAvancement,bRecouvrement)
{
	var oPopupDessous=bRecouvrement?this.m_oPopupPrecedente:this.m_oPopup;
	var oPopupDessus=bRecouvrement?this.m_oPopup:this.m_oPopupPrecedente;
	if(0==nAvancement)
	{
		// Sur le premier appel place correctement les elements
		oPopupDessous.style.left="0px";
		oPopupDessous.style.top="0px";
		oPopupDessus.style.left="0px";
	}
	// Place la popup en hauteur
	oPopupDessus.style.top=(this.__nGetPositionVerticalFinal()+(bRecouvrement?this.m_nValDelta-nAvancement:nAvancement))+"px";

	// Force le reflow avec IE
	this.m_oPopup.className+="";
};
WDAnimSurPopup.prototype.__nGetPositionVerticalFinal=function __nGetPositionVerticalFinal()
{
	return Math.max(0,this.m_oDocument.body.scrollTop-_JCCP(this.m_oCible.offsetTop,this.m_oCible,false,true));
};

// Fin de l'affichage
WDAnimSurPopup.prototype.s_FinAffiche=function s_FinAffiche(oPopup,oCible,oDocument,sAliasCible,sPopupPosition,sPopupZIndex)
{
	// Si on a une popup precedente : replace ses parametres et la masque
	var oDescriptionCible=this.ms_tabCibles[sAliasCible];
	if(oDescriptionCible)
	{
		clWDUtil.SetDisplay(oDescriptionCible.m_oPopup,false);
		oDescriptionCible.m_oPopup.style.position=oDescriptionCible.m_sPosition;
		oDescriptionCible.m_oPopup.style.zIndex=oDescriptionCible.m_sZIndex;
		oDescriptionCible.m_oPopup.style.visibility="hidden";
		oDescriptionCible.m_oPopup=null;
		oDescriptionCible=null;
		this.ms_tabCibles[sAliasCible]=null;
		delete this.ms_tabCibles[sAliasCible];
	}

	// Modifie la popup
	oPopup.style.position="static";
	oPopup.style.height="100%";
	oPopup.style.zIndex="auto";
	oPopup.style.visibility="inherit";
	if("none"==_JGCS(oPopup))
	{
		clWDUtil.SetDisplay(oPopup,true);
	}
	var nScroll=_JCCP(oCible.offsetTop,oCible,false,true);
	if(nScroll<oDocument.body.scrollTop)
	{
		oDocument.body.scrollTop=nScroll;
	}

	// Et ajoute la nouvelle description
	this.ms_tabCibles[sAliasCible]={
		m_oPopup: oPopup,
		m_sPosition: sPopupPosition,
		m_sZIndex: sPopupZIndex
	};

	// Notifie les champs de l'affichage de la popup
	// Force la MAJ des champs (saisie riche, upload)
	AppelMethode(WDChamp.prototype.ms_sOnDisplay,[oPopup]);
};

// Interface avec le WL
WDAnimSurPopup.prototype.s_PopupAnime=function s_PopupAnime(sAliasPopup,sAliasCible,oDocument,nAnimation,nDuree)
{
	// Trouve la popup
	var oPopup=_JGE(sAliasPopup,oDocument,true,false);
	// Trouve la cible
	var oCible=_JGE(sAliasCible,oDocument,false);
	// Si on trouve l'exterieur d'une table de positionnement
	if(oCible&&clWDUtil.bBaliseEstTag(oCible,"table"))
	{
		oCible=oCible.getElementsByTagName("td")[0];
	}

	if(oPopup&&oCible)
	{
		// Trouve si on a deja une popup (pas de var : on fait une variable globale)
		var oDescriptionCible=this.ms_tabCibles[sAliasCible];
		var nHauteurCible;
		var oCibleExterne;
		if(!oDescriptionCible)
		{
			// Il n'y a pas encore de popup dans la cible : affiche simplement la popup
			SupprimeFils(oCible);
		}
		else if(oDescriptionCible.m_oPopup==oPopup)
		{
			// Ne change pas de popup : ne fait rien
			return;
		}
		else
		{
			// Lance l'animation
			oCibleExterne=_JGE(sAliasCible,oDocument,true,false);
			nHauteurCible=oCibleExterne.offsetHeight;
		}

		// Deplace la popup
		oPopup=_JCD(oCible,oPopup);
		// Lance l'animation ou affiche directement
		if(oDescriptionCible)
		{
			oCibleExterne=_JGE(sAliasCible,oDocument,true,false);
			new WDAnimSurPopup(oPopup,oCible,oCibleExterne,sAliasCible,nHauteurCible,oDescriptionCible.m_oPopup,oDocument,nAnimation,nDuree)
		}
		else
		{
			WDAnimSurPopup.prototype.s_FinAffiche(oPopup,oCible,oDocument,sAliasCible,oPopup.style.position,oPopup.style.zIndex);
		}
	}
};

// Pause/Continue les animations
WDAnimSurPopup.prototype.s_Pause=function s_Pause()
{
	if(0==WDAnimSurPopup.prototype.ms_nNbPauses++)
	{
		WDAnimSurPopup.prototype.ms_nDebutPause=(new Date()).getTime();
	}

};
WDAnimSurPopup.prototype.s_Continue=function s_Continue()
{
	setTimeout(WDAnimSurPopup.prototype.__s_Continue,1);
};
WDAnimSurPopup.prototype.__s_Continue=function _s_Continue()
{
	if(0== --WDAnimSurPopup.prototype.ms_nNbPauses)
	{
		var nDecalage=(new Date()).getTime()-WDAnimSurPopup.prototype.ms_nDebutPause;
		var tabAnimSurPopup=WDAnimSurPopup.prototype.ms_tabAnimSurPopup;
		var i;
		var nLimiteI=tabAnimSurPopup.length;
		for(i=0;i<nLimiteI;i++)
		{
			tabAnimSurPopup[i].m_nDebut+=nDecalage;
		}
		delete WDAnimSurPopup.prototype.ms_nDebutPause;
	}
};