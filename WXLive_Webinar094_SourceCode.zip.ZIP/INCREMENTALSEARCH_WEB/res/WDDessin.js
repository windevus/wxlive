//#16.00.11.00 WDDessin.js
//VersionVI: 30A170078p
// Le seul support technique disponible pour cette librairie est
// accessible a travers le service "Assistance Directe".

var dessinNormal=13;
var dessinXOR=7;
var copieImage= -1;
var copieToutNoir=0;
var copieDstInverse=1;
var copieFusionCopie=2;
var copieFusionPeint=3;
var copiePasSrcCopie=4;
var copiePasSrcEfface=5;
var copiePatCopie=6;
var copiePatInverse=7;
var copiePatPeint=8;
var copieSrcEt=9;
var copieSrcCopie=10;
var copieSrcEfface=11;
var copieSrcInverse=12;
var copieSrcPeint=13;
var copieToutBlanc=14;
var dAvecOpacite=2;
var dEffacer=0;
var dQuadrillageOpacite=4;
var dSansEffacer=1;
var dSurGraphe=8;
var dForcerAffichage=16;
var OPACITE_MAX=255;
var FACTEUR_BLEU=0x10000;
var FACTEUR_VERT=0x100;
var iNormal=1;
var iSouligne=2;
var iItalique=4;
var iGras=8;
var iBarre=16;
var SOULIGNE=" underline"
var TRANSPARENT="transparent"

function oCreerCanvas()
{
	return document.createElement("canvas");
}

function oDCCanvas(oCanvas)
{
	return ((oCanvas==null)||(oCanvas.getContext==null))?null:oCanvas.getContext("2d");
}

function WDDessinDisponible()
{
	var c=oCreerCanvas();
	var r=(oDCCanvas(c)!=null);
	delete c;
	return r;
}

var gTabDessin=new Array();
var goDessin=null;
var goDessinSauv=null;
var goDC=null;
var gbDessinDispo=WDDessinDisponible();

function DessinDisponible()
{
	return gbDessinDispo;
}

function RVB(nRouge,nVert,nBleu)
{
	return (nBleu*FACTEUR_BLEU)+(nVert*FACTEUR_VERT)+nRouge;
}

function RVBBleu(nCouleur)
{
	return (nCouleur&0xFF0000)/FACTEUR_BLEU;
}

function RVBVert(nCouleur)
{
	return (nCouleur&0xFF00)/FACTEUR_VERT;
}

function RVBRouge(nCouleur)
{
	return (nCouleur&0xFF);
}

function nWLVersOpacite(nOpacite)
{
	return nOpacite/OPACITE_MAX;
}

function WDDessin(oImg)
{
	this.m_oImg=oImg;
	this.m_oCanvas=oCreerCanvas();
	this.m_oDC=oDCCanvas(this.m_oCanvas);
	this.m_bOpacite=false;
	this.m_nOpaciteFond=OPACITE_MAX;
	this.m_nOpaciteTrait=OPACITE_MAX;
	if(oImg==null) return;
	this.m_oCanvas.width=oImg.offsetWidth;
	this.m_oCanvas.height=oImg.offsetHeight;
	this.m_bForcerAffichage=false;
	this.m_fAngle=0;
	try { this.m_oDC.drawImage(oImg,0,0); } catch(e) { };
}

WDDessin.prototype.AfficheImage=function AfficheImage(oImg)
{
	((oImg!=null)?oImg:this.m_oImg).src=this.m_oCanvas.toDataURL();
};

WDDessin.prototype.MajImage=function MajImage(oImg,oCopie)
{
	if(oCopie!=null)
	{
		var h=oDCCanvas(oCopie);
		h.drawImage(this.m_oCanvas,0,0);
		this.Effacer();
		this.m_oDC.drawImage(oCopie,0,0);
		delete oCopie;
	}
	if(!this.m_bForcerAffichage) this.AfficheImage(oImg);
};

WDDessin.prototype.destructor=function destructor()
{
	delete this.m_oCanvas;
	delete this;
};

WDDessin.prototype.nLargeur=function nLargeur()
{
	return this.m_oCanvas.width;
};

WDDessin.prototype.nHauteur=function nHauteur()
{
	return this.m_oCanvas.height;
};

WDDessin.prototype.oImage=function oImage()
{
	return this.m_oDC.getImageData(0,0,goDessin.nLargeur(),goDessin.nHauteur());
};

WDDessin.prototype.ModifImage=function ModifImage(oImage,oImgDst)
{
	this.m_oDC.putImageData(oImage,0,0);
	delete oImage;
	this.MajImage(oImgDst);
};

WDDessin.prototype.nIndice=function nIndice(nIndice)
{
	return nIndice*4;
};

WDDessin.prototype.nIndiceXY=function nIndiceXY(nX,nY)
{
	return this.nIndice(nX+(this.nLargeur()*nY));
};

WDDessin.prototype.nIndiceRouge=function nIndiceRouge(nIndice)
{
	return nIndice;
};

WDDessin.prototype.nIndiceVert=function nIndiceVert(nIndice)
{
	return nIndice+1;
};

WDDessin.prototype.nIndiceBleu=function nIndiceBleu(nIndice)
{
	return nIndice+2;
};

WDDessin.prototype.nIndiceOpacite=function nIndiceOpacite(nIndice)
{
	return nIndice+3;
};

WDDessin.prototype.nCouleur=function nCouleur(oImage,nIndice)
{
	var d=oImage.data;
	return RVB(d[this.nIndiceRouge(nIndice)],d[this.nIndiceVert(nIndice)],d[this.nIndiceBleu(nIndice)]);
};

WDDessin.prototype.nCouleurIndice=function nCouleurIndice(oImage,nIndice)
{
	return this.nCouleur(oImage,this.nIndice(nIndice));
};

WDDessin.prototype.nCouleurXY=function nCouleurXY(oImage,nX,nY)
{
	return this.nCouleur(oImage,this.nIndiceXY(nX,nY));
};

WDDessin.prototype.nOpacite=function nOpacite(oImage,nIndice)
{
	return oImage.data[this.nIndiceOpacite(nIndice)];
};

WDDessin.prototype.nOpaciteXY=function nOpacite(oImage,nX,nY)
{
	return this.nOpacite(oImage,this.nIndiceXY(nX,nY));
};

WDDessin.prototype.ModifCouleur=function ModifCouleur(oImage,nIndice,nCouleur,nOpacite,bLaisseOpacite)
{
	var d=oImage.data;
	d[this.nIndiceRouge(nIndice)]=RVBRouge(nCouleur);
	d[this.nIndiceVert(nIndice)]=RVBVert(nCouleur);
	d[this.nIndiceBleu(nIndice)]=RVBBleu(nCouleur);
	if((!bLaisseOpacite)&&((nOpacite!=null)||(this.nOpacite(oImage,nIndice)==0))) this.ModifOpacite(oImage,nIndice,(nOpacite!=null)?nOpacite:OPACITE_MAX);
};

WDDessin.prototype.ModifCouleurIndice=function ModifCouleurIndice(oImage,nIndice,nCouleur,nOpacite,bLaisseOpacite)
{
	var d=oImage.data;
	this.ModifCouleur(oImage,this.nIndice(nIndice),nCouleur,nOpacite,bLaisseOpacite);
};

WDDessin.prototype.ModifCouleurXY=function ModifCouleurXY(oImage,nX,nY,nCouleur,nOpacite,bLaisseOpacite)
{
	this.ModifCouleur(oImage,this.nIndiceXY(nX,nY),nCouleur,nOpacite,bLaisseOpacite);
};

function nWDAjoutCoordTableau(nTableau,nIndice,nCoord)
{
	nTableau[++nIndice]=nCoord;
	return nIndice;
}

function nWDAjoutPointTableau(nTableau,nIndice,nX,nY)
{
	nIndice=nWDAjoutCoordTableau(nTableau,nIndice,nX);
	return nWDAjoutCoordTableau(nTableau,nIndice,nY);
}

WDDessin.prototype.PropageCouleur=function PropageCouleur(oImage,nX,nY,nCouleur,nCouleurStop)
{
	var o=new Array();
	var f=new Array();
	var i=nWDAjoutPointTableau(f,-1,nX,nY);
	var l=this.nLargeur();
	var h=this.nHauteur();
	var nCouleurDepart=null;
	if(nCouleur==null) nCouleur=this.m_oDC.fillStyle;
	while(i>0)
	{
		var y=f[i--];
		var x=f[i--];
		var t=this.nIndiceXY(x,y);
		if(!o[t])
		{
			if((x>=0)&&(x<l)&&(y>=0)&&(y<h))
			{
				o[t]=true;
				var c=this.nCouleur(oImage,t);
				if((nCouleurStop==null)&&(nCouleurDepart==null)) nCouleurDepart=c;
				if((nCouleurStop!=null)?(c!=nCouleurStop):(c==nCouleurDepart))
				{
					if(c!=nCouleur) this.ModifCouleur(oImage,t,nCouleur);
					i=nWDAjoutPointTableau(f,i,x-1,y-1);
					i=nWDAjoutPointTableau(f,i,x,y-1);
					i=nWDAjoutPointTableau(f,i,x+1,y-1);
					i=nWDAjoutPointTableau(f,i,x-1,y);
					i=nWDAjoutPointTableau(f,i,x+1,y);
					i=nWDAjoutPointTableau(f,i,x-1,y+1);
					i=nWDAjoutPointTableau(f,i,x,y+1);
					i=nWDAjoutPointTableau(f,i,x+1,y+1);
				}
			}
		}
	}
	delete o;
	delete f;
};

WDDessin.prototype.ModifOpacite=function ModifOpacite(oImage,nIndice,nOpacite)
{
	oImage.data[this.nIndiceOpacite(nIndice)]=nOpacite;
};

WDDessin.prototype.nNbPixel=function nNbPixel()
{
	return this.m_oCanvas.width*this.m_oCanvas.height;
};

WDDessin.prototype.nFinTexteAffiche=function nLargeurTexteAffiche(sTexte,nDebut,nFin,nX,nY)
{
	var s=sTexte.substring(nDebut,nFin);
	this.m_oDC.textBaseline="top";
	//this.m_oDC.strokeText(s,nX,nY);
	this.m_oDC.fillText(s,nX,nY);
	return nX+this.m_oDC.measureText(s).width;
};

WDDessin.prototype.Texte=function Texte(nX,nY,sTexte,bSouligne)
{
	var s=(((bSouligne===undefined)||(!bSouligne))&&(this.m_oDC.font.indexOf(SOULIGNE)<0));
	var d=0;
	if(sTexte.length===undefined) sTexte=sTexte.toString();
	var l=sTexte.length;
	var f=l;
	this.m_oDC.save();
	this.m_oDC.translate(nX,nY);
	nX=nY=0;
	this.m_oDC.rotate(this.m_fAngle);
	while(d<l)
	{

		if(s)
		{
			f=sTexte.indexOf("&",d);
			if(f<0) f=l;
		}
		if(f>d)
		{
			nX=this.nFinTexteAffiche(sTexte,d,f,nX,nY);
			d=f+1;
			f=d+1;
		}
		if(d<l)
		{
			this.m_oDC.save();
			//this.m_oDC.font+=SOULIGNE;
			nX=this.nFinTexteAffiche(sTexte,d,f,nX,nY);
			this.m_oDC.restore();
			d=f;
			f=d+1;
		}
	}
	this.m_oDC.restore();
};

WDDessin.prototype.Effacer=function Effacer()
{
	this.m_oDC.clearRect(0,0,this.nLargeur(),this.nHauteur());
	this.MajImage();
};

function sWDComposanteCouleur(n)
{
	var s=n.toString(16);
	return (s.length<2)?("0"+s):s;
}

function sWDCouleurVersChaine(nCouleur)
{
	if(nCouleur.charAt==null) nCouleur="#"+sWDComposanteCouleur(RVBRouge(nCouleur))+sWDComposanteCouleur(RVBVert(nCouleur))+sWDComposanteCouleur(RVBBleu(nCouleur));
	return nCouleur;
}

function nWDCouleurVersEntier(nCouleur)
{
	if((nCouleur!=null)&&(nCouleur.charAt!=null))
	{
		if((nCouleur.charAt(0)=="#")&&(nCouleur.length==7)) nCouleur=eval("0x"+nCouleur.substring(5,nCouleur.length)+nCouleur.substring(3,5)+nCouleur.substring(1,3));
		else
		{
			var d=nCouleur.indexOf("(");
			if(d>=0)
			{
				var l=nCouleur.length;
				d=d+1;
				var r=parseInt(nCouleur.substring(d,l));
				d=nCouleur.indexOf(",",d);
				if(d>=0)
				{
					d=d+1;
					var v=parseInt(nCouleur.substring(d,l));
					d=nCouleur.indexOf(",",d);
					if(d>=0) nCouleur=RVB(r,v,parseInt(nCouleur.substring(d+1,l)));
				}
			}
		}
	}
	return nCouleur;
}

function WDCouleur(nCouleur)
{
	nCouleur=nWDCouleurVersEntier(nCouleur);
	this.m_nRouge=RVBRouge(nCouleur);
	var Rouge=this.m_nRouge/255.0;
	this.m_nVert=RVBVert(nCouleur);
	var Vert=this.m_nVert/255.0;
	this.m_nBleu=RVBBleu(nCouleur);
	var Bleu=this.m_nBleu/255.0;
	var Teint=0;
	var Lumin=0;
	var Satur=0;
	var MinVal=Math.min(Rouge,Math.min(Vert,Bleu));
	var MaxVal=Math.max(Rouge,Math.max(Vert,Bleu));
	var Diff=MaxVal-MinVal;
	var Somme=MaxVal+MinVal;
	Lumin=Somme/2.0;
	if(MaxVal==MinVal)
	{
		Satur=0.0;
		Teint=0.0;
	}
	else
	{
		Satur=(Lumin<=0.5)?(Diff/Somme):(Diff/(2.0-Somme));
		var RougeNorm=(MaxVal-Rouge)/Diff;
		var VertNorm=(MaxVal-Vert)/Diff;
		var BleuNorm=(MaxVal-Bleu)/Diff;
		if(Rouge==MaxVal) Teint=60.0*(6.0+BleuNorm-VertNorm);
		else if(Vert==MaxVal) Teint=60.0*(2.0+RougeNorm-BleuNorm);
		else Teint=60.0*(4.0+VertNorm-RougeNorm);
	}
	if(Teint<0.0) Teint+=360.0;
	this.m_nTeinte=Math.round(Teint)%360;
	var Lum=Math.round(Lumin*100.0);
	this.m_nLuminosite=Math.max(0,Math.min(Lum,100));
	var Sat=Math.round(Satur*100.0);
	this.m_nSaturation=Math.max(0,Math.min(Sat,100));
	this.MajCouleur();
}

WDCouleur.prototype.MajCouleur=function MajCouleur()
{
	this.m_nCouleur=RVB(this.m_nRouge,this.m_nVert,this.m_nBleu);
};

WDCouleur.prototype.nComposanteRGB=function nComposanteRGB(rm1,rm2,Teinte)
{
	if(Teinte>360) Teinte=Teinte-360;
	else if(Teinte<0) Teinte=Teinte+360;
	if(Teinte<60) rm1=rm1+(rm2-rm1)*Teinte/60;
	else if(Teinte<180) rm1=rm2;
	else if(Teinte<240) rm1=rm1+(rm2-rm1)*(240-Teinte)/60;
	var nRGB=Math.floor(rm1*255);
	if(nRGB<0) nRGB=0;
	else if(nRGB>255) nRGB=255;
	return nRGB;
};

WDCouleur.prototype.nModifieTSL=function nModifieTSL(nTeinte,nSaturation,nLuminosite)
{
	nTeinte=Math.floor(255*(nTeinte%360)/360.0);
	nSaturation=Math.floor(255*(nSaturation%101)/100.0);
	nLuminosite=Math.floor(255*(nLuminosite%101)/100.0);
	this.m_nTeinte+=nTeinte;
	this.m_nTeinte=this.m_nTeinte%255;
	this.m_nSaturation=Math.max(0,Math.min(255,(this.m_nSaturation+nSaturation)));
	if(this.m_nSaturation==0)
	{
		this.m_nBleu=Math.floor(Math.max(0,Math.min(255,(this.m_nLuminosite*255)/100)));
		this.m_nRouge=this.m_nBleu;
		this.m_nVert=this.m_nBleu;
	}
	else
	{
		var fTeinte=this.m_nTeinte;
		var fLuminosite=this.m_nLuminosite/100.0;
		var fSaturation=this.m_nSaturation/100.0;
		var fRm2=(fLuminosite<=0.5)?(fLuminosite+fLuminosite*fSaturation):(fLuminosite+fSaturation-fLuminosite*fSaturation);
		var fRm1=2.0*fLuminosite-fRm2;
		this.m_nRouge=Math.floor(this.nComposanteRGB(fRm1,fRm2,fTeinte+120.0));
		this.m_nVert=Math.floor(this.nComposanteRGB(fRm1,fRm2,fTeinte));
		this.m_nBleu=Math.floor(this.nComposanteRGB(fRm1,fRm2,fTeinte-120.0));
	}
	if(nLuminosite!=0)
	{
		this.m_nRouge=0xFF&Math.max(0,Math.min(255,Math.floor(this.m_nRouge+nLuminosite)));
		this.m_nVert=0xFF&Math.max(0,Math.min(255,Math.floor(this.m_nVert+nLuminosite)));
		this.m_nBleu=0xFF&Math.max(0,Math.min(255,Math.floor(this.m_nBleu+nLuminosite)));
	}
	this.MajCouleur();
	return this.m_nCouleur;
};

function CouleurLuminosite(nCouleur)
{
	var c=new WDCouleur(nCouleur);
	var r=c.m_nLuminosite;
	delete c;
	return r;
}

function CouleurSaturation(nCouleur)
{
	var c=new WDCouleur(nCouleur);
	var r=c.m_nSaturation;
	delete c;
	return r;
}

function CouleurTeinte(nCouleur)
{
	var c=new WDCouleur(nCouleur);
	var r=c.m_nTeinte;
	delete c;
	return r;
}

function nWDIndiceImage(oImg)
{
	var i=0;
	for(i=0;i<gTabDessin.length;i++) if((gTabDessin[i]!=null)&&(gTabDessin[i].m_oImg==oImg)) break;
	return i;
}

function bWDIndiceOK(i)
{
	return i<gTabDessin.length;
}

function bWDTestFlag(nVal,nFlag)
{
	return (nVal&nFlag)==nFlag;
}

function oWDInitDessin(oImg,nOption,bInit)
{
	if(!DessinDisponible()) return null;
	var i=nWDIndiceImage(oImg);
	if(!bWDIndiceOK(i))
	{
		for(i=0;i<gTabDessin.length;i++) if(gTabDessin[i]==null) break;
		gTabDessin[i]=new WDDessin(oImg);
		bInit=true;
	}
	goDessin=gTabDessin[i];
	goDessin.m_bOpacite=bWDTestFlag(nOption,dAvecOpacite);
	goDessin.m_bForcerAffichage=bWDTestFlag(nOption,dForcerAffichage);
	goDC=goDessin.m_oDC;
	if(bInit)goDC.fillStyle=goDC.strokeStyle=TRANSPARENT;
	if(!bWDTestFlag(nOption,dSansEffacer)) goDessin.Effacer();
	return goDC;
}

function dDebutDessin(oImg,nOption)
{
	return oWDInitDessin(oImg,nOption,true);
}

function bWDDessinOK()
{
	return goDC!=null;
}

function WDInitCouleurTrait(nCouleur)
{
	if(nCouleur!=null) goDC.strokeStyle=sWDCouleurVersChaine(nCouleur);
}

function WDInitCouleurFond(nCouleur)
{
	if(nCouleur!=null) goDC.fillStyle=sWDCouleurVersChaine(nCouleur);
}

function WDInitEpaisseurTrait(nEpaisseur)
{
	if(nEpaisseur!=null) goDC.lineWidth=nEpaisseur;
}

function bWDInitTrace(nX1,nY1,nCouleurTrait,nCouleurFond,nEpaisseur)
{
	if(!bWDDessinOK()) return false;
	goDC.save();
	WDInitCouleurTrait(nCouleurTrait);
	WDInitCouleurFond(nCouleurFond);
	WDInitEpaisseurTrait(nEpaisseur);
	goDC.beginPath();
	goDC.moveTo(nX1,nY1);
	return true;
}

function WDChangeOpacite(bChange,nOpacite)
{
	if(bChange)
	{
		goDC.save();
		goDC.globalAlpha=nWLVersOpacite(nOpacite);
	}
}

function WDRestaureOpacite(bRestaure)
{
	if(bRestaure) goDC.restore();
}

function WDFinTrace(bTexte,bSansFond,bFondSeul)
{
	var o=(!bTexte)&&goDessin.m_bOpacite&&(goDessin.m_nOpaciteTrait<OPACITE_MAX);
	WDChangeOpacite(o,goDessin.m_nOpaciteTrait);
	if((!bTexte)&&(!bFondSeul)) goDC.stroke();
	WDRestaureOpacite(o);
	var f=bFondSeul||((!bTexte)&&(!bSansFond));
	o=f&&goDessin.m_bOpacite&&(goDessin.m_nOpaciteFond<OPACITE_MAX);
	WDChangeOpacite(o,goDessin.m_nOpaciteFond);
	if(f) goDC.fill();
	WDRestaureOpacite(o);
	goDC.restore();
	goDessin.MajImage();
}

function dAffiche()
{
	goDessin.AfficheImage();
}

function nWDDistance(nX1,nX2)
{
	return Math.abs(nX2-nX1);
}

function nWDRayon(nX1,nY1,nX2,nY2)
{
	return Math.min(nWDDistance(nX1,nX2),nWDDistance(nY1,nY2))/2;
}

function nWDMilieu(nX1,nX2)
{
	return nWDDistance(nX1,nX2)/2;
}

function nWDCentre(nX1,nX2,nRayon)
{
	return Math.min(nX1,nX2)+nRayon;
}

function nWDAngle(nX1,nY1,nX2,nY2)
{
	return (Math.PI/2)-Math.atan2(nX2-nX1,nY2-nY1);
}

function WDArcEchelle(nX1,nX2,nY1,nY2,nAngle1,nAngle2,bSens,bLien)
{
	var r=nWDRayon(nX1,nY1,nX2,nY2);
	var x=nWDCentre(nX1,nX2,r);
	var y=nWDCentre(nY1,nY2,r);
	goDC.beginPath();
	if(bLien) goDC.moveTo(x,y);
	var l=nWDDistance(nX1,nX2);
	var h=nWDDistance(nY1,nY2);
	var b=l>h;
	var f=b?(l/h):1;
	var g=b?1:(h/l);
	goDC.save();
	goDC.scale(f,g);
	goDC.arc((Math.min(nX1,nX2)/f)+r,(Math.min(nY1,nY2)/g)+r,r,nAngle1,nAngle2,bSens);
	goDC.restore();
}

function WDArc(nX1,nY1,nX2,nY2,nX3,nY3,nX4,nY4,bLien)
{
	var r=nWDRayon(nX1,nY1,nX2,nY2);
	var x=nWDCentre(nX1,nX2,r);
	var y=nWDCentre(nY1,nY2,r);
	WDArcEchelle(nX1,nX2,nY1,nY2,nWDAngle(x,y,nX3,nY3),nWDAngle(x,y,nX4,nY4),true,bLien);
}

function dArc(nX1,nY1,nX2,nY2,nX3,nY3,nX4,nY4,nCouleur)
{
	if(!bWDInitTrace(nX1,nY1,nCouleur)) return;
	WDArc(nX1,nY1,nX2,nY2,nX3,nY3,nX4,nY4);
	WDFinTrace(false,true);
}

function dCercle(nX1,nY1,nX2,nY2,nCouleurFond,nCouleurTrait)
{
	if(!bWDInitTrace(nX1,nY1,nCouleurTrait,nCouleurFond)) return;
	WDArcEchelle(nX1,nX2,nY1,nY2,0,Math.PI*2,false);
	WDFinTrace();
}

function dChangeMode(nMode)
{
	if(!bWDDessinOK()) return;
	goDC.globalCompositeOperation=(nMode==dessinXOR)?"xor":"source-over";
}

function nWDParamLargeur(oImg,nVal)
{
	return (nVal!=null)?nVal:oImg.offsetWidth;
}

function nWDParamHauteur(oImg,nVal)
{
	return (nVal!=null)?nVal:oImg.offsetHeight;
}

function nWDParamCoord(nVal)
{
	return (nVal!=null)?nVal:0;
}

function bWDSwapImg(oImg)
{
	if(!DessinDisponible()) return false;
	goDessinSauv=goDessin;
	oWDInitDessin(oImg,dSansEffacer+((bWDDessinOK()&&goDessin.m_bOpacite)?dAvecOpacite:0));
	return bWDDessinOK();
}

function WDRestaureImg()
{
	if(goDessinSauv==null) return;
	goDessin=goDessinSauv;
	goDC=goDessin.m_oDC;
}

function dCopieImage(oImgSrc,oImgDst,nMode,nXSrc,nYSrc,nHSrc,nLSrc,nXDst,nYDst,nHDst,nLDst)
{
	if(!bWDSwapImg(oImgDst)) return;
	goDC.save();
	goDC.globalCompositeOperation=(nMode==copieSrcEfface)?"source-in":((nMode==copieFusionPeint)?"source-out":((nMode==copieImage)?"source-atop":((nMode==copiePasSrcCopie)?"destination-over":((nMode==copieFusionCopie)?"destination-in":((nMode==copiePatInverse)?"destination-out":((nMode==copiePatPeint)?"destination-atop":((nMode==copiePatCopie)?"lighter":((nMode==copieSrcInverse)?"xor":"source-over"))))))));
	goDC.drawImage(oImgSrc,nWDParamCoord(nXSrc),nWDParamCoord(nYSrc),nWDParamLargeur(oImgSrc,nLSrc),nWDParamHauteur(oImgSrc,nHSrc),nWDParamCoord(nXDst),nWDParamCoord(nYDst),nWDParamLargeur(oImgDst,nLDst),nWDParamHauteur(oImgDst,nHDst));
	goDC.restore();
	goDessin.MajImage();
	WDRestaureImg();
}

function WDTrait(nX1,nY1,nX2,nY2)
{
	goDC.moveTo(nX1,nY1);
	goDC.lineTo(nX2,nY2);
}

function dCorde(nX1,nY1,nX2,nY2,nX3,nY3,nX4,nY4,nCouleurFond,nCouleurTrait)
{
	if(!bWDInitTrace(nX1,nY1,nCouleurTrait,nCouleurFond)) return;
	WDArc(nX1,nY1,nX2,nY2,nX3,nY3,nX4,nY4);
	goDC.closePath();
	WDFinTrace();
}

function WDDetruit(i)
{
	if(gTabDessin[i]==null) return;
	gTabDessin[i].Effacer();
	gTabDessin[i].destructor();
	gTabDessin[i]=null;
}

function dFinDessin(oImg)
{
	if(oImg!=null)
	{
		var i=nWDIndiceImage(oImg);
		if(bWDDessinOK(i)) WDDetruit(i);
		return;
	}
	for(var i=0;i<gTabDessin.length;i++) WDDetruit(i);
}

function dFond(nCouleur,nStyle,nHachure,nOpacite)
{
	if(!bWDDessinOK()) return;
	WDInitCouleurFond((nStyle==1)?TRANSPARENT:nCouleur);
	if(nOpacite!=null) goDessin.m_nOpaciteFond=nOpacite;
}

function dInverseCouleur(oImg)
{
	if(!bWDSwapImg(oImg)) return false;
	var d=goDessin.oImage();
	for(var i=0;i<goDessin.nNbPixel();i++) goDessin.ModifCouleurIndice(d,i,~goDessin.nCouleurIndice(d,i));
	goDessin.ModifImage(d,oImg);
	WDRestaureImg();
	return true;
}

function dLigne(nX1,nY1,nX2,nY2,nCouleur,nEpaisseur)
{
	if(!bWDInitTrace(nX1,nY1,nCouleur,null,nEpaisseur)) return;
	goDC.lineTo(nX2,nY2);
	WDFinTrace();
}

function dModifieTSL(oImg,nTeinte,nSaturation,nLuminosite,oImgDst)
{
	if(!bWDSwapImg(oImg)) return false;
	var d=goDessin.oImage();
	for(var i=0;i<goDessin.nNbPixel();i++)
	{
		var c=new WDCouleur(goDessin.nCouleurIndice(d,i));
		goDessin.ModifCouleurIndice(d,i,c.nModifieTSL(nTeinte,nSaturation,nLuminosite),null,true);
		delete c;
	}
	goDessin.ModifImage(d,oImgDst);
	WDRestaureImg();
	return true;
}

function dModifieLuminosite(oImg,nLuminosite,oImgDst)
{
	return dModifieTSL(oImg,0,0,nLuminosite,oImgDst);
}

function dModifieSaturation(oImg,nSaturation,oImgDst)
{
	return dModifieTSL(oImg,0,nSaturation,0,oImgDst);
}

function dModifieTeinte(oImg,nTeinte,oImgDst)
{
	return dModifieTSL(oImg,nTeinte,0,0,oImgDst);
}

function bWDVerifImgXY(bImg,oImg,nX,nY)
{
	return ((!bImg)||bWDSwapImg(oImg))&&bWDDessinOK()&&(nX>=0)&&(nY>=0)&&(nX<goDessin.nLargeur())&&(nY<goDessin.nHauteur());
}

function nWDResultat(oImage,nRes,bImg)
{
	delete oImage;
	if(bImg) WDRestaureImg();
	return nRes;
}

function dPixelCouleur(oImg,nX,nY)
{
	var i=(oImg!=null);
	if(!bWDVerifImgXY(i,oImg,nX,nY)) return 0;
	var d=goDessin.oImage();
	var r=goDessin.nCouleurXY(d,nX,nY);
	return nWDResultat(d,r,i);
}

function dPixelOpacite(oImg,nX,nY)
{
	var i=(oImg!=null);
	if(!bWDVerifImgXY(i,oImg,nX,nY)) return 0;
	var d=goDessin.oImage();
	var r=goDessin.nOpaciteXY(d,nX,nY);
	return nWDResultat(d,r,i);
}

function dPoint(nX,nY,nCouleur,nOpacite)
{
	if(!bWDDessinOK()) return;
	var d=goDessin.oImage();
	goDessin.ModifCouleurXY(d,nX,nY,nWDCouleurVersEntier((nCouleur!=null)?nCouleur:goDC.strokeStyle));
	goDessin.ModifImage(d);
}

function sWDAjoutAttributPolice(sPolice,bAjout,sAttribut)
{
	if(bAjout) sPolice+=((sPolice=="")?"":" ")+sAttribut;
	return sPolice;
}

function dPolice(sPolice,nTaille,nAttrib,nAngle)
{
	if(!bWDDessinOK()) return;
	var s="";
	s=sWDAjoutAttributPolice(s,bWDTestFlag(nAttrib,iItalique),"italic");
	s=sWDAjoutAttributPolice(s,bWDTestFlag(nAttrib,iGras),"bold");
	s=sWDAjoutAttributPolice(s,nTaille!=null,""+nTaille+"pt");
	goDC.font=sWDAjoutAttributPolice(s,sPolice!=null,sPolice);
	/*+(bWDTestFlag(nAttrib,iBarre)?(" stroke"):"")+(bWDTestFlag(nAttrib,iSouligne)?SOULIGNE:"")*/;
	goDessin.m_fAngle=-fWDDegreVersRadian(nAngle);
}

function dPolygone()
{
	if(arguments.length<1) return;
	var b=arguments.length<4;
	if(b&&(arguments[0].length<4)) return;
	var t=b?arguments[0]:arguments;
	var n=b?(t.length/2):t[0];
	var c=(2*n)+1;
	if((b&&(!bWDInitTrace(t[0],t[1],arguments[2],arguments[1])))||((!b)&&((t.length<5)||(!bWDInitTrace(t[1],t[2],t[c+1],t[c]))))) return;
	var d=b?0:1;
	for(var i=d;i<2*n;i+=2) goDC.lineTo(t[i],t[i+1]);
	goDC.closePath();
	WDFinTrace();
}

function dPortion(nX1,nY1,nX2,nY2,nX3,nY3,nX4,nY4,nCouleurFond,nCouleurTrait)
{
	if(!bWDInitTrace(nX1,nY1,nCouleurTrait,nCouleurFond)) return;
	WDArc(nX1,nY1,nX2,nY2,nX3,nY3,nX4,nY4,true);
	goDC.closePath();
	WDFinTrace();
}

function dRectangle(nX1,nY1,nX2,nY2,nCouleurFond,nCouleurTrait)
{
	if(!bWDInitTrace(nX1,nY1,nCouleurTrait,nCouleurFond)) return;
	goDC.rect(Math.min(nX1,nX2),Math.min(nY1,nY2),nWDDistance(nX1,nX2),nWDDistance(nY1,nY2));
	WDFinTrace();
}

function WDAjoutCouleurDegrade(oDegrade,nCouleur,nDistance)
{
	if(nCouleur!=null) oDegrade.addColorStop(nDistance/100,sWDCouleurVersChaine(nCouleur));
}

function fWDDegreVersRadian(nAngle)
{
	return nAngle*(Math.PI/180)
}

function dRectangleDegrade(nX1,nY1,nX2,nY2,nCouleurDebut,nCouleurFin,nAngle,nCouleur3,nDistance3,nCouleur4,nDistance4)
{
	if(!bWDInitTrace(nX1,nY1)) return;
	var a=fWDDegreVersRadian(nAngle%360);
	var q=(a==(Math.PI/2))||(a==((3*Math.PI)/2));
	var c=q?0:Math.tan(a);
	var p=(a==0)||(a==Math.PI);
	var e=p?0:Math.tan(a+(Math.PI/2));
	var g=nX1;
	var f=nX2;
	if((a>(Math.PI/2))&&(a<=((3*Math.PI)/2)))
	{
		g=nX2;
		f=nX1;
	}
	var h=nY1;
	var b=nY2;
	if(a>Math.PI)
	{
		h=nY2;
		b=nY1;
	}
	var x=p?f:(q?g:(((c*g)-(e*f)+b-h)/(c-e)));
	var d=goDC.createLinearGradient(g,h,x,(c*(x-g))+(q?b:h));
	WDAjoutCouleurDegrade(d,nCouleurDebut,0);
	WDAjoutCouleurDegrade(d,nCouleurFin,100);
	WDAjoutCouleurDegrade(d,nCouleur3,nDistance3);
	WDAjoutCouleurDegrade(d,nCouleur4,nDistance4);
	goDC.fillStyle=d;
	goDC.rect(Math.min(nX1,nX2),Math.min(nY1,nY2),nWDDistance(nX1,nX2),nWDDistance(nY1,nY2));
	WDFinTrace(false,false,true);
}

function oWDCanvaCopie()
{
	var o=oCreerCanvas();
	o.width=goDessin.nLargeur();
	o.height=goDessin.nHauteur();
	return o;
}

function dRedimensionne(oImg,nLargeur,nHauteur)
{
	if(!bWDSwapImg(oImg)) return false;
	var o=oWDCanvaCopie();
	oDCCanvas(o).scale(nLargeur/goDessin.nLargeur(),nHauteur/goDessin.nHauteur());
	goDessin.MajImage(null,o);
	WDRestaureImg();
	return true;
}

function dRemplissage(nX,nY,nCouleur,nCouleurStop)
{
	if(!bWDDessinOK()) return;
	var d=goDessin.oImage();
	goDessin.PropageCouleur(d,nX,nY,nWDCouleurVersEntier((nCouleur!=null)?nCouleur:goDC.fillStyle),nWDCouleurVersEntier(nCouleurStop));
	goDessin.ModifImage(d);
}

function dRotation(oImg,nAngle)
{
	if(!bWDSwapImg(oImg)) return false;
	var a=fWDDegreVersRadian(nAngle);
	var l=goDessin.nLargeur()/2;
	var h=goDessin.nHauteur()/2;
	var b=Math.atan(l/h);
	var c=b-a;
	var r=h/Math.cos(b);
	var o=oWDCanvaCopie();
	var d=oDCCanvas(o);
	d.translate(l-(r*Math.sin(c)),h-(r*Math.cos(c)));
	d.rotate(a);
	goDessin.MajImage(null,o);
	WDRestaureImg();
	return true;
}

function dTexte(nX,nY,sTexte,nCouleur,bSouligne)
{
	if(nCouleur==null) nCouleur=((goDC.strokeStyle!=TRANSPARENT)&&(goDC.strokeStyle!="rgba(0, 0, 0, 0.0)"))?goDC.strokeStyle:0;
	if(!bWDInitTrace(nX,nY,nCouleur,nCouleur)) return;
	goDessin.Texte(nX,nY,sTexte,bSouligne);
	WDFinTrace();
}

function dSauveImage(oImg,sMem,nNbCouleur,sFormat,nQualite)
{
	if(!bWDSwapImg(oImg)) return false;
	var r="";
	try { r=goDessin.m_oCanvas.toDataURL("image/"+sFormat.toLowerCase()); } catch(e) { };
	WDRestaureImg();
	return r;
}

function dSauveImageBMP(oImg,sMem,nNbCouleur)
{
	return dSauveImage(oImg,sMem,nNbCouleur,"bmp");
}

function dSauveImageGIF(oImg,sMem,nNbCouleur)
{
	return dSauveImage(oImg,sMem,nNbCouleur,"gif");
}

function dSauveImageJPEG(oImg,sMem,nQualite,nMarqueur)
{
	return dSauveImage(oImg,sMem,null,"jpeg",((nQualite==null)?80:nQualite)/100);
}

function dSauveImagePNG(oImg,sMem,nCouleurTransparence)
{
	return dSauveImage(oImg,sMem,null,"png");
}

function dStylo(nCouleur,nStyle,nEpaisseur,nOpacite)
{
	if(!bWDDessinOK()) return;
	WDInitCouleurTrait((nStyle==5)?TRANSPARENT:nCouleur);
	WDInitEpaisseurTrait(nEpaisseur);
	if(nOpacite!=null) goDessin.m_nOpaciteTrait=nOpacite;
}

function dSymetrieHorizontale(oImg)
{
	if(!bWDSwapImg(oImg)) return false;
	var o=oWDCanvaCopie();
	oDCCanvas(o).transform(1,0,0,-1,0,goDessin.nHauteur());
	goDessin.MajImage(null,o);
	WDRestaureImg();
	return true;
}

function dSymetrieVerticale(oImg)
{
	if(!bWDSwapImg(oImg)) return false;
	var o=oWDCanvaCopie();
	oDCCanvas(o).transform(-1,0,0,1,goDessin.nLargeur(),0);
	goDessin.MajImage(null,o);
	WDRestaureImg();
	return true;
}

function InfoBitmap(sImg)
{
	var f="BAD"
	var e=f+"\t\t\t";
	if((sImg==null)||(sImg.length==0)) return e;
	var i=new Image();
	i.src=sImg;
	var t=sImg.lastIndexOf(".");
	var r=((i.width>0)&&(i.height>0))?(((t>Math.max(sImg.lastIndexOf("\\"),sImg.lastIndexOf("/")))?sImg.substring(t+1,sImg.length):f)+"\t"+i.width+"\t"+i.height+"\t0"):e;
	delete i;
	return r;
}

function TSL(nTeinte,nSaturation,nLuminosite)
{
	var c=new WDCouleur(0);
	var r=c.nModifieTSL(nTeinte-c.m_nTeinte,nSaturation-c.m_nSaturation,nLuminosite-c.m_nLuminosite);
	delete c;
	return r;
}
