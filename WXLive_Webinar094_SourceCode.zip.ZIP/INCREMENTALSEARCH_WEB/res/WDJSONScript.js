//#17.0.1.0 WDJSONScript.js
//VersionVI: 30A170078p
// Le seul support technique disponible pour cette librairie est
// accessible a travers le service "Assistance Directe".

// Attention a ne pas mettre d'accent dans ce fichier COMMENTAIRES inclus

// Classe representant un appel JSONScript

function WDJSONScriptRequete (nId, sURL, sParamCallback, pCallback)
{
	// Init des membres a memoriser
	this.m_nId = nId;
	this.m_pCallback = pCallback;
	this.m_sNomCallback = "WDJSONScriptRequete_" + nId;

	// Creation de la callback
	window[this.m_sNomCallback] = function() { clWDJSONScriptMain.Appel(nId, arguments[0]); };

	// Creation de la balise src
	var oScript = document.createElement("script");
	// Et cible de la balise
	oScript.src = sURL + ((sURL.indexOf('?') == -1) ? '?' : '&') + sParamCallback + '=' + this.m_sNomCallback;
	oScript.charset = "UTF-8";

	// Et ajout de la balise dans la page
	this.m_oScript = document.body.appendChild(oScript);
};

WDJSONScriptRequete.prototype.AppelCallback = function AppelCallback(oValeur)
{
	// Appele la callback utilisateur
	this.m_pCallback(oValeur);

	// Supprime la balise de la page
	clWDUtil.oSupprimeElement(this.m_oScript);
	delete this.m_oScript;
	this.m_oScript = null;

	// Supprime la callback globale intermediaire
	// On ne peut pas la supprimer donc on la met a null pour ne pas perdre trop de memoire
	window[this.m_sNomCallback] = null;
};

// Classe de suivi des appels JSONScript

function WDJSONScriptMain ()
{
	this.m_tabRequete = [];	// Tableau des requetes
	this.m_nIdPos = 1;		// Id de connection
};

// Creation d'un nouvel appel
WDJSONScriptMain.prototype.JSONScriptExecute = function JSONScriptExecute(sURL, sParamCallback, fCallback)
{
	// Creation et appel
	this.m_tabRequete[this.m_nIdPos] = new WDJSONScriptRequete(this.m_nIdPos, sURL, sParamCallback, fCallback);
	// Numero suivant
	this.m_nIdPos++;
};

// Appel de la callback pour un element donne
WDJSONScriptMain.prototype.Appel = function Appel(nId, oValeur)
{
	this.m_tabRequete[nId].AppelCallback(oValeur);
	// Supprime l'objet
	delete this.m_tabRequete[nId];
};

// On instancie un objet principal
var clWDJSONScriptMain = new WDJSONScriptMain();
