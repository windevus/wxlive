//#17.0.1.0 WDMenu.js
//VersionVI: 30A170078p
// Le seul support technique disponible pour cette librairie est
// accessible a travers le service "Assistance Directe".

// Manipulation des menus
function WDMenu (sAliasChamp, bOnglet)
{
	// Si on est pas dans l'init d'un protoype
	if (sAliasChamp)
	{
		// Appel le constructeur de la classe de base
		WDChamp.prototype.constructor.apply(this, [sAliasChamp, undefined, undefined]);

		this.m_bOnglet = bOnglet;
	}
};

// Declare l'heritage
WDMenu.prototype = new WDChamp();
// Surcharge le constructeur qui a ete efface
WDMenu.prototype.constructor = WDMenu;

// Initialisation
WDMenu.prototype.Init = function Init()
{
	// Appel de la methode de la classe de base
	WDChamp.prototype.Init.apply(this, arguments);

	// Trouve la racine du menu
	this.m_oRacine = _JGE(this.m_sAliasChamp, document, true, false);

	// Si le menu n'existe pas (menu invisible avec l'option ne pas generer les champ hidden)
	if (!this.m_oRacine)
	{
		return;
	}

	// Applique le changement de style et l'affichage des sous menus en survol d'option
	if (this.m_bOnglet)
	{
		// Traite les onglets
		this.AjouteJSSurvolOnglet(this.m_oRacine);
	}
	// Traite les sous menus normaux
	this.AjouteJSSurvolSousMenu(this.m_oRacine);
};

// Applique le changement de style et l'affichage des onglets
WDMenu.prototype.AjouteJSSurvolOnglet = function AjouteJSSurvolOnglet(oRacine)
{
	// Les options sont les TD avec WDOngletOption comme class
	var tabOnglets = oRacine.getElementsByTagName("td");
	var i;
	var nLimiteI = tabOnglets.length;
	for (i = 0; i < nLimiteI; i++)
	{
		var oOnglet = tabOnglets[i];
		if ((oOnglet.className == "WDOngletOption") || (oOnglet.className == "WDOngletOptionSelect"))
		{
			var bAvecSousMenu = false;
			// Cherche sont eventuel sous menu
			var tabTABLE = oOnglet.getElementsByTagName("table");
			var j;
			var nLimiteJ = tabTABLE.length;
			for (j = 0; j < nLimiteJ; j++)
			{
				var oTABLE = tabTABLE[j];
				if (oTABLE.parentNode.className == "WDSousOnglet")
				{
					bAvecSousMenu = true;
					this.AjouteJSSurvol_SousMenu(oOnglet, oTABLE);
				}
			}

			// Si on a pas de sous menu : mettre le code de survol
			if (!bAvecSousMenu)
			{
				this.AjouteJSSurvol_Simple(oOnglet);
			}
		}
	}
};

// Applique le changement de style et l'affichage des sous menus en survol d'option
WDMenu.prototype.AjouteJSSurvolSousMenu = function AjouteJSSurvolSousMenu(oRacine)
{
	// Liste les fils de la balise et trouve la balise TR si elle existe
	var tabOptionsMenu = oRacine.getElementsByTagName("tr");
	var i;
	var nLimiteI = tabOptionsMenu.length;
	for (i = 0; i < nLimiteI; i++)
	{
		// Applique le changement de style et l'affichage des sous menus en survol d'un option
		this.AjouteJSSurvol(tabOptionsMenu[i]);
	}
};

// Applique le changement de style et l'affichage des sous menus en survol d'un option
WDMenu.prototype.AjouteJSSurvol = function AjouteJSSurvol(oOptionMenu)
{
	// Si le style de la ligne n'est pas celui d'une option
	if ((oOptionMenu.className != "WDMenuOption") && (oOptionMenu.className != "WDMenuOptionSelect"))
	{
		return;
	}

	// Regarde si l'option a un sous menu
	var tabSousMenus = oOptionMenu.getElementsByTagName("table");

	if (tabSousMenus.length)
	{
		this.AjouteJSSurvol_SousMenu(oOptionMenu, tabSousMenus[0]);
	}
	else
	{
		this.AjouteJSSurvol_Simple(oOptionMenu);
	}
};

// Ajoute les fonctions JS en survol pour une option avec un sous menu
WDMenu.prototype.AjouteJSSurvol_SousMenu = function AjouteJSSurvol_SousMenu(oOptionMenu, oSousMenu)
{
	// Sauve la classe normale de l'option
	oOptionMenu.oldClassName = oOptionMenu.className;

	oOptionMenu.onmouseover = function(oEvent)
	{
		oOptionMenu.className = oOptionMenu.oldClassName + "Hover";
		// Seulement si le menu n'est pas desactive
		// La norme indique que les elements sont retournes dans l'ordre => On demand le premier donc [0]
		var tabLiens = oOptionMenu.getElementsByTagName("a");
		if (!(tabLiens && (bIE ? tabLiens[0].disabled : tabLiens[0].attributes.getNamedItem("disabled"))))
		{
			clWDUtil.SetDisplay(oSousMenu, true);
		}
	};
	oOptionMenu.onmouseout = function(oEvent)
	{
		// Pas de traitement de oEvent pour IE/autres : on ne l'utilise pas ici
		oOptionMenu.className = oOptionMenu.oldClassName;
		clWDUtil.SetDisplay(oSousMenu, false);
	};

};

// Ajoute les fonctions JS en survol pour une option sans sous menu
WDMenu.prototype.AjouteJSSurvol_Simple = function AjouteJSSurvol_Simple(oOptionMenu)
{
	// Sauve la classe normale de l'option
	oOptionMenu.oldClassName = oOptionMenu.className;

	// Pas de traitement de oEvent pour IE/autres : on ne l'utilise pas ici
	oOptionMenu.onmouseover = function(oEvent) { oOptionMenu.className = oOptionMenu.oldClassName + "Hover"; };
	oOptionMenu.onmouseout = function(oEvent) { oOptionMenu.className = oOptionMenu.oldClassName; };
};

// Execute le clic sur le fond d'une option
WDMenu.prototype.OnClick = function OnClick(oEvent)
{
	// Filtre les clics qui sont sur la zone du lien
	var oSource = clWDUtil.oGetOriginalTarget(oEvent);

	// On ne fait l'action que si le clic n'est pas sur la zone du lien
	// Avec certaines version de firefox, on recoit la balise texte a l'interieur du lien
	if (!oSource || clWDUtil.bBaliseEstTag(oSource, "a") || (oSource.parentNode && clWDUtil.bBaliseEstTag(oSource.parentNode, "a")))
	{
		return;
	}

	// On trouve maintenant l'action en consultant le href du lien
	var oTR = oSource
	while (oTR && !clWDUtil.bBaliseEstTag(oTR, "tr"))
	{
		// Ne remonte pas jusqu'au document
		if (oTR == document.body)
		{
			return;
		}

		oTR = oTR.parentNode;
	}

	// Recupere la balise A
	var tabA = oTR.getElementsByTagName("a");
	if (tabA && tabA.length && tabA[0])
	{
		var sAction = tabA[0].href;
		if (sAction && sAction.length)
		{
			if (sAction.substring(0, "javascript:".length) == "javascript:")
			{
				sAction = sAction.substring("javascript:".length);
			}
			eval(sAction);
		}
	}
};
