//#17.0.1.0 WDSaisieRiche.js
//VersionVI: 30A170078p
// Le seul support technique disponible pour cette librairie est
// accessible a travers le service "Assistance Directe".

// Le champ contient plusieurs elements :
// Role									ID			Membre
// - Un INPUT type="hidden"				ALIAS		m_oValeur
// - Un DIV/TD/Autres hote racine		ALIAS_HTE	m_oHote
//	- (IE)Un DIV editable				ALIAS_EDT	m_oData		Construit dynamiquement
//	- (FF/Autres)IFrame					ALIAS_EDT				Construit dynamiquement
//		- BODY editable								m_oData		Construit dynamiquement

// Manipulation d'un bouton On/Off du champ de saisie
function WDBarreBoutonOnOffRiche (oObjetParent, oBouton, sCommande, sStyle, tabStyleValeur)
{
	// Si on est pas dans l'init d'un protoype
	if (oObjetParent)
	{
		// Appel le constructeur de la classe de base
		WDBarreBoutonOnOff.prototype.constructor.apply(this, [oObjetParent, oBouton, "ExecuteCommande", [sCommande, false, null]]);

		// Sauve les parametres specifiques
		this.m_sStyle = sStyle;
		// Valeurs que l'on recherche ou que l'on evite dans le style
		// Chaque valeur est un couple : valeur (sVal, bTst)
		// Si le booleen est a vrai on recherche style == this.m_sStyleValeur, a faux on recherche !=
		this.m_tabStyleValeur = tabStyleValeur;
	}
};

// Declare l'heritage
WDBarreBoutonOnOffRiche.prototype = new WDBarreBoutonOnOff();
// Surcharge le constructeur qui a ete efface
WDBarreBoutonOnOffRiche.prototype.constructor = WDBarreBoutonOnOffRiche;

// Declare les fonction une par une

// Execute la commande : methode definie dans les classes derivees
WDBarreBoutonOnOffRiche.prototype.ExecuteCommande = function(oEvent)
{
	// Sauve le range courant
	var oDataEtat = this.m_oObjetParent.oGetParamEtat(oEvent, false);
	// Il ne faut pas forcer sur les commandes a effet immediat
	if (oDataEtat[0] && (this.m_sStyle != "textAlign"))
	{

		// Efface un ancien etat
		if (this.m_oRange)
		{
			delete this.m_oRange;
			delete this.m_bForceActif;
		}

		// Inverse l'etat
		switch (this.nGetEtatSpecifique(oEvent, this.ms_nEtatNormal, oDataEtat))
		{
		case this.ms_nEtatNormal:
			this.m_bForceActif = true;
			break;
		case this.ms_nEtatActif:
			this.m_bForceActif = false;
			break;
		}

		this.m_oRange = oDataEtat[0];
	}

	// Execute la commande
	WDBarreBoutonOnOff.prototype.ExecuteCommande.apply(this, arguments);
};

// Si on doit manipuler l'etat surcharge

// Applique ensuite l'etat d'activation
WDBarreBoutonOnOffRiche.prototype.bActif = function (oEvent, oDataEtat)
{
	// Si on a un range memorise et que la selection est identique : retourne la valeur
	if (this.m_oRange)
	{
		try
		{
			if (this.m_oObjetParent.bCompareRange(this.m_oRange, oDataEtat[0]))
			{
				return this.m_bForceActif;
			}
		}
		catch (e)
		{
		}
		// La selection a change
		delete this.m_oRange;
		delete this.m_bForceActif;
	}

	if (oDataEtat[2] && this.m_sStyle.length)
	{
		switch (this.m_oParamCommande[0])
		{
		case "italic":
			// Le style italique utilise la balise EM qui ne change pas le style
			// => Cas particulier
			if (this.__bStyleMatchRecursif(oDataEtat[1], "em") != false)
			{
				return true;
			}
			break;
		case "underline":
			// Le souligne et le barre se partage le meme style et cascadent mais sans que cela se voit dans le style
			// Teste le style local et le style des parents
			if (this.__bStyleMatchRecursif(oDataEtat[1], "u") != false)
			{
				return true;
			}
			break;
		case "strikeThrough":
			if (this.__bStyleMatchRecursif(oDataEtat[1], "strike") != false)
			{
				return true;
			}
			break;
		case "bold":
			// Pour chrome qui retourne "normal" au lieu de "400" : cas particulier
			if (oDataEtat[2][this.m_sStyle] == "normal")
			{
				return false;
			}
			// Pas de break
		default:
			if (this.__bStyleMatch(oDataEtat[2][this.m_sStyle]))
			{
				return true;
			}
			break;
		}
	}
	// L'etat n'est pas actif
	return false;
};

// Verifie si l'element matche le style en pronfondeur
WDBarreBoutonOnOffRiche.prototype.__bStyleMatchRecursif = function(oElement, sBalise)
{
	// Teste le style local et le style des parents
	while (oElement && (oElement != this.m_oObjetParent.m_oData))
	{
		// Si le style match ou que l'on a une balise specifique
		if ((this.__bStyleMatch(_JGCS(oElement)[this.m_sStyle])) || (oElement.tagName && clWDUtil.bBaliseEstTag(oElement, sBalise)))
		{
			return true;
		}
		oElement = oElement.parentNode;
	}
	return false;
};

// Verifie si l'element matche le style
WDBarreBoutonOnOffRiche.prototype.__bStyleMatch = function(sValeur)
{
	var i;
	var nLimiteI = this.m_tabStyleValeur.length;
	for (i = 0; i < nLimiteI; i++)
	{
		var oTest = this.m_tabStyleValeur[i];
		// Comme this.m_tabStyleValeur est une reference sur un tableau inline, on semble lister aussi la propriete .length que l'on ne veux pas
		if (oTest)
		{
			if (oTest.bTst)
			{
				if (sValeur == oTest.sVal)
				{
					return true;
				}
			}
			else
			{
				if (sValeur != oTest.sVal)
				{
					return true;
				}
			}
		}
	}
	return false;
};

// Manipulation d'un bouton dropdown du champ de saisie
function WDBarreBoutonPopupRiche(oObjetParent, oBouton, sCommande, oPopup, sSuffixe)
{
	// Si on est pas dans l'init d'un protoype
	if (oObjetParent)
	{
		// Appel le constructeur de la classe de base
		WDBarreBoutonPopup.prototype.constructor.apply(this, [oObjetParent, oBouton, "ExecuteCommande", [sCommande, false, null], oPopup]);

		// Traduit les textes dans la popup
		var tabLibelle = HTML_TOOLBAR[sSuffixe];
		if (tabLibelle)
		{
			var tabSpan = oPopup.getElementsByTagName("span");
			var i = 0;
			var nLimiteI = tabSpan.length;
			for (i = 0; i < nLimiteI; i++)
			{
				var oSpan = tabSpan[i];
				SupprimeFils(tabSpan[i]);
				if (tabLibelle[i] !== undefined)
				{
					tabSpan[i].appendChild(document.createTextNode(tabLibelle[i]));
				}
			}
		}
	}
};

// Declare l'heritage
WDBarreBoutonPopupRiche.prototype = new WDBarreBoutonPopup();
// Surcharge le constructeur qui a ete efface
WDBarreBoutonPopupRiche.prototype.constructor = WDBarreBoutonPopupRiche;

// Declare les fonction une par une

// Clic sur une couleur : "vraie" commande
WDBarreBoutonPopupRiche.prototype.OnClickP = function(oEvent)
{
	var oSource = bIE ? oEvent.srcElement : oEvent.target;
	// Filtre les clics autour des couleurs
	if (clWDUtil.bBaliseEstTag(oSource, "div"))
	{
		// Trouve la couleur
		this.m_oParamCommande[2] = _JGCS(oSource).backgroundColor;

		// Execute la commande de la classe de base deux niveau au dessus
		WDBarreBouton.prototype.ExecuteCommande.apply(this, [oEvent]);
	}

	// Ferme la popup
	WDBarreBoutonPopup.prototype.OnClickP.apply(this, arguments);
};

// Manipulation d'une combo du champ de saisie
function WDSaisieRicheCbm (oObjetParent, oCombo, sCommande, sStyle, tabValeurs, sSuffixe)
{
	this.m_oObjetParent		= oObjetParent;
	this.m_oCombo			= oCombo;
	this.m_sCommande		= sCommande;
	this.m_sStyle			= sStyle;

	// Pour la validation W3C, il faut au moins une option dans les combos :
	// La generation ajoute une option dans la combo, et je la supprime ici
	this.m_oCombo.options.length = 0;

	// Recherche le tableau des traductions
	var tabLibelle = HTML_TOOLBAR[sSuffixe];

	// Remplit la combo
	var i;
	var nLimiteI = tabValeurs.length;
	for (i = 0; i < nLimiteI; i++)
	{
		var clValeur = tabValeurs[i];
		// Comme tabValeurs est une reference sur un tableau inline, on semble lister aussi la propriete .length que l'on ne veux pas
		if (clValeur)
		{
			// Construit le libelle
			var sLibelle = clValeur.sN;
			if (tabLibelle && tabLibelle[i])
			{
				sLibelle = tabLibelle[i] + " (" + sLibelle + ")";
			}
			this.m_oCombo.options[this.m_oCombo.options.length] = new Option(sLibelle, clValeur.sV);
		}
	}

	// Hook les methodes des boutons
	// Uniquement si le parent n'est pas dans une ZR
	// Si le parent est dans une ZR, le hook est fait au deplacement de la barre
	if (!(oObjetParent.bGestionZR()))
	{
		this.PostPlaceBarre();
	}
};

// Hook les boutons
// Le fait de deplacer la barre fait perdre le hook sur onchange des combos
WDSaisieRicheCbm.prototype.PrePlaceBarre = function PrePlaceBarre()
{
	this.m_oCombo.onchange = null;
};

// Le fait de deplacer la barre fait perdre le hook sur onchange des combos
WDSaisieRicheCbm.prototype.PostPlaceBarre = function PostPlaceBarre()
{
	var oThis = this;
	this.m_oCombo.onchange = function(oEvent) { oThis.OnChange(oEvent || event); }
};

WDSaisieRicheCbm.prototype.OnChange = function OnChange(oEvent)
{
	// Memorise le range courant
	var oRange = this.m_oObjetParent.oGetRange();
	if (oRange)
	{
		this.m_oRange = oRange;
	}

	// Execute la commande (rafraichit le bouton en interne)
	this.m_oObjetParent.ExecuteCommande(oEvent, [this.m_sCommande, false, this.m_oCombo.options[this.m_oCombo.selectedIndex].value]);
};

// Rafraichit le bouton
WDSaisieRicheCbm.prototype.RafEtatSimple = function RafEtatSimple(oEvent)
{
	this.RafEtat(oEvent, this.m_oObjetParent.oGetParamEtat(oEvent, false));
};

WDSaisieRicheCbm.prototype.RafEtat = function RafEtat(oEvent, oDataEtat)
{
	// Si on a un range memorise et que la selection est identique : retourne la valeur
	if (this.m_oRange)
	{
		try
		{
			if (this.m_oObjetParent.bCompareRange(this.m_oRange, oDataEtat[0]))
			{
				// Ne fait rien (ne change pas l'etat)
				return;
			}
		}
		catch (e)
		{
		}
		// La selection a change
		delete this.m_oRange;
	}

	// Si on n'a pas de style
	if (!oDataEtat[2])
	{
		return;
	}

	// On pretraite la valeur du style pour eviter les valeurs transforme de firefox
	var sValeurStyleCal = oDataEtat[2][this.m_sStyle];

	// Cas de la taille de la police
	switch (this.m_sCommande)
	{
	case "FontSize":
		this.__RafEtat_Taille(oEvent, sValeurStyleCal);
		break;
	case "FontName":
		this.__RafEtat_Police(oEvent, sValeurStyleCal);
		break;
	case "FormatBlock":
		this.__RafEtat_Format(oEvent, oDataEtat[1]);
		break;
	default:
		break;
	}
};

// Traite la selection de la taille de la police
WDSaisieRicheCbm.prototype.__RafEtat_Taille = function __RafEtat_Taille(oEvent, sValeurStyleCal)
{
	// Supprime les '
	sValeurStyleCal.replace(/'/g, "");

	// Cas de la taille transformee en px
	if (sValeurStyleCal.charAt(sValeurStyleCal.length - 2) == 'p')
	{
		var dTaille = parseFloat(sValeurStyleCal);
		if (sValeurStyleCal.charAt(sValeurStyleCal.length - 1) == 't')
		{
			dTaille *= 96.0 / 72.0;
		}
		if (dTaille < 11.5)			// 10 => 1
		{
			sValeurStyleCal = "1";
		}
		else if (dTaille < 14.5)	// 13 => 2
		{
			sValeurStyleCal = "2";
		}
		else if (dTaille < 17)		// 16 => 3
		{
			sValeurStyleCal = "3";
		}
		else if (dTaille < 21)		// 18 => 4
		{
			sValeurStyleCal = "4";
		}
		else if (dTaille < 28)		// 24 => 5
		{
			sValeurStyleCal = "5";
		}
		else if (dTaille < 40)		// 32 => 6
		{
			sValeurStyleCal = "6";
		}
		else						// 48 => 7
		{
			sValeurStyleCal = "7";
		}
	}

	// Selectionne l'element dans la combo
	var nOption;
	var tabOptions = this.__tabRechercheValeurCombo(sValeurStyleCal, function(sValeur, oOption) { return (sValeur.toUpperCase() == oOption.value.toUpperCase()); });
	if (tabOptions.length > 0)
	{
		nOption = tabOptions[0];
	}
	else
	{
		// Element non trouve dans la combo : l'ajoute a la combo
		nOption = this.m_oCombo.options.length;
		this.m_oCombo.options[nOption] = new Option(sValeurStyleCal, sValeurStyleCal);
	}
	this.__Selection(nOption);
};

// Transforme une liste de police en tableau
WDSaisieRicheCbm.prototype.__tabSplitPolices = function __tabSplitPolices(sValeur)
{
	// Commence par separer les differentes valeurs
	var tabPolices = sValeur.split(',');
	// Puis supprime les apostrophes et espaces au debut
	var i;
	var nLimiteI = tabPolices.length;
	for (i = 0; i < nLimiteI; i++)
	{
		var nTaille = tabPolices[i].length;
		while ((nTaille > 0) && ((tabPolices[i].charAt(0) == "'") || (tabPolices[i].charAt(0) == " ")))
		{
			tabPolices[i] = tabPolices[i].substring(1);
			nTaille--;
		}
		while ((nTaille > 0) && ((tabPolices[i].charAt(nTaille - 1) == "'") || (tabPolices[i].charAt(nTaille - 1) == " ")))
		{
			tabPolices[i] = tabPolices[i].substring(0, nTaille - 1);
			nTaille--;
		}
	}
	return tabPolices;
};

// Traite la selection du style de la police
WDSaisieRicheCbm.prototype.__RafEtat_Police = function __RafEtat_Police(oEvent, sValeurStyleCal)
{
	// Commence par separer les differentes valeurs
	var tabPolices = this.__tabSplitPolices(sValeurStyleCal);
	var sSubStitutionReconstruite = tabPolices.join(',');

	// Recherche la police dans la combo avec le texte
	var fTest = function(sValeur, oOption)
	{
		// Transforme la valeur en tableau
		return (sValeur.toUpperCase() == WDSaisieRicheCbm.prototype.__tabSplitPolices(oOption.value)[0].toUpperCase());
	}

	var nOption;
	var tabOptions = this.__tabRechercheValeurCombo(tabPolices[0], fTest);
	if (tabOptions.length > 0)
	{
		// Test si on a une valeur identique
		var i;
		var nLimiteI = tabOptions.length;
		for (i = 0; i < nLimiteI; i++)
		{
			if (this.__tabSplitPolices(this.m_oCombo.options[tabOptions[i]].value).join(',').toUpperCase() == sSubStitutionReconstruite.toUpperCase())
			{
				// Trouvee
				nOption = tabOptions[i];
				break;
			}
		}
		if (nOption === undefined)
		{
			// On n'a pas d'option complete : ajoute un doublon
			nOption = this.m_oCombo.options.length;
			this.m_oCombo.options[nOption] = new Option(tabPolices[0] + '(' + sSubStitutionReconstruite + ')', sSubStitutionReconstruite);
		}
	}
	else
	{
		// On n'a pas l'option et pas de doublon : ajoute simplement
		nOption = this.m_oCombo.options.length;
		this.m_oCombo.options[nOption] = new Option(tabPolices[0], sSubStitutionReconstruite);
	}
	this.__Selection(nOption);
};

// Traite la selection formatage logique
WDSaisieRicheCbm.prototype.__RafEtat_Format = function __RafEtat_Format(oEvent, oElement)
{
	// Si on est dans le click sur la combo : ne fait pas MAj (ie)
	if (bIE && oEvent && clWDUtil.bBaliseEstTag(oEvent.srcElement, "select"))
	{
		return;
	}

	// Selectionne le premier element par defaut (format par defaut)
	var nOption = 0;

	// Remonte les parents pour rechercher un conteneur correct
	var oBody = this.m_oObjetParent.m_oData;
	while (oElement && (oElement != oBody))
	{
		var sTag = "<" + clWDUtil.sGetTagName(oElement) + ">";
		var tabOptions = this.__tabRechercheValeurCombo(sTag, function(sValeur, oOption) { return (sValeur == oOption.value); });
		if (0 < tabOptions.length)
		{
			nOption = tabOptions[0];
			break;
		}

		oElement = oElement.parentNode;
	}

	this.__Selection(nOption);
};

WDSaisieRicheCbm.prototype.__tabRechercheValeurCombo = function __tabRechercheValeurCombo(sValeur, fbFonction)
{
	var tabOptions = [];
	var i;
	var nLimiteI = this.m_oCombo.options.length;
	for (i = 0; i < nLimiteI; i++)
	{
		if (fbFonction(sValeur, this.m_oCombo.options[i]))
		{
			// Trouve
			tabOptions.push(i);
		}
	}
	return tabOptions;
};

// Selectionne un element dans la combo
WDSaisieRicheCbm.prototype.__Selection = function __Selection(nOption)
{
	if (this.m_oCombo.selectedIndex != nOption)
	{
		this.m_oCombo.selectedIndex = nOption;
	}
};


// Manipulation d'un champ de saisie HTML
function WDSaisieRiche(sAliasChamp, eModeBarre, sImageSurvol, sImageActif, sAliasZR, sAliasAttribut)
{
	// Si on est pas dans l'init d'un protoype
	if (sAliasChamp)
	{
		// Appel le constructeur de la classe de base
		WDBarre.prototype.constructor.apply(this, [sAliasChamp, sAliasZR, sAliasAttribut, eModeBarre, sImageSurvol, sImageActif]);

		var oThis = this;
		if (bIE)
		{
			this.m_fKeyDown = function(event) { return oThis.bOnKeyDown(event); }
		}
		this.m_fRafBarreTrue = function(oEvent) { return oThis.RafBarre(oEvent || event, true); }
		this.m_fRafBarreSans = function(oEvent) { return oThis.RafBarre(oEvent || event); }
	}
};

// Declare l'heritage
WDSaisieRiche.prototype = new WDBarre();
// Surcharge le constructeur qui a ete efface
WDSaisieRiche.prototype.constructor = WDSaisieRiche;

// Membres statiques
WDSaisieRiche.prototype.ms_sSuffixeEditeur = "_EDT";
WDSaisieRiche.prototype.ms_tabPropBordureSav = ["borderTopWidth", "borderTopStyle", "borderTopColor",
												"borderLeftWidth", "borderLeftStyle", "borderLeftColor",
												"borderRightWidth", "borderRightStyle", "borderRightColor",
												"borderBottomWidth", "borderBottomStyle", "borderBottomColor"];
// Description de la barre
// - Le type (m_nBoutonXXX ou ms_nCombo)
// - Le suffixe du nom
// - La commande/la fonction (pour les boutons commandes)
// - Le style
// - Les parametres
WDSaisieRiche.prototype.m_tabDescBarre = [
// Boutons OnOff
	{ nType: 0, sSuf: "GRA", sCom: "bold", sSty: "fontWeight", tabP: [{ sVal: "400", bTst: false}] },
	{ nType: 0, sSuf: "ITA", sCom: "italic", sSty: "fontStyle", tabP: [{ sVal: "italic", bTst: true }, { sVal: "oblique", bTst: true}] },
	{ nType: 0, sSuf: "SOU", sCom: "underline", sSty: "textDecoration", tabP: [{ sVal: "underline", bTst: true}] },
	{ nType: 0, sSuf: "BAR", sCom: "strikeThrough", sSty: "textDecoration", tabP: [{ sVal: "line-through", bTst: true}] },
	{ nType: 0, sSuf: "AGA", sCom: "JustifyLeft", sSty: "textAlign", tabP: [{ sVal: "left", bTst: true}] },
	{ nType: 0, sSuf: "ACE", sCom: "JustifyCenter", sSty: "textAlign", tabP: [{ sVal: "center", bTst: true}] },
	{ nType: 0, sSuf: "ADR", sCom: "JustifyRight", sSty: "textAlign", tabP: [{ sVal: "right", bTst: true}] },
	{ nType: 0, sSuf: "AJU", sCom: "JustifyFull", sSty: "textAlign", tabP: [{ sVal: "justify", bTst: true}] },
	{ nType: 0, sSuf: "LNU", sCom: "InsertOrderedList", sSty: "", tabP: [] },
	{ nType: 0, sSuf: "LPU", sCom: "InsertUnorderedList", sSty: "", tabP: [] },
	{ nType: 0, sSuf: "RMO", sCom: "Outdent", sSty: "", tabP: [] },
	{ nType: 0, sSuf: "RPL", sCom: "Indent", sSty: "", tabP: [] },
	{ nType: 0, sSuf: "EXP", sCom: "superscript", sSty: "", tabP: [] },
	{ nType: 0, sSuf: "IND", sCom: "subscript", sSty: "", tabP: [] },
// Boutons popup
	{ nType: 1, sSuf: "COF", sCom: "BackColor" },
	{ nType: 1, sSuf: "COL", sCom: "ForeColor" },
// Boutons action
	{ nType: 2, sSuf: "LNK", sCom: "OnLink" },
	{ nType: 2, sSuf: "IMG", sCom: "OnImage" },
// Combo
	{ nType: 3, sSuf: "FNA", sCom: "FontName", sSty: "fontFamily", tabP: [
			{ sN: "Arial", sV: "Arial,Helvetica,sans-serif" },
			{ sN: "Courier", sV: "Courier New,Courier,mono" },
			{ sN: "Geneva", sV: "Geneva,Verdana,Arial,Helvetica" },
			{ sN: "Georgia", sV: "Georgia,Times New Roman,Times" },
			{ sN: "Helvetica", sV: "Helvetica" },
			{ sN: "Tahoma", sV: "Tahoma,Arial,Helvetica,sans-serif" },
			{ sN: "Times New Roman", sV: "Times New Roman,Times,serif" },
			{ sN: "Verdana", sV: "Verdana,Geneva,Arial,Helvetica" }
		]
	},
	{ nType: 3, sSuf: "FSI", sCom: "FontSize", sSty: "fontSize", tabP: [
			{ sN: "1", sV: "1" },
			{ sN: "2", sV: "2" },
			{ sN: "3", sV: "3" },
			{ sN: "4", sV: "4" },
			{ sN: "5", sV: "5" },
			{ sN: "6", sV: "6" },
			{ sN: "7", sV: "7" }
		]
	},
	{ nType: 3, sSuf: "FHE", sCom: "FormatBlock", sSty: "", tabP: [
			{ sN: "div", sV: "<div>" },
			{ sN: "h1", sV: "<h1>" },
			{ sN: "h2", sV: "<h2>" },
			{ sN: "h3", sV: "<h3>" },
			{ sN: "h4", sV: "<h4>" },
			{ sN: "h5", sV: "<h5>" },
			{ sN: "h6", sV: "<h6>" },
			{ sN: "pre", sV: "<pre>" }
//			{ sN: "mark", sV: "<mark>" }
		]
	},
];

// Declare les fonction une par une

// Initialisation
WDSaisieRiche.prototype.Init = function Init(tabBoutonsInfo)
{
	// Lance l'init interne qui gere le cas du 'reinit'
	// Rappele le Init de la classe de base
	this.__InitInterne(true, tabBoutonsInfo);
};

// Initialisation
WDSaisieRiche.prototype.__InitInterne = function __InitInterne(bInitInitiale, tabBoutonsInfo)
{
	// Si on est pas dans l'init initiale : supprime tout les elements initialises
	if (!bInitInitiale)
	{
		this.__Uninit();
	}

	// Initialise les membres et le contenu
	this.__Init1(bInitInitiale);

	if (bInitInitiale)
	{
		// Appel de la methode de la classe de base
		// Fait ici car on a besoin d'une partie de l'initalisation de __InitCommun
		WDBarre.prototype.Init.apply(this, [tabBoutonsInfo]);
	}

	// Fini l'initalisation
	// true : initialisation initiale
	this.__Init2(bInitInitiale);
};

// Initialise ou reinitialise les membres qui font reference au HTML
// Cree aussi l'iframe
WDSaisieRiche.prototype.__Init1 = function __Init1(bInitInitiale)
{
	// Si on est dans une ZR AJAX : ne fait rien sur les champs
	if (this.oGetZRAjax())
	{
		return;
	}

	// Initialise les membres
	this.m_oValeur = this.oGetElementByIdZR(document, "");
	this._vLiaisonHTML();

	// Si c'est l'init initiale recupere le tabindex d'une des valeurs
	// Si on est dans une ZR tout les champs ont le meme tabindex donc cela ne pose pas de problemes
	// On peut ne pas avoir this.m_oHote si la ligne selectionne n'est pas sur la page courante
	if (bInitInitiale && this.m_oHote)
	{
		// Reporte si besoin l'attribut TABINDEX
		var oTabIndex = this.m_oHote.attributes.getNamedItem("TABINDEX");
		if (oTabIndex)
		{
			this.m_sTabIndex = oTabIndex.nodeValue;
			// Supprime l'attribut du parent
			this.m_oHote.removeAttribute("TABINDEX", 0);
		}
	}

	// Construit le contenu
	this.__InitCommun();
};

// Inverse les elements important de __Init1 (pour ne pas garder des references croisees perdu dans IE)
WDSaisieRiche.prototype.__Uninit1 = function()
{
	// Si on est dans une ZR AJAX : ne fait rien sur les champs
	if (this.oGetZRAjax())
	{
		return;
	}

	// Supprime le contenu
	// En particulier suppression de tous les hooks des lignes hors de la ligne selectionnee de la ZR
	this.__UninitCommun();

	if (this.m_oHote)
	{
		// Restaure la bordure de l'hote
		if (bIEQuirks)
		{
			// Restaure le style de la bordure de l'hote pour IE
			var sProp;
			for (sProp in this.m_oHoteStyleBordure)
			{
				this.m_oHote.style[sProp] = this.m_oHoteStyleBordure[sProp];
			}
			delete this.m_oHoteStyleBordure;
		}
		else
		{
			this.m_oHote.style.border = "";
		}
		SupprimeFils(this.m_oHote);
	}
	this.m_oHote = null; delete this.m_oHote;
	this.m_oValeur = null; delete this.m_oValeur;
};

// Fini l'initalisation
WDSaisieRiche.prototype.__Init2 = function(bInitInitiale)
{
	// Si on est dans une ZR : place la barre d'outils
	// On peut ne pas avoir oHoteBarre si la ligne selectionne n'est pas sur la page courante
	if (this.bGestionZR())
	{
		this.DeplaceBarre(this.oGetElementByIdZRIndice(document, this.nGetZRValeur(), this.ms_sSuffixeCommande));
	}

	// Cree/Recree le lien avec la barre d'outils si besoin
	this.__InitHookDocumentBarre();

	// Fixe la valeur
	// On peut ne pas avoir m_oData/m_oValeur si la ligne selectionne n'est pas sur la page courante
	if (this.m_oData && this.m_oValeur)
	{
		this.__EcraseContenu(this.m_oValeur.value);
	}

	// Met a jour la barre d'outils
	this.RafBarre(null);

	// Initialisation specifique
	this.__InitSpecifique(bInitInitiale);
};

// Inverse les elements important de __Init2 (pour ne pas garder des references croisees perdu dans IE)
WDSaisieRiche.prototype.__Uninit2 = function()
{
	// Pour ie : unhook de keydown
	this.__UninitSpecifique();

	// Unhook le document
	this.__UnhookDocumentBarre();
};

// Supprime tout les hooks en cas de reinitialisation du champ
WDSaisieRiche.prototype.__Uninit = function()
{
	// Si on est dans une ZR AJAX : ne fait rien sur les champs
	if (this.oGetZRAjax())
	{
		return;
	}

	// Appel les initialisation dans l'ordre inverse de l'initialisation
	this.__Uninit2();
	this.__Uninit1();
};

// Change l'etat du champ
WDSaisieRiche.prototype.SetEtat = function(eEtat)
{
	// Appel de la methode de la classe de base
	WDBarre.prototype.SetEtat.apply(this, arguments);

	// Traite les modifications
	this.__ActiveModeEditable();
};

// Active le mode editable
WDSaisieRiche.prototype.__ActiveModeEditable = function()
{
	var bContentEditable;
	var sDesignMode;
	var sCouleurFond;

	// Selon l'etat
	switch (this.eGetEtat())
	{
	default:
	case WDChamp.prototype.ms_eEtatActif:
		bContentEditable = true;
		sDesignMode = "on";
		sCouleurFond = "";
		break;

	case WDChamp.prototype.ms_eEtatLectureSeule:
		bContentEditable = false;
		sDesignMode = "off";
		sCouleurFond = "";
		break;

	case WDChamp.prototype.ms_eEtatGrise:
		bContentEditable = false;
		sDesignMode = 'off';
		sCouleurFond = 'InactiveBorder';
		break;
	}

	// On peut ne pas avoir m_oData/m_oDocument si la ligne selectionne n'est pas sur la page courante
	if (this.m_oData && this.m_oDocument)
	{
		if (bIE)
		{
			// Passe en mode editable
			this.m_oDocument.contentEditable = bContentEditable;
			this.m_oData.contentEditable = bContentEditable;
		}
		else
		{
			// Passe en mode editable uniquement si l'element est visible
			if (_JGCS(this.m_oHote).display != "none")
			{
				this.m_oDocument.designMode = sDesignMode;
			}
		}
		this.m_oData.style.backgroundColor = sCouleurFond;
	}
};

// Reactive le mode d'edition (pour firefox uniquement)
WDSaisieRiche.prototype.__ReactiveModeEditable = function()
{
	if (!bIE)
	{
		// Uniquement si l'element est visible
		// Si l'element est invisible, la modification sera faite quand l'element est rendu visible
		if (_JGCS(this.m_oHote).display != "none")
		{
			this.m_oDocument.designMode = 'off';

			// Selon l'etat
			switch (this.eGetEtat())
			{
			default:
			case WDChamp.prototype.ms_eEtatActif:
				this.m_oDocument.designMode = 'on';
				break;

			case WDChamp.prototype.ms_eEtatLectureSeule:
			case WDChamp.prototype.ms_eEtatGrise:
				// Laisse desactive
				break;
			}
		}
	}
};

// Initialisation commune des contenus : IFrame ou HTML direct dans les ZR
WDSaisieRiche.prototype.__InitCommun = function()
{
	// Si on est pas dans une ZR
	if (!this.bGestionZR())
	{
		// Initialise directement l'IFrame
		this.__InitCommunIFrame();
	}
	else
	{
		this.__InitCommunZR();
	}
};

// Initialisation commune de l'IFrame
WDSaisieRiche.prototype.__InitCommunIFrame = function()
{
	// Construit l'IFRAME interne
	var oIFrame = document.createElement("iframe");
	oIFrame.id = this.sGetNomElement(this.ms_sSuffixeEditeur);
	oIFrame.src = "javascript:\"\"";

	// Copie la bordure de l'hote sur l'iframe
	var oStyleHote = _JGCS(this.m_oHote);
	// Sauve le style de la bordure de l'hote pour IE
	if (bIEQuirks)
	{
		this.m_oHoteStyleBordure = {};
		var sProp;
		for (sProp in this.ms_tabPropBordureSav)
		{
			var sNomProp = this.ms_tabPropBordureSav[sProp];
			this.m_oHoteStyleBordure[sNomProp] = oStyleHote[sNomProp];
		}
	}
	oIFrame.style.border = oStyleHote.borderLeftWidth + ' ' + oStyleHote.borderLeftStyle + ' ' + oStyleHote.borderLeftColor;
	this.m_oHote.style.border = '0px solid transparent';
	this.__OnResize(null, oIFrame, oIFrame.style);
	oIFrame.frameBorder = "0";
	oIFrame.border = "0";

	// Reporte si besoin l'attribut TABINDEX
	if (this.m_sTabIndex)
	{
		oIFrame.tabIndex = this.m_sTabIndex;
	}

	// L'ajoute au document
	SupprimeFils(this.m_oHote);
	this.m_oIFrame = this.m_oHote.appendChild(oIFrame);

	// Document a manipuler
	this.m_oDocument = this.m_oIFrame.contentWindow.document;

	// Construit le contenu de l'IFRAME
	var sIFrameHTML = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">";
	// Cela ne semble pas fonctionner dans certaines version de FireFox sans le xmlns
	sIFrameHTML += clWDUtil.bRTL ? "<HTML dir=\"rtl\">" : "<HTML>";
	sIFrameHTML += "<HEAD xmlns=\"http://www.w3.org/1999/xhtml\">";
	// Recupere le style du texte
	var sStyleBase = this.__sGetStyleBase();
	sIFrameHTML += "<style type=\"text/css\">BODY{margin:1px;overflow:auto;" + sStyleBase + "}</style>";
	sIFrameHTML += "<META http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" /><BASE href=\"" + _WD_ + "\" /></HEAD><BODY></BODY></HTML>";

	// L'ecrit
	this.m_oDocument.open();
	this.m_oDocument.write(sIFrameHTML);
	this.m_oDocument.close();

	// Memorise les donnees
	this.m_oData = this.m_oDocument.body;
};

// Initialisation commune des contenus dans une ZR : IFrame ou HTML direct dans les ZR
WDSaisieRiche.prototype.__InitCommunZR = function()
{
	this.PourToutesLignesZR(this.__InitCommunZR_CB, this.nGetZRValeur());
};
WDSaisieRiche.prototype.__InitCommunZR_CB = function __InitCommunZR_CB(nLigneAbsolueBase1, nValeur)
{
	if (nLigneAbsolueBase1 != nValeur)
	{
		// Initialise une valeur sans le HTML
		this.__InitCommunZR_HTML(nLigneAbsolueBase1);
	}
	else
	{
		// Initialise l'IFrame
		this.__InitCommunZR_IFrame(nLigneAbsolueBase1);
	}
};

// Initialisation commune des contenus dans une ZR : IFrame
WDSaisieRiche.prototype.__InitCommunZR_IFrame = function(nIndice)
{
	// On ne peut pas le faire maintenant car this.m_oBarre n'est pas encore defini
//	// Place la barre d'outils
//	this.m_oBarre = this.oGetElementByIdZRIndice(document, nIndice, this.ms_sSuffixeCommande).insertBefore(this.m_oBarre, null);

	// Init l'IFrame
	if (this.m_oHote)
	{
		this.__InitCommunIFrame();
	}
};

// Initialisation commune des contenus dans une ZR : HTML
WDSaisieRiche.prototype.__InitCommunZR_HTML = function(nIndice)
{
	// Place simplement la valeur HTML
	var oValeur = this.oGetElementByIdZRIndice(document, nIndice, "");
	var oHote = this.oGetElementByIdZRIndice(document, nIndice, this.ms_sSuffixeHote);

	if (!oValeur || !oHote)
	{
		return;
	}

	// Applique la couleur selon l'etat
	var oAttribut = oValeur.attributes.getNamedItem("DISABLED");
	oHote.style.backgroundColor = (oAttribut && oAttribut.specified) ? "InactiveBorder" : "";
	// Pour avoir un asenseur et ne pas deformer la page
	oHote.style.overflow = "auto";
	// Maintenant que l'hote est pret : ecrit la valeur
	oHote.innerHTML = oValeur.value;

	// Se branche sur le onclick de l'element pour pourvoir changer de ligne
	// normalement il n'y a pas de code de onclick sur l'hote donc on n'a pas besoin de gerer le cas
	var oThis = this;
	oHote.onclick = function(oEvent) { oThis.OnClickLigne(oEvent || event, nIndice); };
};

// Inverse les elements important de __InitCommun (pour ne pas garder des references croisees perdu dans IE)
WDSaisieRiche.prototype.__UninitCommun = function()
{
	// Si on est dans une ZR : suppression des onclick sur les elements
	if (this.bGestionZR())
	{
		this.__UninitCommunZR();
	}

	// Suppression de l'iframe et des membres
	this.m_oData = null; delete this.m_oData;
	this.m_oDocument = null; delete this.m_oDocument;
	this.m_oIFrame = null; delete this.m_oIFrame;
};

// Inverse les elements important de __InitCommunZR (pour ne pas garder des references croisees perdu dans IE)
// (sauf la gestion de l'iframe qui est manipule globalement)
WDSaisieRiche.prototype.__UninitCommunZR = function()
{
	// Pour toutes les lignes de la ZR : Uninitialise une valeur dans le HTML
	this.PourToutesLignesZR(this.__UninitCommunZR_HTML);
};
WDSaisieRiche.prototype.__UninitCommunZR_HTML = function(nIndice)
{
	// Trouve simplement la valeur HTML
	var oHote = this.oGetElementByIdZRIndice(document, nIndice, this.ms_sSuffixeHote);
	if (oHote)
	{
		SupprimeFils(oHote);
		oHote.onclick = null;
	}
};

// Initialisation specifique
WDSaisieRiche.prototype.__InitSpecifique = function __InitSpecifique(bInitInitiale)
{
	// Met a jour le mode lecture seule/grise du champ
	if (this.m_oValeur)
	{
		var bLectureSeule = false;
		var oAttribut = this.m_oValeur.attributes.getNamedItem("READONLY");
		if (oAttribut && oAttribut.specified)
		{
			// Appele directement la methode de la classe de base car on ne veux pas modifier maintenant l'iframe
			// (fait par __ActiveModeEditable)
			WDBarre.prototype.SetEtat.apply(this, [this.ms_eEtatLectureSeule]);
			bLectureSeule = true;
		}
		// Grise est prioritaire sur lecture seule
		var bGrise = false;
		oAttribut = this.m_oValeur.attributes.getNamedItem("DISABLED");
		if (oAttribut && oAttribut.specified)
		{
			// Appele directement la methode de la classe de base car on ne veux pas modifier maintenant l'iframe
			// (fait par __ActiveModeEditable)
			WDBarre.prototype.SetEtat.apply(this, [this.ms_eEtatGrise]);
			bGrise = true;
		}

		// Si on n'est pas en lecture seule ou en grise, et que l'on n'etait pas actif, passe en actif
		if (!bLectureSeule && !bGrise && (this.ms_eEtatActif != this.eGetEtat()))
		{
			WDBarre.prototype.SetEtat.apply(this, [this.ms_eEtatActif]);
		}
	}

	// Passe en mode editable
	this.__ActiveModeEditable();

	// Pour ie : hook de keydown pour gerer le cas des balises P a remplacer par des br
	if (bIE)
	{
		// On peut ne pas avoir m_oData si la ligne selectionne n'est pas sur la page courante
		if (this.m_oDocument)
		{
			HookOnXXX(this.m_oDocument, 'onkeydown', 'keydown', this.m_fKeyDown);
		}
	}
};

// Desinitialisation specifique
WDSaisieRiche.prototype.__UninitSpecifique = function()
{
	// pas besoin de supprimer le mode editable

	// Pas besoin de supprimer la fonction de redimensionnement : elle est globale

	// Pour ie : hook de keydown pour gerer le cas des balises P a remplacer par des br
	if (bIE)
	{
		// On peut ne pas avoir m_oData si la ligne selectionne n'est pas sur la page courante
		if (this.m_oDocument)
		{
			UnhookOnXXX(this.m_oDocument, 'onkeydown', 'keydown', this.m_fKeyDown);
		}
	}
};

// Rearenge le style pour supprimer les doublons
WDSaisieRiche.prototype.__sOptimiseStyle = function(sStyle)
{
	// Separe la chaine en couple separee par ;
	var tabStyle = sStyle.split(";");
	var tabStyleOpt = [];
	var i;
	var nLimiteI = tabStyle.length
	for (i = 0; i < nLimiteI; i++)
	{
		var sStyleElement = tabStyle[i];
		if (sStyleElement && (sStyleElement.length > 0))
		{
			// Separe le nom et la valeur
			var tabElement = sStyleElement.split(":");
			// Supprime les espaces
			tabElement[0] = clWDUtil.sSupprimeEspaces(tabElement[0]);
			if (tabElement[0] && (tabElement[0].length > 0))
			{
				// Ignore les attribut width et height
				switch (tabElement[0].toLowerCase())
				{
				case "width":
				case "height":
					break;
				default:
					// Si le style est deja present le replace sinon le cree
					tabStyleOpt[tabElement[0]] = tabElement[1];
					break;
				}
			}
		}
	}

	// Reconstruit la chaine
	// On ne peut pas utiliser join car les indexs sont importants
	var sStyleOpt = "";
	var sCle;
	for (sCle in tabStyleOpt)
	{
		sStyleOpt += sCle + ":" + tabStyleOpt[sCle] + ";";
	}
	return sStyleOpt;
};

// Recupere le style par defaut du champ
WDSaisieRiche.prototype.__sGetStyleBase = function()
{
	var sStyle = "";

	// On ajoute TOUJOURS le style par l'id car le navigateur tient compte des deux
	// On les ajoute dans CET ordre car si une directive est dans les deux c'est l'ordre d'application du navigateur
	// des doulon de style sont possibles

	// Recupere le style du champ : convention avec la generation HTML, le style est celui sur le champ cache
	if (this.m_oValeur.className)
	{
		sStyle += clWDUtil.sGetCSSTexte("." + this.m_oValeur.className);
	}
	sStyle += clWDUtil.sGetCSSTexte("#" + this.m_sAliasChamp);

	// Si il y a un style inline sur la balise input, il faut l'ajouter
	sStyle += clWDUtil.sGetCSSTexteElement(this.m_oValeur);

	// Puis on rearenge le style pour supprimer les doublons
	return this.__sOptimiseStyle(sStyle);
};

// Initialise la barre d'outils
WDSaisieRiche.prototype._InitBarreAutomatique = function _InitBarreAutomatique()
{
	// Deplace en dehors de l'init de la barre pour ne pas avoir plein de cas : init initiale et init dans ZR
//	// Hook la gestion de la barre dans l'iframe
//	this.__InitHookDocumentBarre();

	// Ajoute le hook sur onkeyup et onclick
	// Cette init n'est faite que une fois donc pas besoin de fonction de unhook
	var oThis = this;
	HookOnXXX(document, 'onclick', 'click', this.m_fRafBarreSans);
	HookOnXXX(document, 'onkeyup', 'keyup', this.m_fRafBarreSans);
};

// Hook la gestion de la barre dans l'iframe
WDSaisieRiche.prototype.__InitHookDocumentBarre = function()
{
	// Le cas FF semble fonctioner aussi dans IE mais dans le doute je garde les deux cas
	// On peut ne pas avoir this.m_oData/this.m_oDocument si la ligne selectionne n'est pas sur la page courante
	var oCible = bIE ? this.m_oData : this.m_oDocument;
	if (oCible)
	{
		HookOnXXX(oCible, 'onclick', 'click', this.m_fRafBarreTrue);
		HookOnXXX(oCible, 'onkeyup', 'keyup', this.m_fRafBarreTrue);
	}
};

// Suppression de la gestion de la barre dans l'iframe
WDSaisieRiche.prototype.__UnhookDocumentBarre = function()
{
	var oCible = bIE ? this.m_oData : this.m_oDocument;
	if (oCible)
	{
		UnhookOnXXX(oCible, 'onclick', 'click', this.m_fRafBarreTrue);
		UnhookOnXXX(oCible, 'onkeyup', 'keyup', this.m_fRafBarreTrue);
	}
};

// Creation des boutons de la barre d'outils

// Boutons on/off
WDSaisieRiche.prototype._voNewBoutonOnOff = function _voNewBoutonOnOff(oElementBarre, oDesc)
{
	return new WDBarreBoutonOnOffRiche(this, oElementBarre, oDesc.sCom, oDesc.sSty, oDesc.tabP);
};
// Boutons popup
WDSaisieRiche.prototype._voNewBoutonPopup = function _voNewBoutonPopup(oElementBarre, oDesc)
{
	var sSuffixe = oDesc.sSuf + "P";
	return new WDBarreBoutonPopupRiche(this, oElementBarre, oDesc.sCom, this.oGetElementByIdBarre(document, sSuffixe), sSuffixe);
};
// Boutons action
WDSaisieRiche.prototype._voNewBoutonAction = function _voNewBoutonAction(oElementBarre, oDesc)
{
	return new WDBarreBouton(this, oElementBarre, oDesc.sCom);
};
// Combos
WDSaisieRiche.prototype._voNewBoutonCombo = function _voNewBoutonCombo(oElementBarre, oDesc)
{
	return new WDSaisieRicheCbm(this, oElementBarre, oDesc.sCom, oDesc.sSty, oDesc.tabP, oDesc.sSuf);
};
//// Menus
//WDSaisieRiche.prototype._voNewBoutonMenu = function _voNewBoutonMenu(oElementBarre, oDesc)
//{
//	return null;
//};
//// Menus avec highlight du parent si un element est selectionne
//WDSaisieRiche.prototype._voNewBoutonMenuS = function _voNewBoutonMenuS(oElementBarre, oDesc)
//{
//	return null;
//};

// Gestion du click dans une ligne autre de la ZR
WDSaisieRiche.prototype.OnClickLigne = function(oEvent, nLigneAbsolueBase1)
{
	// Sauve le contenu de la ligne
	this.bSauveContenu(oEvent);

	// Dans le cas des ZR Ajax, il faut attendre la MAJ de la ZR par le serveur pour forcer la valeur sinon notre valeur est ecrasee
	// Appel de la methode automone qui supporte l'appel retarde
	this._OnClickLigneRetarde(oEvent, nLigneAbsolueBase1);
};

// Dans le cas des ZR Ajax, il faut attendre la MAJ de la ZR par le serveur pour forcer la valeur sinon notre valeur est ecrasee
// Appel de la methode automone qui supporte l'appel retarde
WDSaisieRiche.prototype._OnClickLigneRetarde = function(oEvent, nLigneAbsolueBase1)
{
	// Si on est dans une ZR Ajax, retarde l'appel tant que toutes les requetes ne sont pas traitees
	var oZRAjax = this.oGetZRAjax();
	if (oZRAjax && (oZRAjax.m_oCache.m_tabRequetes.length > 0))
	{
		this.nSetTimeout(this._OnClickLigneRetarde, 1, null, nLigneAbsolueBase1);
		return;
	}

	// Affecte la valeur de la ZR
	this.SetZRValeur(oEvent, nLigneAbsolueBase1);

	// Redessine tout
	this.__InitInterne(false);
};

// Evenement sur l'appuis d'une touche (remplace les <p> par des <BR /> en IE
WDSaisieRiche.prototype.bOnKeyDown = function (oEvent)
{
	// Selon le code du caractere
	// On est dans IE donc pas besoin de lire le membre de FF
	if (oEvent.keyCode == 13)
	{
		// Recupere la selection
		var oRange = this.oGetRange();
		if (oRange)
		{
			this.nSetTimeout(this.__SupprimeSPAN_BR_IE, 1);
			// Si on a une selection texte
			if (oRange["duplicate"] && ("" != oRange.htmlText))
			{
				// Uniquement si on est pas dans une balise de liste
				var oElement = this.oGetSelection(oRange);
				while (oElement && (oElement != this.m_oData))
				{
					// Selon la balise trouvee
					switch (clWDUtil.sGetTagName(oElement))
					{
					case "li":
						// Liste : ne fait rien
						return;
					case "p":
						// Paragraphe : arrete la recherche
						oElement = null;
						break;
					default:
						oElement = oElement.parentNode;
						break;
					}
				}

				// Puis supprime les SPAN utiliser pour avoir le bon focus dans IE
				this.__SupprimeSPAN_BR_IE();

				// Ajoute le caratere
				// Ajoute un SPAN pour forcer le retour a la ligne
				// Il sera supprime ulterieurement
				oRange.pasteHTML("<br /><span id=\"WDSaisieRiche_TMP\"></span>");
				oRange.collapse(false);
				oRange.scrollIntoView();

				// Bloque la propagation de l'evenement
				return clWDUtil.bStopPropagation(oEvent);
			}
			else
			{
				// La selection est un/des objets
				// Laisse IE faire seul car les objets controlRange ne permettent pas la manipulation simple
			}
		}
	}
};

// Supprime le SPAN utilise pour avoir le bon focus dans IE
WDSaisieRiche.prototype.__SupprimeSPAN_BR_IE = function(oEvent)
{
	if (bIE)
	{
		var oSPAN = this.m_oDocument.getElementById("WDSaisieRiche_TMP");
		while (oSPAN)
		{
			oSPAN.removeNode(false);
			// Logiquement il n'y a qu'un element (unicite de l'ID et suppression du precedent en ajout)
			oSPAN = this.m_oDocument.getElementById("WDSaisieRiche_TMP");
		}
		// Remplace les p par des div
		// On doit recalculer a chaque iteration car on peut avoir des p dans des p
		var tabP;
		while ((tabP = this.m_oDocument.getElementsByTagName("p")).length)
		{
			var i = 0;
			var nLimiteI = tabP.length;
			var bAvecSuppression = false;
			for (i = 0; i < nLimiteI; i++)
			{
//				var oP = tabP[i];
//				// Ignore les P originaux
//				if (oP.m_bOriginal)
//				{
//					continue;
//				}

				// On doit recalculer a chaque iteration car on peut avoir des p dans des p
				var oP = tabP[0];

				var oDIV = this.m_oDocument.createElement("div");
				while (oP.firstChild)
				{
					oDIV.appendChild(oP.firstChild);
				}
				// Si c'est le premier et qu'il est vide place un br
				if ((0 == oDIV.childNodes.length) && (!bAvecSuppression))
				{
					oDIV.appendChild(this.m_oDocument.createElement("br"));
				}
				oP.parentNode.replaceChild(oDIV, oP);
				// Suppression
				bAvecSuppression = true;
			}

			// Si on n'a plus de suppresion
			if (!bAvecSuppression)
			{
				break;
			}
		}
	}
};

// Evenement sur le rechargement du champ apres filtrage par la classe de base
WDSaisieRiche.prototype._vOnResize = function(oEvent)
{
	// Appel de la classe de base
	WDBarre.prototype._vOnResize.apply(this, arguments);

	// Ne fait rien si on a un redimensionnement en attente (IE)
	// Car dans ce cas le computedStyle de this.m_oIFrame n'existe pas (element non visible)
	if (this.m_oIFrameOnResizeInterne === undefined)
	{
		this.__OnResize(oEvent, this.m_oIFrame, _JGCS(this.m_oIFrame));
	}
};

// Evenement sur le rechargement du champ
WDSaisieRiche.prototype.__OnResize = function __OnResize(oEvent, oIFrame, oStyle)
{
	// Il faut tenir compte des bordure du parent
	var nLargeurOffset = this._nGetOffset(oStyle.borderLeftWidth) + this._nGetOffset(oStyle.borderRightWidth);
	var nHauteurOffset = this._nGetOffset(oStyle.borderTopWidth) + this._nGetOffset(oStyle.borderBottomWidth);

	if (bIEQuirks)
	{
		// Sauf si on est dans l'init et que l'iframe n'est pas encore dans l'hote
		if (this.m_oIFrame == oIFrame)
		{
			clWDUtil.oSupprimeElement(oIFrame);
		}
		// Appel de la version interne par timeout si on est dans un vrai redimensionnement
		if (oEvent)
		{
			// Modifie temporairement la taille de l'hote pour etre sur de la reduction (se reduit en hauteur mais pas en largeur)
			// La sauvegarde de la valeur (pour le cas en %) ne fonctionne que parce que l'on est en quirks et que l'on lit la valeur en %
			// Avec les autres navigateurs on recoit la valeur finale en px
			var oStyleHote = _JGCS(this.m_oHote);
			var sWidth = oStyleHote.width;
			var sHeight = oStyleHote.height;
			this.m_oHote.style.width = "1px"
			this.m_oHote.style.height = "1px";
			this.m_oIFrameOnResizeInterne = oIFrame
			this.nSetTimeoutUnique("__OnResizeInterneS1", 200, nLargeurOffset, nHauteurOffset, sWidth, sHeight);
			return;
		}
	}
	else
	{
		// On remet une taille extensible que que le m_oHote recalcule sa taille (utile en reduction)
		oIFrame.style.width = '100%';
		oIFrame.style.height = '100%';
		// Tous le reste semble inutile dans les navigateurs moderne : sort direct
		return;
	}

	// Appel direct de la version interne
	this.__OnResizeInterne(oIFrame, nLargeurOffset, nHauteurOffset);
};

// Versions interne
WDSaisieRiche.prototype.__OnResizeInterneS1 = function __OnResizeInterneS1(nLargeurOffset, nHauteurOffset, sWidth, sHeight)
{
	// Replace la taille du champ
	this.m_oHote.style.width = sWidth;
	this.m_oHote.style.height = sHeight;

	// Retourve le parametre
	var oIFrame = this.m_oIFrameOnResizeInterne;
	this.m_oIFrameOnResizeInterne = null;
	delete this.m_oIFrameOnResizeInterne;

	// Appel la version finale
	this.__OnResizeInterne(oIFrame, nLargeurOffset, nHauteurOffset);
};
WDSaisieRiche.prototype.__OnResizeInterne = function __OnResizeInterne(oIFrame, nLargeurOffset, nHauteurOffset)
{
	// Il faut tenir compte des bordure du parent
	var nLargeur = this.m_oHote.offsetWidth - nLargeurOffset;
	var nHauteur = this.m_oHote.offsetHeight - nHauteurOffset;

	if (bIEQuirks && (this.m_oIFrame == oIFrame))
	{
		this.m_oHote.appendChild(oIFrame);
	}
	// Filtre les valeurs negatives (possible si offsetXXX retourne 0 et que l'on supprime les bordures)
	oIFrame.style.width = ((nLargeur >= 0) ? nLargeur : 0) + "px";
	oIFrame.style.height = ((nHauteur >= 0) ? nHauteur : 0) + "px";
};

// Passe en mode editable les barres affichees
WDSaisieRiche.prototype.OnDisplay = function(oElementRacine)
{
	// Appel de la methode de la classe de base
	WDBarre.prototype.OnDisplay.apply(this, arguments);

	if (this.m_oHote && bEstFils(this.m_oHote, oElementRacine, document))
	{
		var bResize = true;
		// Deplace si besoin l'iframe (FF)
		// Si on a plusieurs champs de saisie dans le contenu il faut faire un parcours
		var bTrouve = false;
		var tabIFrame = oElementRacine.getElementsByTagName("iframe");
		var i;
		var nLimiteI = tabIFrame.length;
		for (i = 0; i < nLimiteI; i++)
		{
			if (this.m_oDocument == tabIFrame[i].contentWindow.document)
			{
				bTrouve = true;
				break;
			}
		}
		if (!bTrouve)
		{
			// Reinitialise les membres et le contenu
			this.__InitInterne(false);

			// On ne redimensionnera pas
			bResize = false;
		}

		this.__ReactiveModeEditable();

		// Et redimensionne la zone cliente si besoin
		if (bResize)
		{
			this.OnResize(null);
		}
	}
};

// - Tous les champs : notifie que une ZRs a ete MAJ en AJAX (= ZR non AJAX mais avec les ZR horizontales)
WDSaisieRiche.prototype._vOnZRAfficheAJAXInterne = function _vOnZRAfficheAJAXInterne()
{
	// Appel de la methode de la classe de base (qui normalement ne fait rien car on est une ZR donc pas dans une autre ZR)
	WDBarre.prototype._vOnZRAfficheAJAXInterne.apply(this, arguments);

	// MAJ du champ
	this.__InitInterne();
};

// Methode appele directement
// - Champ dans une ZR : notifie le champ de l'affichage/suppression de la ligne
WDSaisieRiche.prototype._vOnLigneZRAffiche = function _vOnLigneZRAffiche(nLigneAbsolueBase1, bSelectionne)
{
	// Appel de la methode de la classe de base
	WDBarre.prototype._vOnLigneZRAffiche.apply(this, arguments);

	// Si c'est la ligne selectionnee
	if (bSelectionne)
	{
		// Init 1

		// Initialise les membres
		this.m_oValeur = this.oGetElementByIdZRIndice(document, nLigneAbsolueBase1, "");
		this.m_oHote = this.oGetElementByIdZRIndice(document, nLigneAbsolueBase1, this.ms_sSuffixeHote);
		// Initialise l'IFrame
		this.__InitCommunZR_IFrame(nLigneAbsolueBase1 - 1);

		// Init 2
		this.DeplaceBarre(this.oGetElementByIdZRIndice(document, nLigneAbsolueBase1, this.ms_sSuffixeCommande));

		// Cree/Recree le lien avec la barre d'outils si besoin
		this.__InitHookDocumentBarre();

		// Fixe la valeur
		// On peut ne pas avoir m_oData/m_oValeur si la ligne selectionne n'est pas sur la page courante
		if (this.m_oData && this.m_oValeur)
		{
			this.__EcraseContenu(this.m_oValeur.value);
		}

		// Met a jour la barre d'outils
		this.RafBarre(null);

		// Initialisation specifique
		this.__InitSpecifique(false);
	}
	else
	{
		// Initialise une valeur dans le HTML
		this.__InitCommunZR_HTML(nLigneAbsolueBase1);
	}
};
WDSaisieRiche.prototype._vOnLigneZRMasque = function _vOnLigneZRMasque(nLigneAbsolueBase1, bSelectionne, oEvent)
{
	// Uninit 2

	// Si c'est la ligne selectionnee
	if (bSelectionne)
	{
		// Sauve la valeur
		this.bSauveContenu(oEvent);

		// Pour ie : unhook de keydown
		this.__UninitSpecifique();

		// Unhook le document
		this.__UnhookDocumentBarre();
	}

	// Trouve simplement la valeur HTML
	var oHote = this.oGetElementByIdZRIndice(document, nLigneAbsolueBase1, this.ms_sSuffixeHote);
	if (oHote)
	{
		// Restaure la bordure de l'hote
		if (bSelectionne)
		{
			if (bIE)
			{
				// Restaure le style de la bordure de l'hote pour IE
				var sProp;
				for (sProp in this.m_oHoteStyleBordure)
				{
					oHote.style[sProp] = this.m_oHoteStyleBordure[sProp];
				}
				delete this.m_oHoteStyleBordure;
			}
			else
			{
				oHote.style.border = "";
			}
		}

		SupprimeFils(oHote);
		oHote.onclick = null;
	}

	// Suppression de l'iframe et des membres
	if (bSelectionne)
	{
		this.m_oData = null; delete this.m_oData;
		this.m_oDocument = null; delete this.m_oDocument;
		this.m_oIFrame = null; delete this.m_oIFrame;

		// Uninit1

		// Restaure la bordure de l'hote : aucune importance on supprime la ligne

		this.m_oHote = null; delete this.m_oHote;
		this.m_oValeur = null; delete this.m_oValeur;
	}

	// Appel de la methode de la classe de base
	WDBarre.prototype._vOnLigneZRMasque.apply(this, arguments);
};

// Met a jour la barre d'outils
WDSaisieRiche.prototype.RafBarre = function(oEvent, bAfficheBarre)
{
	// Calcule l'etat de la barre dans tous les cas
	// Calcule si besoin si on doit afficher la barre
	if (bAfficheBarre === undefined)
	{
		// Regarde l'element actif dans le document
		var oA = null;
		if (!bIE && oEvent)
		{
			oA = clWDUtil.oGetOriginalTarget(oEvent);
		}
		if (!oA)
		{
			oA = document.activeElement;
			// Avec Firefox la valeur recue n'est pas forcement dans le document (c'est un objet externe donc sans acces)
			try
			{
				oA.parentNode;
			}
			catch (e)
			{
				oA = null;
			}
		}
		if (bEstFils(oA, this.m_oBarre, document) || bEstFils(oA, this.m_oHote, document))
		{
			bAfficheBarre = true;
		}
		// Si on est dans une ZR Ajax, on recoit parfois le fils racine de la cellule
		var oZRAjax = this.oGetZRAjax();
		if (oZRAjax && oZRAjax.m_tabSelection)
		{
			var oLigneCache = oZRAjax.m_oCache.oGetLigne(oZRAjax.m_tabSelection[0]);
			if (oLigneCache && (oA == oLigneCache.m_oLigneHTML.oGetLigneLogiqueHTML(oLigneCache.vnGetColonneHTML())))
			{
				bAfficheBarre = true;
			}
		}
	}

	// Si le champ n'avais pas le focus, le notifie qu'il le recoit
	if (bAfficheBarre)
	{
		this.OnFocus(oEvent);
	}
	else
	{
		// Supprime le focus si besoin
		this.OnBlur(oEvent);
	}

	// Masque les autres barres
	if (bAfficheBarre)
	{
		this.AppelMethodeAutresPtr(WDChamp.prototype.MasqueBarre, [oEvent]);
	}

	// Memorise la valeur uniquement en mode automatiqueoDataCommande
	if (this.m_eModeBarre != this.ms_nModeBarreAutomatique)
	{
		bAfficheBarre = undefined;
	}

	// Puis appele la methode de la classe de base
	WDBarre.prototype.RafBarre.apply(this, [oEvent, bAfficheBarre]);
};

// Masque la barre d'outil a la demande d'un autre champ
WDSaisieRiche.prototype._vMasqueBarre = function _vMasqueBarre(oEvent)
{
	// Supprime le focus si besoin
	this.OnBlur(oEvent);

	// Appel de la classe de base
	WDBarre.prototype._vMasqueBarre.apply(this, arguments);
};

// Si le champ n'avais pas le focus, le donne
WDSaisieRiche.prototype.OnFocus = function(oEvent)
{
	// Si le champ n'a pas encore le focus
	if (!this.m_bFocus)
	{
		// Memorise que l'on a le focus
		this.m_bFocus = true;
		// Execute le PCode
		this.RecuperePCode(this.ms_nEventNavFocus)(oEvent);
	}
};

// Si le champ avais pas le focus, le supprime
WDSaisieRiche.prototype.OnBlur = function(oEvent)
{
	// Si le champ a le focus
	if (this.m_bFocus)
	{
		// Si la valeur du champ a ete modifie : appel de onchange
		// (Comme sur un champ de saisie normal, avant le onfocus)
		var fOnChange = this.RecuperePCode(this.ms_nEventNavChange);
		if ((fOnChange != clWDUtil.m_pfVide) && this.bSauveContenu(oEvent))
		{
			fOnChange(oEvent);
		}

		// Execute le PCode
		this.RecuperePCode(this.ms_nEventNavBlur)(oEvent);
		// Memorise que l'on n'a plus le focus
		delete this.m_bFocus
	}
};

// Recupere les parametres pour RafEtat
WDSaisieRiche.prototype.oGetParamEtat = function(oEvent, bSimple)
{
	// Si on est lie a un ZR vide, on n'a pas de selection
	if (this.bGestionZR() && !this.m_oDocument)
	{
		return [null, null, null];
	}
	var oDataEtat = [this.oGetRange(), null, null];
	// Sous IE on peut avoir un "controlRange"
	var oElement = null;
	if (bIE && !(oDataEtat[0]["duplicate"]))
	{
		oElement = oDataEtat[0].item(0);
		oDataEtat[0] = null;
	}

	if (bSimple == false)
	{
		oDataEtat[1] = oElement ? oElement : this.oGetSelection(oDataEtat[0]);
		oDataEtat[2] = oDataEtat[1] ? _JGCS(oDataEtat[1]) : null;
	}
	return oDataEtat;
};

// Recupere la selection
WDSaisieRiche.prototype.oGetRange = function()
{
	// Recupere la selection
	if (bIE)
	{
		// Recupere la selection
		return this.m_oDocument.selection.createRange();
	}
	else
	{
		// Si le champ n'est pas visible (cellule masque qui sera affiche par CelluleAfficheDialogue) : defaultView est null
		if (this.m_oDocument.defaultView)
		{
			var oSelection = this.m_oDocument.defaultView.getSelection();
			if (oSelection && oSelection.rangeCount)
			{
				return oSelection.getRangeAt(0);
			}
		}
	}
	return null;
};

// Recupere une copie de la selection
WDSaisieRiche.prototype.oGetRangeCpy = function()
{
	var oRange = this.oGetRange();
	if (bIE)
	{
		return oRange.duplicate();
	}
	else
	{
		if (oRange)
		{
			oRange.cloneRange();
		}
	}
	return null;
};

// Compare deux range
WDSaisieRiche.prototype.bCompareRange = function(oRange1, oRange2)
{
	if (bIE)
	{
		return oRange1.isEqual(oRange2);
	}
	else
	{
		return (oRange1.compareBoundaryPoints(0, oRange2) == 0) && (oRange1.compareBoundaryPoints(2, oRange2) == 0);
	}
};

// Recupere le noeud qui contient le debut de la selection
WDSaisieRiche.prototype.oGetSelection = function(oRange)
{
	var oParentElement = null;
	// Recupere la selection
	if (bIE)
	{
		// On veut l'element le plus bas qui contient le debut
		// Donc on va reduire la selection au debut et demander le parent contenant
		// Duplication pour ne pas la modifier
		oRange = oRange.duplicate();
		oRange.collapse(true);
		var oParent = oRange.parentElement();
		// Si le focus est vraiment sortit du champ de saisie, on peut avoir un element qui n'est pas dans l'IFrame mais le body de la frame hote
		return (oParent.document == this.m_oDocument) ? oParent : this.m_oData;
	}
	else
	{
		if (oRange)
		{
			return oRange.startContainer;
		}
	}

	return null;
};

// Optimise le contenu au niveau du DOM
WDSaisieRiche.prototype.OptimiseContenu = function()
{
	// Puis supprime les SPAN utiliser pour avoir le bon focus dans IE
	this.__SupprimeSPAN_BR_IE();

	// Rien pour le moment
};

// Ecrase le contenu et marque les P originaux (IE)
WDSaisieRiche.prototype.__EcraseContenu = function __EcraseContenu(sValeur)
{
	// Ecrase le contenu
	this.m_oData.innerHTML = sValeur;
//	// Marque les P originaux (IE)
//	if (bIE)
//	{
//		var tabP = this.m_oData.getElementsByTagName("p");
//		var i = 0;
//		var nLimiteI = tabP.length;
//		for (i = 0; i < nLimiteI; i++)
//		{
//			tabP[i].m_bOriginal = true;
//		}
//	}
};

// Sauvegarde du contenu. Indique si le contenu a changer
WDSaisieRiche.prototype.bSauveContenu = function bSauveContenu(oEvent)
{
	var bChange = false;
	if (this.m_oValeur)
	{
		// Optimise le contenu du champ pour avoir un HTML compact
		this.OptimiseContenu();

		// Et recupere ce contenu HTML
		var sOldValue = this.m_oValeur.value;
		this.m_oValeur.value = this.m_oData.innerHTML;
		bChange = (sOldValue != this.m_oValeur.value);

		// Si on est dans une ZR AJAX, notifie la ZR de la modification de la valeur
		// Et si on ne change que la case du texte ?
		if (sOldValue.toUpperCase() != this.m_oValeur.value.toUpperCase())
		{
			var oZRAjax = this.oGetZRAjax();
			if (oZRAjax && oEvent)
			{
				oZRAjax.vOnValideLigneZRExterne(oEvent);
			}
		}
	}

	return bChange;
};

// Affectation externe du contenu du champ
WDSaisieRiche.prototype.SetValeur = function(oEvent, sValeur, oChamp)
{
	// Appel de la methode de la classe de base (ignore la valeur retourne par l'implementation de la classe de base)
	WDBarre.prototype.SetValeur.apply(this, arguments);

	// Ecrase le contenu
	this.__EcraseContenu(sValeur);
	// Sauve ensuite le contenu
	this.bSauveContenu();

	// Bug de FF : il faut supprimer le mode d'edition et le remettre
	this.__ReactiveModeEditable();

	// Et le relit pour avoir la version reelle du navigateur
	return this.m_oValeur.value;
};

// Lecture externe du contenu du champ
WDSaisieRiche.prototype.GetValeur = function GetValeur (oEvent, sValeur, oChamp)
{
	// sValeur est ignore car il contient une valeur obsolete
	// Sauve le contenu HTML dans le champ cache
	this.bSauveContenu();
	// Puis retourne cette valeur
	return this.m_oValeur.value;
};

// Ecrit les proprietes dont la couleur et la couleur de fond
WDSaisieRiche.prototype.SetProp = function SetProp(eProp, oEvent, oValeur, oChamp)
{
	// Implementation de la classe de base
	oValeur = WDChamp.prototype.SetProp.apply(this, arguments);

	switch (eProp)
	{
	case this.XML_CHAMP_PROP_NUM_COULEUR:
		// this.m_oDocument.body == this.m_oData non ?
		this.m_oDocument.body.style.color = oValeur;
		return oValeur;
	case this.XML_CHAMP_PROP_NUM_COULEURFOND:
		// this.m_oDocument.body == this.m_oData non ?
		this.m_oDocument.body.style.backgroundColor = oValeur;
		return oValeur;
	case this.XML_CHAMP_PROP_NUM_ETAT:
		// On a deja modifie la valeur par le champ cache
		// On force juste un reaffichage
		this.__InitSpecifique(false);
		return oValeur;
	default:
		return oValeur;
	}
};


// En cas de Submit : sauve le contenu
WDSaisieRiche.prototype.OnSubmit = function(oEvent)
{
	this.bSauveContenu(oEvent);
};

// Donne le focus au champ (pour reprisesaisie et la validation de champ obligatoire
WDSaisieRiche.prototype.SetFocus = function()
{
	// Pour les navigateur autre que IE il faut d'abord donner le focus a l'IFrame
	if (!bIE)
	{
		this.m_oIFrame.contentWindow.focus();
	}
	this.m_oData.focus();
};

// Gestion des commandes

// Execute une commande
WDSaisieRiche.prototype.ExecuteCommande = function(oEvent, oDataCommande)
{
	// Donne le focus au document
	this.SetFocus();

	// Execute la commande
	this.m_oDocument.execCommand(oDataCommande[0], oDataCommande[1], oDataCommande[2])

	// Donne le focus au document
	this.SetFocus();

	// Rafrachit les boutons
	this.RafBarre(oEvent, true);
};

// Insere un lien
WDSaisieRiche.prototype.OnLink = function(oEvent)
{
	this.__OnPrompt(oEvent, "CreateLink", "Link ?", "http://", false);
};

// Insere une image
WDSaisieRiche.prototype.OnImage = function(oEvent)
{
	// Si une image est selectionnee : on prend son URL
	var oRange = this.oGetRange();
	var sDefaut = "http://"
	// Sous IE on peut avoir un "controlRange"
	if (bIE && !(oRange["duplicate"]) && oRange.item(0) && oRange.item(0).src)
	{
		sDefaut = oRange.item(0).src;
	}

	this.__OnPrompt(oEvent, "InsertImage", "Image ?", sDefaut, true);
};

// Insertion generique
WDSaisieRiche.prototype.__OnPrompt = function(oEvent, sCommande, sTexte, sDefaut, bForcePrompt)
{
	// IE
	if (bIE && !bForcePrompt)
	{
		// Demande l'affichage de l'interface
		this.ExecuteCommande(oEvent, [sCommande, true, ""]);
	}
	else
	{
		var sVal = prompt(sTexte, sDefaut);
		if ((sVal != null) && (sVal != "") && (sVal != sDefaut))
		{
			this.ExecuteCommande(oEvent, [sCommande, false, sVal]);
		}
	}
};


// Recupere le texte alternatif d'un bouton
WDSaisieRiche.prototype.sGetAltText = function(sSuffixe)
{
	return HTML_TOOLBAR.ALTTEXT[sSuffixe];
};

// Place l'indication si besoin (Init ou apres un submit AJAX)
// Declare uniquement pour le cas ou le champ est en 'dynamique' auquel cas la generation HTML fait un appel
WDSaisieRiche.prototype.RAZIndication = clWDUtil.m_pfVide;
