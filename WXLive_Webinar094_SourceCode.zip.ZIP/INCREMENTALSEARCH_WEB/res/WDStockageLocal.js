//#16.00.03.00 WDStockageLocal.js
//VersionVI: 30A170078p
// Le seul support technique disponible pour cette librairie est
// accessible a travers le service "Assistance Directe".

function StockageLocalStorage(l)
{
	return (l||(l===undefined))?localStorage:sessionStorage;
}

function StockageLocalDisponible(l)
{
	return StockageLocalStorage(l)!=null;
}

function StockageLocalDispoValide(n,l)
{
	return StockageLocalDisponible(l)&&(n!="");
}

function StockageLocalAjoute(n,v,l)
{
	if(!StockageLocalDispoValide(n,l)) return false;
	StockageLocalStorage(l).setItem(n,(v==="")?"":v);
	return true;
}

function StockageLocalModifie(n,v,l)
{
	return StockageLocalAjoute(n,v,l);
}

function StockageLocalRecupere(n,l)
{
	if(!StockageLocalDispoValide(n,l)) return "";
	var r=StockageLocalStorage(l).getItem(n);
	return (r==null)?"":((r=="true")?true:((r=="false")?false:r));
}

function StockageLocalSupprime(n,l)
{
	if(!StockageLocalDispoValide(n,l)) return false;
	StockageLocalStorage(l).removeItem(n);
	return true;
}

function StockageLocalSupprimeTout(l)
{
	if(!StockageLocalDisponible(l)) return false;
	StockageLocalStorage(l).clear();
	return true;
}

function StockageLocalOccurrence(l)
{
	if(!StockageLocalDisponible(l)) return 0;
	return StockageLocalStorage(l).length;
}

function StockageLocalNomValeur(i,l)
{
	if((!StockageLocalDisponible(l))||((!(i<=0))&&(!(i>0)))||(i<=0)||(i>StockageLocalOccurrence(l))) return "";
	return StockageLocalStorage(l).key(i-1);
}
