//#17.0.1.0 WDVignette.js
//VersionVI: 30A170078p
// Le seul support technique disponible pour cette librairie est
// accessible a travers le service "Assistance Directe".

// Manipulation d'un champ vignette
function WDVignette(sAliasChamp, sAliasZR, sAliasAttribut, sAliasCellule, sAliasGrandeImage)
{
	// Si on est pas dans l'init d'un protoype
	if (sAliasChamp)
	{
		// Appel le constructeur de la classe de base
		WDImage.prototype.constructor.apply(this, arguments);

		if (sAliasCellule)
		{
			// Si on a un alias de cellule c'est que l'on est dans une cellule definie par l'utilisateur
			this.m_bCelluleUtilisateur = true;
			this.m_sAliasCellule = sAliasCellule;
			this.m_sAliasGrandeImage = sAliasGrandeImage;
		}
		else
		{
			// Si on n'a pas d'alias de cellule/d'image c'est que l'on est dans une cellule automatique
			this.m_bCelluleUtilisateur = false;
			this.m_sAliasCellule = sAliasChamp + this.ms_sSuffixeHote;
			this.m_sAliasGrandeImage = sAliasChamp + this.ms_sSuffixeGrandeImage;
		}
	}
};

// Declare l'heritage
WDVignette.prototype = new WDImage();
// Surcharge le constructeur qui a ete efface
WDVignette.prototype.constructor = WDVignette;

// Membres statiques
WDVignette.prototype.ms_sSuffixeGrandeImage = "_DIMG";

// Declare les fonction une par une

// Initialisation :
WDVignette.prototype.Init = function Init(sAliasCellule, sAliasImage)
{
	// Appel de la methode de la classe de base
	WDImage.prototype.Init.apply(this, arguments);

	if (!this.m_bCelluleUtilisateur)
	{
		var oThis = this;
		this.m_fChargementTermine = function(oEvent) { oThis.__ChargementTermine(oEvent || event); }
	}
};

// Trouve les divers elements : liaison avec le HTML
WDVignette.prototype._vLiaisonHTML = function _vLiaisonHTML(sSuffixeHote)
{
	// Appel de la methode de la classe de base
	WDImage.prototype._vLiaisonHTML.apply(this, arguments);

	// Trouve la grande image et sa cellule
	this.m_oCellule = document.getElementById(this.m_sAliasCellule);
	this.m_oGrandeImage = document.getElementById(this.m_sAliasGrandeImage);
};

// - Tous les champs : Notifie le champ que la fenetre est redimentionnee
WDVignette.prototype.OnResize = function OnResize(oEvent)
{
	// Appel de la methode de la classe de base
	WDImage.prototype.OnResize.apply(this, arguments);

	if (this._bGrandeImageAffichee())
	{
		// Redimensionne le champ
		// @@@
	}
};

// Calcule de defilement effectif
// Virtuel car surcharge par le champ vignette qui tient compte de l'ouverture
WDVignette.prototype._vGetDefilementEffectif = function _vGetDefilementEffectif()
{
	return (WDImage.prototype._vGetDefilementEffectif.apply(this, arguments) && !this._bGrandeImageAffichee());
};

// Indique si la grande image est affichee
WDVignette.prototype._bGrandeImageAffichee = function _bGrandeImageAffichee()
{
	// On peut ne pas avoir de grande image en cas de vignette avec defilement mais qui ouvre dans une nouvelle fenetre
	if (!this.m_oGrandeImage)
	{
		return false;
	}
	// => Si l'image est affichee
	var oGrandeImageCurrentStyle = _JGCS(this.m_oGrandeImage);
	return (oGrandeImageCurrentStyle.display != "none") && (oGrandeImageCurrentStyle.visibility != "hidden");
};

// Si on est en mode automatique, remplace l'image (pour permettre de tester la taille de l'image source)
// On ne peut pas tester sur une image invisible, car si c'est une image generee est elle sans cache et on ne veut pas faire deux appels au serveur
WDVignette.prototype.__PrepareGrandeImage = function __PrepareGrandeImage()
{
	// Uniquement si on est en mode automatique
	if (!this.m_bCelluleUtilisateur)
	{
		var oOldGrandeImage = this.m_oGrandeImage;
		UnhookOnXXX(oOldGrandeImage, "onreadystatechange", "load", this.m_fChargementTermine);
		// Creer un nouvelle image
		this.m_oGrandeImage = document.createElement("img");
		// L'ajoute a cote de l'ancienne grande image
		oOldGrandeImage = oOldGrandeImage.parentNode.replaceChild(this.m_oGrandeImage, oOldGrandeImage);

//		// Creer la nouvelle image en invisible
//		this.m_oGrandeImage.visibility = "hidden";
	}
};

// Affiche l'image
WDVignette.prototype.__AfficheGrandeImage = function __AfficheGrandeImage(sImage)
{
	// Et si on est en mode automatique : attend le chargement de l'image (avant le chargement ca si l'image est en cache c'est direct)
	if (!this.m_bCelluleUtilisateur)
	{
		HookOnXXX(this.m_oGrandeImage, "onreadystatechange", "load", this.m_fChargementTermine);

		// Masque la cellule le temps de l'affichage
		this.m_oCellule.style.visibility = "hidden";
	}

	// Afiche l'image
	this.m_oGrandeImage.src = sImage;
};

// Fin du chargement de la grande image en mode automatique
WDVignette.prototype.__ChargementTermine = function __ChargementTermine(oEvent)
{
	if (!bIE || ("complete" == this.m_oGrandeImage.readyState))
	{
		var oConteneur = this.m_oCellule.parentNode;
		var nLargeurDisponible = Math.min(document.body.scrollWidth, document.body.clientWidth) - 60;
		var nHauteurDisponible = Math.min(document.body.scrollHeight, document.body.clientHeight) - 60;
		// 1 : Pour eviter les divisions par zero
		var nLargeurImage = Math.max(this.m_oGrandeImage.offsetWidth, 1);
		var nHauteurImage = Math.max(this.m_oGrandeImage.offsetHeight, 1);

		var nLargeurReduction = Math.max(nLargeurImage - nLargeurDisponible, 0);
		var nHauteurReduction = Math.max(nHauteurImage - nHauteurDisponible, 0);
		var dLargeurReduction = nLargeurReduction / nLargeurImage;
		var dHauteurReduction = nHauteurReduction / nHauteurImage;
		// Si on doit reduire la taille
		var bReduction = false;
		if (dLargeurReduction > dHauteurReduction)
		{
			bReduction = true;
			nLargeurImage = nLargeurDisponible;
			nHauteurImage = nHauteurImage * (1 - dLargeurReduction);
		}
		else if (dLargeurReduction < dHauteurReduction)
		{
			bReduction = true;
			nHauteurImage = nHauteurDisponible;
			nLargeurImage = nLargeurImage * (1 - dHauteurReduction);
		}

		if (bReduction)
		{
			// Affiche l'image
			this.m_oGrandeImage.style.width = nLargeurImage + "px";
			this.m_oGrandeImage.style.height = nHauteurImage + "px";
		}

		this.nSetTimeout(this.__ChargementTermineRecentre, 1);
	}
};

// Recentre la cellule
WDVignette.prototype.__ChargementTermineRecentre = function __ChargementTermineRecentre()
{
	// Recentre la cellule en masquant et reaffichant le GFI
	_JDE(this.m_oCellule, document, 5);

	// Affiche la cellule (si on l'a masque
	clWDUtil.SetDisplay(this.m_oCellule, true);
	// Affiche la cellule
	this.m_oCellule.style.visibility = "inherit";
};

// Prepare la grande image pour ne plus prendre de place (evite les problemes de reflow)
WDVignette.prototype.__FermeGrandeImage = function __FermeGrandeImage()
{
	if (!this.m_bCelluleUtilisateur)
	{
		// Reduit l'image pour ne pas prendre de place
		this.m_oGrandeImage.style.src = "";
		this.m_oGrandeImage.style.width = "1px";
		this.m_oGrandeImage.style.height = "1px";

		// Et masque la cellule
		clWDUtil.SetDisplay(this.m_oCellule, false);
	}
};

//////////////////////////////////////////////////////////////////////////
// Interface pour le WL

// Affiche la grande image
WDVignette.prototype.ImageAffiche = function ImageAffiche(sImage)
{
	// Si on est en mode automatique, remplace l'image (pour permettre de tester la taille de l'image source)
	// On ne peut pas tester sur une image invisible, car si c'est une image generee est elle sans cache et on ne veut pas faire deux appels au serveur
	this.__PrepareGrandeImage();

	// Affiche la cellule
	// 5 = centre
	_JCAD(this.m_sAliasCellule, document, 5, _GFI_A_, _GFI_T_);

	// Affiche l'image
	this.__AfficheGrandeImage(sImage);
};

// Masque la grande image
WDVignette.prototype.ImageFerme = function ImageFerme()
{
	// Appel de CelluleFermeDialogue
	_JCFD(this.m_sAliasCellule, document);

	this.__FermeGrandeImage();
};
