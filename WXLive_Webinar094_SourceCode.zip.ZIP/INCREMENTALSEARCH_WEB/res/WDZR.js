//#17.0.1.0 WDZR.js
//VersionVI: 30A170078p
// Le seul support technique disponible pour cette librairie est
// accessible a travers le service "Assistance Directe".

// Attention a ne pas mettre d'accent dans ce fichier COMMENTAIRES inclus

// Ligne dans une ZR
function WDZRCacheLigne (oXMLLigne, oObjetZR, nLigne)
{
	if (oXMLLigne)
	{
		// Appel le constructeur de la classe de base
		WDTableCacheLigne.prototype.constructor.apply(this, arguments);

		// Recupere la ligne et la colonne effective
		this.m_nLignePosVisibleEff = clWDAJAXMain.nXMLGetAttributSafe(oXMLLigne, this.XML_LIGNE_EFFECTIVE, parseInt(nLigne / oObjetZR.vnGetNbLignesLogiquesParLignePhysique()));
		this.m_nColonneEff = clWDAJAXMain.nXMLGetAttributSafe(oXMLLigne, this.XML_COLONNE_EFFECTIVE, nLigne % oObjetZR.vnGetNbLignesLogiquesParLignePhysique());
	}
};

// Declare l'heritage
WDZRCacheLigne.prototype = new WDTableCacheLigne();
// Surcharge le constructeur qui a ete efface
WDZRCacheLigne.prototype.constructor = WDZRCacheLigne;

WDZRCacheLigne.prototype.XML_LIGNE_EFFECTIVE = "LIGNEEFF";
WDZRCacheLigne.prototype.XML_COLONNE_EFFECTIVE = "COLONNEEFF";

// Place le contenu du XML dans une cellule
WDZRCacheLigne.prototype._vPlaceXMLDansCellule = function _vPlaceXMLDansCellule(oXMLCellule, oCellule, nColonne, oChampTable)
{
	var oXMLCelluleChildNodes = oXMLCellule.childNodes;

	// Si on est dans le cas d'une ZR on lit la balise millieu
	if ((oXMLCelluleChildNodes.length == 3) && (oXMLCelluleChildNodes[1].nodeName == WDAJAXMain.prototype.XML_CHAMP_LIGNES_LIGNE_CORPS))
	{
		oCellule.m_sValeur = clWDAJAXMain.sXMLGetValeur(oXMLCelluleChildNodes[1]);
	}
	// Sinon contenu vide (par exemple si la ligne est repliee)
	this.m_nNbRepliee = clWDAJAXMain.nXMLGetAttributSafe(oXMLCellule.parentNode, WDAJAXMain.prototype.XML_CHAMP_LIGNES_NBREPLIEES, 0);
};

// Recupere la ligne dans le HTML
WDZRCacheLigne.prototype.vnGetLigneHTML = function vnGetLigneHTML(nLigneAbsolue)
{
	// Se place par rapport a la premiere ligne affichee
	return this.m_nLignePosVisibleEff;
};

// Recupere la colonne dans le HTML
WDZRCacheLigne.prototype.vnGetColonneHTML = function vnGetColonneHTML()
{
	return this.m_nColonneEff;
};

// Si la ligne est repliee (ligne est invisible mais ses ruptures oui)
WDZRCacheLigne.prototype.vnGetNbRepliees = function vnGetNbRepliees()
{
	// Se place par rapport a la premiere ligne affichee
	return this.m_nNbRepliee;
};

// Classe representant le cache
function WDZRCache (oChampZR)
{
	if (oChampZR)
	{
		// Appel le constructeur de la classe de base
		WDTableCache.prototype.constructor.apply(this, arguments);
	}
};

// Declare l'heritage
WDZRCache.prototype = new WDTableCache();
// Surcharge le constructeur qui a ete efface
WDZRCache.prototype.constructor = WDZRCache;

// Classe de ligne de cache
WDZRCache.prototype.vCacheLigne = WDZRCacheLigne;

// Classe manipulant une ZR
function WDZR(sAliasChamp, bSansLimite, nHauteurLigne, nPagesMargeMin, nPagesMargeMax, tabStyle, nNbLignesLogiquesParLignePhysique)
{
	// Si on est pas dans l'init d'un protoype
	if (sAliasChamp)
	{
		// Appel le constructeur de la classe de base
		WDTable.prototype.constructor.apply(this, [sAliasChamp, bSansLimite, nHauteurLigne, nPagesMargeMin, nPagesMargeMax, WDTable.prototype.SELECTION_SIMPLE, tabStyle]);

		// Initialise le tableau des champs fils
		this.m_tabChampsFils = new WDTableauChamps();

		// Se declare dans la table globale des Tables/ZRs AJAX
		WDChamp.prototype.ms_tabTablesZRs.DeclareChamp(this);

		this.m_nNbLignesLogiquesParLignePhysique = nNbLignesLogiquesParLignePhysique;

		// Ne rien mettre ici qui doit etre remit a zero dans l'init
	}
};

// Declare l'heritage
WDZR.prototype = new WDTable();
// Surcharge le constructeur qui a ete efface
WDZR.prototype.constructor = WDZR;

// Classe de cache
WDZR.prototype.vCache = WDZRCache;

// Initialisation
WDZR.prototype.Init = function(nColonneTrie)
{
	// Appel de la methode de la classe de base
	WDTable.prototype.Init.apply(this, arguments);
};

// Declare un champ a la ZR
WDZR.prototype.DeclareChampFils = function(oFils)
{
	// Est normalement dans une ZR
	this.m_tabChampsFils.DeclareChamp(oFils);
};

// Gestion sepcifique de l'evenement roulette SI il y a deplacement
WDZR.prototype._vForceDefilement = function(oEvent)
{
	// Si on est en saisie dans une zone repetee valide la modification de la ligne par une selection d'une autre partie du DOM
	// Dans certaines tables, ce code declenche une execution de DeplaceTable mais avec un deplacement vide.
	var oTableInterne = this.oGetIDElement(this.ID_TABLEINTERNE);

	// Il ne faut pas donner le focus a l'ascenseur car cela provoque un defilement irregulier (ou pas de defilment du tout) dans IE
	var sTabIndex;
	try
	{
		if (!bIEQuirks)
		{
			// Pour recevoir le focus un element doit avoir un TABINDEX
			sTabIndex = oTableInterne.tabIndex;
			oTableInterne.tabIndex = "1000";
		}

		oTableInterne.focus();
	}
	catch (e)
	{
		throw e;
	}
	finally
	{
		if (!bIEQuirks)
		{
			oTableInterne.tabIndex = sTabIndex;
		}
	}

	// Appel de la methode de la classe de base
	WDTable.prototype._vForceDefilement.apply(this, arguments);
};

// Indique que le champ est une ZR
WDZR.prototype.vbZR = function vbZR()
{
	return true;
};

// Rafraichi la table
WDZR.prototype._vRefresh = function _vRefresh(nReset, nNouveauDebut, sCleNouveauDebut)
{
	// Si reaffichage de la table
	switch (nReset)
	{
	case 1:
	case 2:
		// Annule la validation d'une ligne de ZR si la ZR est MAJ
		this.AnnuleTimeXXX("_OnValideLigneZR");
		if (undefined !== this.m_oValideLigneZR)
		{
			this.m_oValideLigneZR = null;
			delete this.m_oValideLigneZR;
		}
		break;
	}

	// Appel de la methode de la classe de base
	WDTable.prototype._vRefresh.apply(this, arguments);
};

// Pas de bordure dans les ZRs
WDZR.prototype._vnGetOffset = function _vnGetOffset(oLignePhysique)
{
	return 0;
};

// Recepere le style CSS a utiliser pour la hauteur des lignes :
// - table : "height"
// - ZR : "height" pour le mode quirks, "min-height" pour le reste
WDZR.prototype._vsGetCSSLigneHeight = function _vsGetCSSLigneHeight()
{
	return bIEQuirks ? "height" : "min-height";
};

// Indique si une ligne est selectionnee + retourne faux dans le cas des ZRs
WDZR.prototype.vbLigneEstSelectionneeSansZR = function vbLigneEstSelectionneeSansZR(nLigneAbsolue)
{
	return false;
};

// Vide une cellule de ZR
WDZR.prototype.vVideCellule = function vVideCellule(oEtatLigne, nColonne)
{
	this.__VideCellule(oEtatLigne.oGetCelluleHTML(this, nColonne));
};
WDZR.prototype.__VideCellule = function __VideCellule(oCellule)
{
	// Pas d'appel de la methode de la classe de base

	// La suppression des ruptures est fait par l'appel parent

	// Supprime les elements JavaScript pour les reference circulaires entre le DOM et le JS
	// Vide la cellule
	clWDUtil.SupprimeFilsEtOnFocus(oCellule, true);
};

// Remplit une cellule de la ZR
WDZR.prototype.vRemplitCellule = function vRemplitCellule(oCellule, sValeur, nLigneAbsolue, nColonne, nNbRepliees, bSelection)
{
	// Pas d'appel de la methode de la classe de base

	// L'ajout des ruptures est fait par l'appel parent

	// Vide la cellule
	this.__VideCellule(oCellule);

	// Affiche ou masque la cellule selon son repliement
	// On modifie la racine de la ligne pour ne pas avoir de blanc
	var oCelluleParent = oCellule.parentNode;
	if (1 == this.vnGetNbLignesLogiquesParLignePhysique())
	{
		oCelluleParent = oCelluleParent.parentNode;
	}
	clWDUtil.SetDisplay(oCelluleParent, 0 == nNbRepliees);

	if (0 == nNbRepliees)
	{
		// Et place le contenu dans la cellule
		oCellule.innerHTML = clWDEncode.sEncodeInnerHTML(sValeur, false, true);

		var sCelluleId = oCellule.id;

		// Puis on hook le onblur de tous les champs de la selection
		var tabElements = clWDUtil.tabGetElements(oCellule, true);
		var i;
		var nLimiteI = tabElements.length;
		for (i = 0; i < nLimiteI; i++)
		{
			var oElement = tabElements[i];
			var bOnBlurSeul = (oElement.onchange === undefined);
			clWDUtil.SetOnXxx(oElement, "onblur", this, this.OnValideLigneZR, [sCelluleId, nLigneAbsolue, bOnBlurSeul]);
			if (false == bOnBlurSeul)
			{
				clWDUtil.SetOnXxx(oElement, "onchange", this, this.OnValideLigneZR, [sCelluleId, nLigneAbsolue, true]);
			}

			// On doit passer par une fonction pour les valeurs des variables sinon on a la valeurs de i lors de sa destruction
			clWDUtil.SetOnXxx(oElement, "onfocus", this, this.OnFocusLigneZR, [sCelluleId, nLigneAbsolue, i]);
		}
	}
};

// Corrige m_bDebordeLargeur selon le type du champ (pour les ZRs)
// Si la ZR est vide => on trouve scrollWidth a 0 donc on a m_bDebordeLargeur a vrai
WDZR.prototype._vMAJDebordeLargeur = function _vMAJDebordeLargeur()
{
	// Pas d'appel de la classe de base

	this.m_bDebordeLargeur = false;
};

// Met a jour les pictos de tri de la table (maintenant que l'on a recu la liste des colonnes)
// Rien dans les ZR
WDZR.prototype.vAffichePictoTriColonnes = function()
{
	// Pas d'appel de la classe de base
};

// Recupere le nombre de colonne de presentation
WDZR.prototype.vnGetNbLignesLogiquesParLignePhysique = function()
{
	return this.m_nNbLignesLogiquesParLignePhysique;
};

// Class utilitaire pour la validation des lignes
function WDZRValideLigne (sCelluleId, nLigneAbsolue)
{
	this.m_nLigneAbsolue = nLigneAbsolue;
	this.m_sCelluleId = sCelluleId;
	// Recupere le formulaire a la main
	this.m_sContenu = clWDAJAXMain.sConstruitValeurPage(clWDUtil.tabGetElements(document.getElementById(sCelluleId), false));
}

// Valide la ligne selectionnee et envoie la modification au serveur
WDZR.prototype.vOnValideLigneZRExterne = function(oEvent)
{
	// La selection contient les numero de ligne en valeur absolue et pas en valeur affichee
	// Recupere l'ID de la cellule depuis son numero de le ligne (pas d'information de colonne car on est pas dans une table)
	this.__OnValideLigneZR(new WDZRValideLigne(this.sGetIDCellule(this.nAbsolue2Relative(this.m_tabSelection[0])), this.m_tabSelection[0]));
};

// Valide une ligne de table et envoie la modification au serveur
WDZR.prototype.OnValideLigneZR = function(oEvent, tabParametres)
{
	var sCelluleId = tabParametres[0];
	var nLigneAbsolue = tabParametres[1];
	var bChangement = tabParametres[2];

	// Si on est dans un lien n'active uniquement si on a recu le focus APRES une modification
	if (this.bEstLienOuImageDansLien(oEvent))
	{
		if (!this.m_bValideLigneZRCelluleDansLien)
		{
			return;
		}
		else
		{
			// Pour ne plus influencer le prochain passage
			delete this.m_bValideLigneZRCelluleDansLien;
		}
	}

	// m_bValideLigneZRChangement est inutile : il revient au meme que tester this.bGetTimeXXXExiste("_OnValideLigneZR")

	// Si pas de changement : fini
	if (!bChangement)
	{
		return;
	}

	// Pour les gestion du champ qui prend le focus on se fait un setTimeout (1ms)
	// Comme ca le onfocus a le temps de traiter le cas et de nous bloquer
	// Seulement si on n'a pas deja un timeout
	if (!this.bGetTimeXXXExiste("_OnValideLigneZR"))
	{
		this.m_oValideLigneZR = new WDZRValideLigne(sCelluleId, nLigneAbsolue);
		this.nSetTimeoutUnique("_OnValideLigneZR", clWDUtil.nTimeoutImmediat);
	}
};

// Valide une ligne de table et envoie la modification au serveur
WDZR.prototype._OnValideLigneZR = function()
{
	// Recuperation et suppression des proprietes
	var oValideLigneZR = this.m_oValideLigneZR;
	this.m_oValideLigneZR = null;
	delete this.m_oValideLigneZR;

	// Et envoi la requete
	this.__OnValideLigneZR(oValideLigneZR);
};

// Valide une ligne de table et envoie la modification au serveur
WDZR.prototype.__OnValideLigneZR = function __OnValideLigneZR(oValideLigneZR)
{
	// Et envoi la requete
	// Uniquement si on a des valeurs sinon le serveur fait une erreur de manque de valeurs
	var sContenu = oValideLigneZR.m_sContenu;
	if (sContenu && (sContenu.length > 0))
	{
		this.m_oCache.CreeRequeteModifLigne(this, oValideLigneZR.m_nLigneAbsolue, true, sContenu);
	}
};

// Pour la validation des lignes de ZR : recupere le contenu de la ligne
WDZR.prototype.__sGetContenuLigne = function __sGetContenuLigne(sCelluleId)
{
	// Recupere le formulaire a la main
	var tabContenu = clWDUtil.tabGetElements(document.getElementById(sCelluleId), false);
	return clWDAJAXMain.sConstruitValeurPage(tabContenu);
};

// Indique si le champ source d'un evenement est un lien ou une image dans un lien
WDZR.prototype.bEstLienOuImageDansLien = function(oEvent)
{
	// Si on est dans un lien n'active uniquement si on a recu le focus APRES une modification
	if (!oEvent)
	{
		return false;
	}
	var oChamp = bIE ? oEvent.srcElement : oEvent.target;
	switch (clWDUtil.sGetTagName(oChamp))
	{
	// Selon le cas (on peut avoir une image dans le lien et alors la source est l'image et pas le lien)
	case "img":
		return clWDUtil.bBaliseEstTag(oChamp.parentNode, "a");
	case "a":
		return true;
	default:
		return false;
	}
};

// Indique qu'une ligne donnee de la ZR a recu le focus
WDZR.prototype.OnFocusLigneZR = function(oEvent, tabParametres)
{
	var sCelluleId = tabParametres[0];
	var nLigneAbsolue = tabParametres[1];
	var nNumElement = tabParametres[2];

	// Si on a un traitement de focus qui correspond : on le bloque
	if (this.bGetTimeXXXExiste("_OnValideLigneZR") && (this.m_oValideLigneZR.m_sCelluleId == sCelluleId) && (this.m_oValideLigneZR.m_nLigneAbsolue == nLigneAbsolue))
	{
		// Si on est dans un lien n'active uniquement si on a recu le focus APRES une modification
		if (this.bEstLienOuImageDansLien(oEvent))
		{
			this.m_bValideLigneZRCelluleDansLien = true;
		}
		this.AnnuleTimeXXX("_OnValideLigneZR");
		this.m_oValideLigneZR = null;
		delete this.m_oValideLigneZR;
	}

	if (!this.m_bSansLimite)
	{
		var nDefilement = 0;
		// Si la ligne est au debut et a moitie visible ou a la fin : force le defilement
		if ((nLigneAbsolue == this.m_nDebut) && (parseInt(this.m_oDivPos.style.top, 10) < 0))
		{
			nDefilement = parseInt(this.m_oDivPos.style.top, 10);
		}
		else if (nLigneAbsolue >= (this.m_nDebut + this.m_nNbLignesPage))
		{
			nDefilement = parseInt(this.m_oAscenseur.style.height, 10) / this.m_nNbLignes;
		}

		// Si on a un defilement
		if (nDefilement != 0)
		{
			// Et note de redonner le focus avec deplacement
			this.nSetTimeout(this.DonneFocusZR, 20, nDefilement, sCelluleId, nLigneAbsolue);
		}
	}
};

// Redonne le focus a un champ de la ZR sur une ligne donnee
WDZR.prototype.DonneFocusZR = function(nDefilement, sCelluleId, nLigneAbsolue)
{
	this.__nForceDefilement(nDefilement, null, null);
	var tabContenu = clWDUtil.tabGetElements(document.getElementById(sCelluleId), false);
	// Donne le focus au champ
	var oLigneCache = this.m_oCache.oGetLigne(nLigneAbsolue);
	var nNumElement = (oLigneCache.vnGetLigneHTML(nLigneAbsolue) - this.nGetLigneHTMLDebut()) * this.vnGetNbLignesLogiquesParLignePhysique() + oLigneCache.vnGetColonneHTML();
	if (tabContenu && tabContenu[nNumElement])
	{
		try
		{
			tabContenu[nNumElement].focus();
		}
		catch (e)
		{
		}
	}
};

// Click sur une ligne de zone repetee
WDZR.prototype.OnSelectLigne = function(nLigneRelative, nColonne, oEvent)
{
	// Pas d'appel de la casse de base

	// Si on a une requete en cours : la modification de la selection va etre ecrase donc on l'interdit
	if (this.m_oCache.m_tabRequetes.length > 0)
	{
		return;
	}

	var nLigneAbsolue = nLigneRelative + this.m_nDebut;

	// Regarde si la ligne est selectionne et ne fait rien si c'est deja le cas
	if (this.bLigneEstSelectionnee(nLigneAbsolue))
	{
		return;
	}

	// Supprime les autres selections (Normalement une seule ligne)
	this.bLigneDeselectionneTous(-1, oEvent);

	// Selectionne la ligne
	this.__bLigneSelectionne(nLigneAbsolue, true, oEvent);

//	// Envoie une requete au serveur demandant le refraichissement de la ligne donnee
//	this.RequeteSelection(-1);
};

// Notifie les champs qu'une ligne va etre masque
WDZR.prototype._vMasqueLigneInterne = function(nLigneAbsolue, bLigneSelectionnee, oEvent)
{
	// Appel de la classe de base
	WDTable.prototype._vMasqueLigneInterne.apply(this, arguments);

	this.m_tabChampsFils._AppelMethodePtr(WDChamp.prototype.OnLigneZRMasque, [nLigneAbsolue + 1, bLigneSelectionnee, oEvent]);
};

// Action avant la MAJ d'une ligne
WDZR.prototype.vPreMAJLigne = function vPreMAJLigne(nLigneAbsolue, oEvent)
{
	// Indique que la ligne est masque aux champs fils
	// Note : plusieurs endroits invalident m_bPlein sans faire ces appels
	// Ils ne concernent normalement que les tables
	this._vMasqueLigneInterne(nLigneAbsolue, this.bLigneEstSelectionnee(nLigneAbsolue), oEvent)
};

// Action apres la MAJ d'une ligne
WDZR.prototype.vPostMAJLigne = function vPostMAJLigne(nLigneAbsolue, oEvent)
{
	// Indique que la ligne est affichee aux champs fils
	this.m_tabChampsFils._AppelMethodePtr(WDChamp.prototype.OnLigneZRAffiche, [nLigneAbsolue + 1, this.bLigneEstSelectionnee(nLigneAbsolue)]);
};
