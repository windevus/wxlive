//#17.0.1.0 WDZRNavigateur.js
//VersionVI: 30A170078p
// Le seul support technique disponible pour cette librairie est
// accessible a travers le service "Assistance Directe".

// Manipulation des champs zone repetee navigateur

// Une ligne de la zone repetee navigateur
function WDZRLigne (nNbColonnes)
{
	if (nNbColonnes !== undefined)
	{
		// Tableaux des valeurs
		this.m_tabValeurs = new Array(nNbColonnes);
		// Etat d'enroulement de la ligne : complement deroule
		// Pour le cache de l'etat, on ne garde par un flag par rupture effective mais on a le flag en general et il n'est lut que si on a une rupture
		// Plus on stocke l'etat dans un entier et on lit les bits (ce qui limite en pratique a 32 ruptures)
		// Cela evite des couteux tableaux d'etats
		this.m_nDeroule = this.ms_nTous;
		// Pareil pour les ruptures
		// L'etat sera MAJ lors de l'ajout dans la table
		this.m_nRupturesHaut = this.ms_nRien;
		this.m_nRupturesBas = this.ms_nRien;
		// Indique que la ligne a ete modifie (pour le PCode d'affichage : oui a la creation)
		this.m_bPCodeAffichage = false;
		this.m_bModifieRuptures = true;
	}
};

WDZRLigne.prototype.ms_nRien = 0;
WDZRLigne.prototype.ms_nTous = (0xFFFFFFFF | 0); // Pour avoir -1 en entier

// Lecture des valeurs
WDZRLigne.prototype.tabGetValeurs = function tabGetValeurs ()
{
	return this.m_tabValeurs;
};

// Indique que la ligne est modifie
WDZRLigne.prototype.SetModifieRuptures = function SetModifieRuptures(bRuptures)
{
	this.m_bModifieRuptures = this.m_bModifieRuptures || bRuptures;
};
WDZRLigne.prototype.bGetClearPCodeAffichage = function bGetClearPCodeAffichage()
{
	var bPCodeAffichage = this.m_bPCodeAffichage;
	this.m_bPCodeAffichage = true;
	return !bPCodeAffichage;
};
WDZRLigne.prototype.bGetClearModifieRuptures = function bGetClearModifieRuptures()
{
	var bModifieRuptures = this.m_bModifieRuptures;
	this.m_bModifieRuptures = false;
	return bModifieRuptures;
};

// Indique si on a une rupture
WDZRLigne.prototype.nGetRuptures = function nGetRuptures(bHaut)
{
	return bHaut ? this.m_nRupturesHaut : this.m_nRupturesBas;
};
WDZRLigne.prototype.bGetRupture = function bGetRupture(nRupture, bHaut)
{
	// Il faut aussi tester les ruptures precedentes
	return this.bGetRuptureDirect(nRupture, bHaut) || ((0 < nRupture) && this.bGetRupture(nRupture - 1, bHaut));
};
WDZRLigne.prototype.bGetRuptureDirect = function bGetRuptureDirect(nRupture, bHaut)
{
	return (0 != (this.nGetRuptures(bHaut) & (1 << nRupture)));
};

// Indique si la rupture est visible
WDZRLigne.prototype.bGetRuptureVisible = function bGetRuptureVisible(nRupture, bHaut)
{
	// Si la ligne est enroule
	if (!this.bGetDeroule())
	{
		if (bHaut)
		{
			// Haut : Il ne faut pas que la ligne soit enroule sur une rupture precedente
			for (var nRupturePrecedente = nRupture - 1; 0 <= nRupturePrecedente; nRupturePrecedente--)
			{
				if (0 == (this.m_nDeroule & (1 << nRupturePrecedente)))
				{
					return false;
				}
			}
		}
		else
		{
			// Bas : il ne faut pas que la ligne soit enroule
			return false;
		}
	}

	return this.bGetRupture(nRupture, bHaut);
};

WDZRLigne.prototype.bGetDeroule = function bGetDeroule()
{
	return (this.ms_nTous == this.m_nDeroule);
};

WDZRLigne.prototype.CopieEnrouleDeroule = function CopieEnrouleDeroule(oLigne, nRupture)
{
	var nBit = 1 << nRupture;
	if (0 == (oLigne.m_nDeroule & nBit))
	{
		// Enroule
		this.m_nDeroule &= ~nBit;
	}
	else
	{
		// Deroule
		this.m_nDeroule |= nBit;
	}
};

// Notifie de la suppression de la ligne
WDZRLigne.prototype.OnSupprime = function OnSupprime ()
{
	// Libere explictement la memoire
	this.m_tabValeurs.length = 0;
};

// Enroule/deroule une rupture de la ligne
WDZRLigne.prototype.EnrouleDeroule = function EnrouleDeroule (nRupture, bDeroule, bRecursif)
{
	var nBit = 1 << nRupture;
	// Calcule l'inversion si besoin
	if (bDeroule === undefined)
	{
		bDeroule = (0 == (this.m_nDeroule & nBit));
	}
	if (bDeroule)
	{
		this.m_nDeroule |= nBit;
		// Plus deroule si demande les ruptures precedentes
		if (bRecursif && (0 < nRupture))
		{
			this.EnrouleDeroule(nRupture - 1, bDeroule, bRecursif);
		}
	}
	else
	{
		this.m_nDeroule &= ~nBit;
	}
};

// Fixe les ruptures
WDZRLigne.prototype.SetRupturesHaut = function SetRupturesHaut(nRuptures)
{
	// Prepare au deroule les ruptures modifiees
	var nDeroule = this.m_nRupturesHaut ^ nRuptures;

	this.m_nRupturesHaut = nRuptures;
	// Deroule les ruptures modifiees
	this.m_nDeroule |= nDeroule;
};
WDZRLigne.prototype.SetRupturesBas = function SetRupturesBas(nRuptures)
{
	this.m_nRupturesBas = nRuptures;
};

// Une rupture de la zone repetee navigateur
function WDZRRupture(sAlias, nColonne, tabPCodesHaut, tabPCodesBas, bVisibleHaut, bVisibleBas)
{
	if (sAlias)
	{
		this.m_sAlias = sAlias;
		this.m_nColonne = nColonne;
		this.m_oPCodesHaut = new WDPCodes(tabPCodesHaut);
		this.m_oPCodesBas = new WDPCodes(tabPCodesBas);
		this.m_bVisibleHaut = bVisibleHaut;
		this.m_bVisibleBas = bVisibleBas;
	}
};

// Recupere un PCode navigateur de la rupture
WDZRRupture.prototype.RecuperePCode = function RecuperePCode(ePCodeNav, bHaut)
{
	return (bHaut ? this.m_oPCodesHaut : this.m_oPCodesBas).RecuperePCode(ePCodeNav);
};

// Indique si la rupture est visible
WDZRRupture.prototype.bVisible = function bVisible(bHaut)
{
	return bHaut ? this.m_bVisibleHaut : this.m_bVisibleBas;
};

// Une colonne/un attribut de la zone repetee navigateur
function WDZRColonne(sAlias, eProprieteAssocie)
{
	if (sAlias)
	{
		this.m_sAlias = sAlias;
		this.m_eProprieteAssocie = eProprieteAssocie;
	}
};

WDZRColonne.prototype.oGetValeurInterne = function oGetValeurInterne(oValeur)
{
	if (oValeur !== undefined)
	{
		var oTemp;
		switch (this.m_eProprieteAssocie)
		{
		case WDChamp.prototype.XML_CHAMP_PROP_NUM_VISIBLE:
		case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICEGRAS:
		case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICEITALIQUE:
		case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICESOULIGNE:
			// On gere aussi le flase en chaine (pour la concatenation en chaine de la constante false par le JS)
			return (false != oValeur) && ("false" != oValeur);
		case WDChamp.prototype.XML_CHAMP_PROP_NUM_ETAT:
			oTemp = parseInt(oValeur + "", 10);
			if ((oTemp != WDChamp.prototype.ms_eEtatActif) && (oTemp != WDChamp.prototype.ms_eEtatLectureSeule) && (oTemp != WDChamp.prototype.ms_eEtatGrise))
			{
				oTemp = WDChamp.prototype.ms_eEtatActif;
			}
			return oTemp;
		case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICETAILLE:
			// Une taille chaine est possible
		default:
			// @@@ : Selon le type de la colonne
			// Temporaire : si c'est un booleen on le garde en booleen, il sera convertit bien assez tot
			switch (typeof oValeur)
			{
			case "boolean":
				return oValeur;
			default:
				return (oValeur + "");
		}
			break;
		}
	}
	else
	{
		return this.__oGetValeurDefaut();
	}
};

WDZRColonne.prototype.__oGetValeurDefaut = function __oGetValeurDefaut()
{
	switch (this.m_eProprieteAssocie)
	{
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_VISIBLE:
		return true;
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_ETAT:
		return WDChamp.prototype.ms_eEtatActif;
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICEGRAS:
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICEITALIQUE:
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICESOULIGNE:
		return false;
	case WDChamp.prototype.XML_CHAMP_PROP_NUM_POLICETAILLE:
		return 0;
	default:
		// @@@ : Selon le type de la colonne
		return "";
	}
};

WDZRColonne.prototype.fGetCompare = function fGetCompare(bCommencePar)
{
	// @@@ : Selon le type de la colonne et ses options
	return bCommencePar ? this.nCompareChaineCommencePar : this.nCompareChaine;
};

WDZRColonne.prototype.nCompareChaine = function nCompareChaine(sValeur1, sValeur2)
{
	if (sValeur1 < sValeur2)
	{
		return -1;
	}
	else if (sValeur1 > sValeur2)
	{
		return 1;
	}
	else
	{
		return 0;
	}
};
WDZRColonne.prototype.nCompareChaineCommencePar = function nCompareChaineCommencePar(sValeur1, sValeur2)
{
	var nLongueur = Math.min(sValeur1.length, sValeur2.length);
	return this.nCompareChaine(sValeur1.substring(0, nLongueur), sValeur2.substring(0, nLongueur));
};

// Manipulation d'une zone repetee galerie
function WDZRNavigateur(sAliasChamp, tabCouleurFond, nNbLignesLogiquesParLignePhysique)
{
	// Si on est pas dans l'init d'un protoype
	if (sAliasChamp)
	{
		// Appel le constructeur de la classe de base
		WDChampParametresHote.prototype.constructor.apply(this, [sAliasChamp, undefined, undefined]);

		// Tableaux des lignes
		this.m_tabLignes = [];
		// Tableaux des attributs/colonnes
		this.m_tabColonnes = [];
		// Tableaux des ruptures
		this.m_tabRuptures = [];
		// Tri (tableau d'objets)
		this.m_tabTri = [];
		// Couleur de fond
		this.m_tabCouleurFond = tabCouleurFond;
		// Nombre de colonnes de la ZR
		this.m_nNbLignesLogiquesParLignePhysique = nNbLignesLogiquesParLignePhysique;
	}
};

// Declare l'heritage
WDZRNavigateur.prototype = new WDChampParametresHote();
// Surcharge le constructeur qui a ete efface
WDZRNavigateur.prototype.constructor = WDZRNavigateur;

WDZRNavigateur.prototype.ms_nLigneInvalide = -1;
WDZRNavigateur.prototype.ms_sDynO = "[%";
WDZRNavigateur.prototype.ms_sDynF = "%]";
WDZRNavigateur.prototype.ms_sDynSi = "[%SI%]";
WDZRNavigateur.prototype.ms_sDynAlors = "[%ALORS%]";
WDZRNavigateur.prototype.ms_sDynFin = "[%FIN%]";
WDZRNavigateur.prototype.ms_sInclureHautRupture = "INCLURE_HAUTRUPTURE";
WDZRNavigateur.prototype.ms_sInclureBasRupture = "INCLURE_BASRUPTURE";
WDZRNavigateur.prototype.ms_sConditionEgal = "=";
WDZRNavigateur.prototype.ms_sConditionDifferent = "!=";
WDZRNavigateur.prototype.ms_sPropriete = "..";
WDZRNavigateur.prototype.ms_sConversion = ";";
WDZRNavigateur.prototype.ms_nAttributRuptureLigneDebut = -1;
WDZRNavigateur.prototype.ms_nAttributRuptureLigneFin = -2;
WDZRNavigateur.prototype.ms_nAttributLigneRepliee = -3;
WDZRNavigateur.prototype.ms_nAttributIncludeHautRupture = -4;
WDZRNavigateur.prototype.ms_nAttributIncludeBasRupture = -5;
WDZRNavigateur.prototype.ms_oRegExpAlias = new RegExp("zrl_(\\d+)_([A-Za-z0-9-_\\:\\.]+)", "");

// Initialisation :
WDZRNavigateur.prototype.Init = function Init()
{
	// Appel de la methode de la classe de base
	WDChampParametresHote.prototype.Init.apply(this, arguments);

	// Parse le HTML
	this.__HTMLParse();

	// Initialise la valeur des champs cache
	this.m_oChampDeb.value = "1";
	this.m_oChampOcc.value = "0";
	this.m_oChampFormulaire.value = "0";
};

// Trouve les divers elements : liaison avec le HTML
WDZRNavigateur.prototype._vLiaisonHTML = function _vLiaisonHTML(sSuffixeHote)
{
	// Appel de la methode de la classe de base
	WDChampParametresHote.prototype._vLiaisonHTML.apply(this, arguments);

	// Recupere les differents champs caches
	this.m_oChampDeb = this.oGetElementByName(document, "_DEB");
	this.m_oChampOcc = document.getElementsByName("_" + this.m_sAliasChamp + "_OCC")[0];
};

// Trouve le champ formulaire
WDZRNavigateur.prototype._voGetChampFormulaire = function _voGetChampFormulaire()
{
	// Ignore l'implementation avec _DATA de WDChampParametres
	// Il doit y avoir une meilleure solution (en particulier deplacer le code lie au ZR dans WDChamp mais cela va faire des effets de bord a l'init)
	return WDChamp.prototype._voGetChampFormulaire.apply(this, arguments);
};

// Interface de declaration
WDZRNavigateur.prototype.DeclareColonne = function DeclareColonne(sAlias, eProprieteAssocie)
{
	this.m_tabColonnes.push(new WDZRColonne(sAlias, eProprieteAssocie));
};
WDZRNavigateur.prototype.DeclareRupture = function DeclareRupture(sAlias, sAliasColonne, tabPCodesHaut, tabPCodesBas, bVisibleHaut, bVisibleBas)
{
	this.m_tabRuptures.push(new WDZRRupture(sAlias, this._nGetColonneSelonAlias(sAliasColonne), tabPCodesHaut, tabPCodesBas, bVisibleHaut, bVisibleBas));
};

// Occurrence de la ZR
WDZRNavigateur.prototype._nGetNbLignes = function _nGetNbLignes()
{
	return this.m_tabLignes.length;
};

// Nombre de attributs/colonnes de la ZR
WDZRNavigateur.prototype._nGetNbColonnes = function _nGetNbColonnes()
{
	return this.m_tabColonnes.length;
};

// Nombre de rupture de la ZR
WDZRNavigateur.prototype._nGetNbRuptures = function _nGetNbRuptures()
{
	return this.m_tabRuptures.length;
};

WDZRNavigateur.prototype._nGetRuptureSelonAlias = function _nGetRuptureSelonAlias(sAliasRupture)
{
	var tabRuptures = this.m_tabRuptures;
	var i;
	var nLimiteI = this._nGetNbRuptures();
	for (i = 0; i < nLimiteI; i++)
	{
		if (tabRuptures[i].m_sAlias == sAliasRupture)
		{
			return i;
		}
	}
	return undefined;
};

WDZRNavigateur.prototype._nGetColonneSelonAlias = function _nGetColonneSelonAlias(sAliasColonne)
{
	var tabColonnes = this.m_tabColonnes;
	var i;
	var nLimiteI = this._nGetNbColonnes();
	for (i = 0; i < nLimiteI; i++)
	{
		if (tabColonnes[i].m_sAlias == sAliasColonne)
		{
			return i;
		}
	}
	return undefined;
};

// Recalcul les ruptures pour une ligne
WDZRNavigateur.prototype.__RupturesEntreLignes = function __RupturesEntreLignes(oLigne1, oLigne2, nLigne1, nLigne2)
{
	var nRuptures;
	var tabRuptures = this.m_tabRuptures;
	if (oLigne1 && oLigne2)
	{
		nRuptures = WDZRLigne.prototype.ms_nRien;
		var tabValeurs1 = oLigne1.tabGetValeurs();
		var tabValeurs2 = oLigne2.tabGetValeurs();
		var i;
		var nLimiteI = this._nGetNbRuptures();
		for (i = 0; i < nLimiteI; i++)
		{
			var nColonne = tabRuptures[i].m_nColonne;
			if (tabValeurs1[nColonne] != tabValeurs2[nColonne])
			{
				nRuptures |= (1 << i);
			}
		}
	}
	else
	{
		// Premiere (oLigne2) ou derniere ligne (oLigne1)
		nRuptures = WDZRLigne.prototype.ms_nTous;
	}

	var nRupturesPrecedente;
	if (oLigne1)
	{
		nRupturesPrecedente = oLigne1.nGetRuptures(false);
		oLigne1.SetRupturesBas(nRuptures);
		// Execute les PCodes d'affichage des ruptures
		this.__AppelPCodeAffichageRuptures(nLigne1, nRuptures, nRupturesPrecedente, false);
	}
	if (oLigne2)
	{
		nRupturesPrecedente = oLigne2.nGetRuptures(true);
		oLigne2.SetRupturesHaut(nRuptures);
		// Execute les PCodes d'affichage des ruptures
		this.__AppelPCodeAffichageRuptures(nLigne2, nRuptures, nRupturesPrecedente, true);
	}
};

// Notifie de la modication de la ruptures
WDZRNavigateur.prototype.__OnLigneModificationRuptures = function __OnLigneModificationRuptures(nLigne)
{
	// Si on demande de modifier la ligne -1, c'est que la premier ligne doit etre modifiee
	if (-1 == nLigne)
	{
		// Traite ensuite comme cas particuler dans __LigneAfficheCalculs
		nLigne = 0;
	}
	var oLigne = this.m_tabLignes[nLigne];
	if (oLigne)
	{
		oLigne.SetModifieRuptures(true);
	}
};

// Notifie de la modication des lignes (recalcul les ruptures)
WDZRNavigateur.prototype.__OnLigneModification = function __OnLigneModification(nLigne, bMontre, bSansReaffichage)
{
	// On note aussi de recalculer la rupture entre la ligne precedente et la ligne
	this.__OnLigneModificationRuptures(nLigne - 1);
	this.__OnLigneModificationRuptures(nLigne);

	this._LigneAffiche(nLigne, bMontre, bSansReaffichage);
};

// Modifie une ligne avec un tableau de valeurs
// Version interne avec les parametres validees
WDZRNavigateur.prototype.__LigneModifie = function __LigneModifie(tabValeurs, nLigne)
{
	// Formate le tableau selon les attributs/colonnes
	var tabLigneValeurs = this.m_tabLignes[nLigne].tabGetValeurs();
	var tabColonnes = this.m_tabColonnes;
	var i;
	var nLimiteI = tabColonnes.length;
	for (i = 0; i < nLimiteI; i++)
	{
		tabLigneValeurs[i] = tabColonnes[i].oGetValeurInterne(tabValeurs[i]);
	}

	// Notifie de la modication des lignes (recalculs, PCode et reaffichage)
	this.__OnLigneModification(nLigne);
};

// Indique que un champ formulaire a ete modifie dans la ligne
WDZRNavigateur.prototype.__OnLigneModifieFormulaire = function __OnLigneModifieFormulaire(oEvent, tabParametres)
{
	var nColonne = tabParametres[0];
	var nLigne = tabParametres[1];

	// Lit la valeur de l'element
	var oChamp = bIE ? oEvent.srcElement : oEvent.target;
	var oValeur = oChamp.value;
	switch (oChamp.type.toLowerCase())
	{
	case "checkbox":
		// Ne fonctionne pas (comme en serveur) en cas de multiple coche
		oValeur = oChamp.checked ? true : false;
		break;
	case "radio":
		// On recoit la selection pour celui selectionne et la deselection pour l'autre
		if (!oChamp.checked)
		{
			return;
		}
		break;
	// select-multiple inutilisable dans une ZR
	case "select-multiple":
	case "select-one":
		oValeur = (oChamp.selectedIndex != -1) ? parseInt(oChamp.options[oChamp.selectedIndex].value, 10) : -1;
		break;
	default:
		break;
	}

	this.m_tabLignes[nLigne].tabGetValeurs()[nColonne] = oValeur;

	// Notifie de la modication des lignes (recalcul les ruptures)
	// Pas besoin de reaffichage si on n'a pas de ruptures
	this.__OnLigneModification(nLigne, undefined, (0 == this._nGetNbRuptures()));
};

// Hook les onblur/onchange des champs formulaire de la ZR
WDZRNavigateur.prototype.__SetOnBlurChange = function __SetOnBlurChange()
{
	// Sans les liens
	var tabElements = clWDUtil.tabGetElements(this.m_oHote, false);
	var i;
	var nLimiteI = tabElements.length;
	for (i = 0; i < nLimiteI; i++)
	{
		var oElement = tabElements[i];
		// Si on est dans un champ formulaire, le nom de l'element est de la forme "zrl_LIGNE_ATTRIBUT"
		var sElementNom = oElement.name;
		var oRes;
		if (sElementNom && sElementNom.length && (oRes = this.ms_oRegExpAlias.exec(sElementNom)) && oRes[1] && oRes[2])
		{
			var nLigne = this._nLigneWLLigne(parseInt(oRes[1], 10));
			var nColonne = this._nGetColonneSelonAlias(oRes[2]);
			if ((nLigne !== undefined) && (nColonne !== undefined))
			{
				var sOnXxx = (oElement.onchange !== undefined) ? "onchange" : "onblur";
				clWDUtil.SetOnXxx(oElement, sOnXxx, this, this.__OnLigneModifieFormulaire, [nColonne, nLigne, sElementNom], true);
			}
		}
	}
};

// Gere les lignes modifiee :
// - Recalcul des ruptures
// - PCode d'affichage
WDZRNavigateur.prototype.__LigneAfficheCalculs = function __LigneAfficheCalculs(nLigneDepuis)
{
	var tabLignes = this.m_tabLignes;
	var i;
	var nLimiteI = this._nGetNbLignes();

	// - PCode d'affichage (avant le calcul des ruptures)
	var fPCode = this.RecuperePCode(this.ms_nEventNavAffichageLigne);
	for (i = nLigneDepuis; i < nLimiteI; i++)
	{
		if (tabLignes[i].bGetClearPCodeAffichage())
		{
			this.__AppelPCodeAffichage(i, fPCode);
		}
	}

	// Calcul des ruptures
	if (0 < this._nGetNbRuptures())
	{
		// On commence a la ligne precedente (pour la rupture entre la ligne precedente et la premiere ligne reaffichee
		for (i = (0 < nLigneDepuis) ? (nLigneDepuis - 1) : nLigneDepuis; i < nLimiteI; i++)
		{
			var oLigne = tabLignes[i];
			if (oLigne.bGetClearModifieRuptures())
			{
				// Si on est sur la premiere ligne le traite aussi comme un cas particulier (sinon le haut de la premiere ligne n'est pas affiche)
				if (i == 0)
				{
					this.__RupturesEntreLignes(undefined, oLigne, undefined, 0);
				}
				var oLigneSuivante = (i < (nLimiteI - 1)) ? tabLignes[i + 1] : undefined;
				this.__RupturesEntreLignes(oLigne, oLigneSuivante, i, i + 1);
			}
		}
	}
};

// Appel un PCode d'affichage
WDZRNavigateur.prototype.__AppelPCodeAffichage = function __AppelPCodeAffichage(nLigne, fPCode)
{
	if (fPCode != clWDUtil.m_pfVide)
	{
		try
		{
			// Fait comme si on etait dans une ZR (on est une ZR)
			this.m_sAliasZR = this.m_sAliasChamp;
			// Note que l'on est en PCode d'affichage (pas de reentrance)
			this.m_nPCodeAffichageLigne = nLigne;
			// Appel la methode sur la ligne
			this.oAppelSurLigneZR(nLigne + 1, fPCode, []);
		}
		catch (e)
		{
			throw e;
		}
		finally
		{
			delete this.m_nPCodeAffichageLigne;
			delete this.m_sAliasZR;
		}
	}
};
// Appel des PCodes d'affichage des ruptures
WDZRNavigateur.prototype.__AppelPCodeAffichageRuptures = function __AppelPCodeAffichageRuptures(nLigne, nRuptures, nRupturesPrecedente, bHaut)
{
	var tabRuptures = this.m_tabRuptures;
	var i;
	var nLimiteI = tabRuptures.length;
	for (i = 0; i < nLimiteI; i++)
	{
		if (nRuptures & (1 << i))
		{
			this.__AppelPCodeAffichage(nLigne, tabRuptures[i].RecuperePCode(this.ms_nEventNavAffichageLigne, bHaut));
		}
	}
};

// Affiche la ZR depuis un point donne
WDZRNavigateur.prototype.__LigneAffiche = function __LigneAffiche(nLigneDepuis)
{
	// Gere les lignes modifiee :
	// - Recalcul des ruptures
	// - PCode d'affichage
	this.__LigneAfficheCalculs(nLigneDepuis);

	// Conserve le focus
	try
	{
		var oFocus = document.activeElement;
		if (oFocus && clWDUtil.bEstFils(oFocus, this.m_oHote, document))
		{
			this.m_sFocusNom = oFocus.name;
			if (this.m_sFocusNom && this.m_sFocusNom.length)
			{
				this.m_nFocusIndice = clWDUtil.nDansTableau(document.getElementsByName(this.m_sFocusNom), oFocus);
				if (-1 == this.m_nFocusIndice)
				{
					this.m_nFocusIndice = 0;
				}
			}
		}
	}
	catch (e)
	{
	}

	// @@@ A optimiser : reaffiche tout

	// Supprime les elements JavaScript pour les reference circulaires entre le DOM et le JS
	// Vide la cellule
	clWDUtil.SupprimeFilsEtOnFocus(this.m_oHote, false);

	var tabHTML = [];
	var tabLignes = this.m_tabLignes;
	var i;
	var nLimiteI = this._nGetNbLignes();
	for (i = 0; i < nLimiteI; i++)
	{
		this.__HTMLGenere(i, tabLignes[i], this.m_tabElementsHTML, tabHTML);
	}
	// A factoriser avec WDTable::GenereLignesHTML
	if (bIE && clWDUtil.bBaliseEstTag(this.m_oHote, "table"))
	{
		var tabHTMLHote = (this.m_oHote.outerHTML + "").split("><");
		this.m_oHote.outerHTML = tabHTMLHote[0] + ">" + tabHTML.join("") + "<" + tabHTMLHote[tabHTMLHote.length - 1];
	}
	else
	{
		this.m_oHote.innerHTML = tabHTML.join("");
	}

	// Trouve l'hote (potentiellement ecrase par le outerHTML)
	this._vLiaisonHTML();

	// Hook les onblur/onchange des elements
	this.__SetOnBlurChange();

	// Si le champ est superposable, IE ne le redessine pas bien
	if (bIEQuirks)
	{
		var oExterne = _JGE(this.m_sAliasChamp, document, true, false);
		if (oExterne && (_JGCS(oExterne).position == "absolute"))
		{
			oExterne.className = oExterne.className;
		}
	}

	// Replace le focus
	if (this.m_nFocusIndice !== undefined)
	{
		this.nSetTimeoutUnique("__SetFocus", 1);
	}
};

// Replace le focus perdu par le reaffichage
WDZRNavigateur.prototype.__SetFocus = function __SetFocus()
{
	if (this.m_nFocusIndice !== undefined)
	{
		try
		{
			document.getElementsByName(this.m_sFocusNom)[this.m_nFocusIndice].focus();
		}
		catch (e)
		{
		}
		delete this.m_nFocusIndice;
		delete this.m_sFocusNom;
	}
};

// Presente une ligne de la ZR
WDZRNavigateur.prototype.__Montre = function __Montre(nLigne)
{
	// @@@
};

// Indique que la valeur du champ

// Marque une ligne comme supprimee (ne l'enleve pas du tableau pour optimiser dans __LigneSupprimeTout)
WDZRNavigateur.prototype.__OnLigneSupprime = function __OnLigneSupprime(nLigne)
{
	// Notifie la ligne
	this.m_tabLignes[nLigne].OnSupprime();
	this.m_tabLignes[nLigne] = null;
};

// Supprime une ligne
WDZRNavigateur.prototype.__LigneSupprime = function __LigneSupprime(nLigne)
{
	// Supprime la ligne
	this.__OnLigneSupprime(nLigne);
	this.m_tabLignes.splice(nLigne, 1);

	this.m_oChampOcc.value = this._nGetNbLignes();

	// On note aussi de recalculer la rupture entre la ligne precedente et la ligne
	this.__OnLigneModificationRuptures(nLigne - 1);
};

// Supprime toutes les lignes
WDZRNavigateur.prototype.__LigneSupprimeTout = function __LigneSupprimeTout()
{
	// Supprime toutes les lignes
	var i;
	var nLimiteI = this._nGetNbLignes();
	for (i = 0; i < nLimiteI; i++)
	{
		this.__OnLigneSupprime(i);
	}
	// Et vide le tableau
	this.m_tabLignes.length = 0;
	this.m_oChampOcc.value = this._nGetNbLignes();

	// Reaffiche la table depuis le debut
	this._LigneAffiche(0);
};

// Fonction de comparaison pour le tri
WDZRNavigateur.prototype.__nTriCompare = function __nTriCompare (oLigne1, oLigne2)
{
	// Compare selon les criteres de tri
	var tabTri = this.m_tabTri;
	var tabValeurs1 = oLigne1.tabGetValeurs();
	var tabValeurs2 = oLigne2.tabGetValeurs();
	var tabColonne = this.m_tabColonnes;
	var i;
	var nLimiteI = tabTri.length;
	for (i = 0; i < nLimiteI; i++)
	{
		var oTri = tabTri[i];
		var nRes = oTri.m_fCompare.apply(tabColonne[oTri.m_nColonne], [tabValeurs1[oTri.m_nColonne], tabValeurs2[oTri.m_nColonne]]);
		// Si les valeurs ne sont pas egales
		if (0 != nRes)
		{
			// Si on inverse
			return oTri.m_bCroissant ? nRes : -nRes;
		}
	}
	// Egaux
	return 0;
};

// Recherche une ligne
WDZRNavigateur.prototype.__nLigneCherche = function __nLigneCherche (nColonne, sRecherche, bCommencePar, nLigneDebut)
{
	// Trouve la colonne et normalise la valeur recherchee
	var oColonne = this.m_tabColonnes[nColonne];
	var oRecherche = oColonne.oGetValeurInterne(sRecherche);

	// Trouve la fonction de comparaison
	var fCompare = oColonne.fGetCompare(bCommencePar);

	// Optimisation possible : en cas de table triee faire une recherche dichotomique

	// Recherche dans les lignes
	var tabLignes = this.m_tabLignes;
	var i;
	var nLimiteI = this._nGetNbLignes();
	for (i = nLigneDebut; i < nLimiteI; i++)
	{
		if (0 == fCompare.apply(oColonne, [oRecherche, this.__oGetValeurColonne(nColonne, tabLignes[i])]))
		{
			return i;
		}
	}

	return this.ms_nLigneInvalide;
};

WDZRNavigateur.prototype.__sLitPropriete = function __sLitPropriete(nLigne, oLigne, ePropriete, nParametre, bPourCondition)
{
	switch (ePropriete)
	{
	case this.XML_CHAMP_PROP_NUM_VALEUR:
		// Donne la ligne en indice WL
		return this._nLigneLigneWL(nLigne);
	case this.XML_CHAMP_PROP_NUM_COULEURFOND:
		// Si la ligne a une couleur de fond (non disponible en WL navigateur actuellement)
		if (oLigne.m_sCouleurFond !== undefined)
		{
			return oLigne.m_sCouleurFond;
		}
		var sCouleur = -1;
		if (this.m_tabCouleurFond && this.m_tabCouleurFond.length)
		{
			// Notre premier indice est zero, mais c'est la premiere ligne qui ets impaire et le tableau est [impair, pair]
			// Donc +1 -1 => 0
			sCouleur = this.m_tabCouleurFond[nLigne % this.m_tabCouleurFond.length];
		}
		if ((sCouleur == -1) && !bPourCondition)
		{
			sCouleur = "transparent";
		}
		return sCouleur;

	case this.ms_nAttributRuptureLigneDebut:
		// Il n'y a pas encore de lignes invisibles
		// Donc c'est une simple division
		return (nLigne % this.m_nNbLignesLogiquesParLignePhysique) == 0;
	case this.ms_nAttributRuptureLigneFin:
		// Il n'y a pas encore de lignes invisibles
		// Donc c'est une simple division
		return (nLigne % this.m_nNbLignesLogiquesParLignePhysique) == (this.m_nNbLignesLogiquesParLignePhysique - 1);
	case this.ms_nAttributLigneRepliee:
		return (false == this.m_tabLignes[nLigne].bGetDeroule());
	case this.ms_nAttributIncludeHautRupture:
		return this.__bGetRuptureVisible(nLigne, nParametre, true);
	case this.ms_nAttributIncludeBasRupture:
		return this.__bGetRuptureVisible(nLigne, nParametre, false);
	default:
		// @@@
//		alert(ePropriete);
		return "";
	}
};

// Indique si la rupture est visible
WDZRNavigateur.prototype.__bGetRuptureVisible = function __bGetRuptureVisible(nLigne, nRupture, bHaut)
{
	// Si la rupture est invisible
	if (!this.m_tabRuptures[nRupture].bVisible(bHaut))
	{
		return false;
	}
	// Rebond sur la methode de la ligne
	return this.m_tabLignes[nLigne].bGetRuptureVisible(nRupture, bHaut);
};

// Trouve la valeur d'une colonne/ligne
WDZRNavigateur.prototype._oGetValeurColonne = function _oGetValeurColonne(nColonne, nLigne)
{
	return this.__oGetValeurColonne(nColonne, this.m_tabLignes[nLigne]);
};
// Trouve la valeur d'une colonne/ligne
WDZRNavigateur.prototype.__oGetValeurColonne = function __oGetValeurColonne(nColonne, oLigne)
{
	return oLigne.tabGetValeurs()[nColonne];
};

//////////////////////////////////////////////////////////////////////////
// Interface interne pour le WL

// Modifie une ligne avec un tableau de valeurs
WDZRNavigateur.prototype._LigneModifie = function _LigneModifie(tabValeurs, nLigneWL)
{
	var nLigne = this._nLigneWLLigne(nLigneWL, this._nGetSelection());
	if (nLigne !== undefined)
	{
		// Modifie la ligne (provoque le reaffichage)
		this.__LigneModifie(tabValeurs, nLigne);
	}
};

// Insere une ligne avec un tableau de valeurs
// Sans indice, insere a la fin (= ajout)
WDZRNavigateur.prototype._nLigneInsere = function _nLigneInsere(bTrie, tabValeurs, nLigneWL)
{
	var nLigne = this._nLigneWLLigne(nLigneWL);
	// Ajoute une ligne vide
	var oLigne = new WDZRLigne(this._nGetNbColonnes());
	if (nLigne !== undefined)
	{
		// Ajoute au milieu
		this.m_tabLignes.splice(nLigne, 0, oLigne);
	}
	else
	{
		// Ajoute a la fin
		this.m_tabLignes.push(oLigne);
		nLigne = this._nGetNbLignes() - 1;
	}
	this.m_oChampOcc.value = this._nGetNbLignes();

	// Modifie la ligne (provoque le reaffichage)
	this.__LigneModifie(tabValeurs, nLigne);

	var i;
	var nLimiteI;
	if (bTrie)
	{
		// Lent mais juste : retrie la table si besoin
		this._TriEncore();
		// Si le numero de ligne change pendant le tri
		if (this.m_tabLignes[nLigne] != oLigne)
		{
			nLimiteI = this._nGetNbLignes();
			for (i = 0; i < nLimiteI; i++)
			{
				if (this.m_tabLignes[i] == oLigne)
				{
					nLigne = i;
					break;
				}
			}
		}

		// Modifie la ligne (provoque le reaffichage)
		this.__LigneModifie(tabValeurs, nLigne);
	}

	// Si la ligne est dans une rupture repliee, ajoute la ligne en repliee
	nLimiteI = this._nGetNbRuptures();
	if (0 < nLimiteI)
	{
		if (0 < nLigne)
		{
			// Copie l'etat d'enroulement de la ligne precedente pour les ruptures identiques
			var oLignePrecedente = this.m_tabLignes[nLigne - 1];
			for (i = 0; i < nLimiteI; i++)
			{
				if (oLigne.bGetRuptureDirect(i, true))
				{
					// Plus dans la meme zone de rupture
					break;
				}
				else
				{
					// Dans la meme zone de rupture : copie l'enroulement
					oLigne.CopieEnrouleDeroule(oLignePrecedente, i);
				}
			}
		}
		if (nLigne < (this._nGetNbLignes() - 1))
		{
			// Copie l'etat d'enroulement de la ligne precedente pour les ruptures identiques
			var oLigneSuivante = this.m_tabLignes[nLigne + 1];
			for (i = 0; i < nLimiteI; i++)
			{
				if (oLigneSuivante.bGetRuptureDirect(i, true))
				{
					// Plus dans la meme zone de rupture
					break;
				}
				else
				{
					// Dans la meme zone de rupture : copie l'enroulement
					oLigne.CopieEnrouleDeroule(oLigneSuivante, i);
				}
			}
		}
	}

	// Conversion en numero de ligne WL
	return this._nLigneLigneWL(nLigne);
};

// Affiche la ZR depuis un point donne
WDZRNavigateur.prototype._LigneAffiche = function _LigneAffiche(nLigne, bMontre, bSansReaffichage)
{
	// Ne fait pas de redessin si on le demande ou si on est deja en PCode d'affichage (donc en redessin)
	if (bSansReaffichage || (this.m_nPCodeAffichageLigne !== undefined))
	{
		return;
	}

	// En fait on affiche depuis une ligne avant (la rupture a peut-etre ete modifiee)
	var nLigneAffiche = nLigne + ((0 < nLigne) ? -1 : 0);
	// Note que l'on devra afficher la ligne
	if (this.m_nLigneAfficheSuivante === undefined)
	{
		this.m_nLigneAfficheSuivante = nLigneAffiche;
	}
	else
	{
		this.m_nLigneAfficheSuivante = Math.min(nLigneAffiche, this.m_nLigneAfficheSuivante);
	}
	if (bMontre)
	{
		// Montre toujours la derniere ligne demandee
		this.m_bLigneMontreSuivante = bMontre;
		this.m_nLigneMontreSuivante = nLigne;
	}
	// Lance le setTimeout (dans le cas ou le WL ne valide pas explicitement la MAJ)
	this.nSetTimeoutUnique("_Affiche", 1);
};

WDZRNavigateur.prototype._Affiche = function _Affiche()
{
	// Supprime le Timeout de meme nom s'il existe
	this.AnnuleTimeXXX("_Affiche", false);
	// En fait on affiche depuis une ligne avant (la rupture a peut-etre ete modifiee)
	this.__LigneAffiche(this.m_nLigneAfficheSuivante);
	if (this.m_bLigneMontreSuivante)
	{
		this.__Montre(this.m_nLigneMontreSuivante);
	}
};

// Affiche la ZR depuis un point donne
WDZRNavigateur.prototype._nLigneDeplace = function _nLigneDeplace(nLigneSource, nLigneDestination, bEchange, bMontre)
{
	var tabLignes = this.m_tabLignes;
	var tabLigne = tabLignes[nLigneSource];
	if (bEchange)
	{
		tabLignes[nLigneSource] = tabLignes[nLigneDestination];
		tabLignes[nLigneDestination] = tabLigne;
		// Modifie les lignes (provoque le reaffichage)
		this.__OnLigneModification(nLigneSource);
		this.__OnLigneModification(nLigneDestination, bMontre);
	}
	else
	{
		tabLignes.splice(nLigneSource, 1);
		// Decale la destination si besoin
		if (nLigneSource < nLigneDestination)
		{
			nLigneDestination--;
		}
		tabLignes.splice(nLigneDestination, 0, tabLigne);
		// Modifie les lignes (provoque le reaffichage)
		this.__OnLigneModification(nLigneDestination, bMontre);
		// Modifie aussi les ruptures de la ligne avant la source)
		this.__OnLigneModificationRuptures(nLigneSource - 1);
	}

	// Conversion en numero de ligne WL
	return this._nLigneLigneWL(nLigneDestination);
};

// Supprime une ligne
WDZRNavigateur.prototype._LigneSupprime = function _LigneSupprime(nLigne)
{
	// Supprime la ligne (provoque le reaffichage)
	this.__LigneSupprime(nLigne);
};

// Supprime toutes les lignes
WDZRNavigateur.prototype._LigneSupprimeTout = function _LigneSupprimeTout()
{
	// Supprime toutes les lignes (provoque le reaffichage)
	this.__LigneSupprimeTout();
};

// Retourne la ligne selectionnee
WDZRNavigateur.prototype._nGetSelection = function _nGetSelection()
{
	// L'indice est en WL
	return this._nLigneWLLigne(this.m_oChampFormulaire.value);
};

// Informations sur les ruptures
WDZRNavigateur.prototype._nIndiceRupture = function _nIndiceRupture (sAliasRupture, nLigne)
{
	// Trouve l'indice de la rupture
	var nRupture = this._nGetRuptureSelonAlias(sAliasRupture);
	if (nRupture !== undefined)
	{
		// Remonte les lignes
		var tabLignes = this.m_tabLignes;
		var i;
		for (i = nLigne; 0 <= i; i--)
		{
			if (tabLignes[i].bGetRupture(nRupture, true))
			{
				// Trouve
				return this._nLigneLigneWL(i);
			}
		}
		// Normalement n'arrive pas (sauve si on n'a pas de lignes ou pas de selection)
	}
	return this.ms_nLigneInvalide;
};

// Tri
WDZRNavigateur.prototype._Tri = function _Tri (sSensColonnes)
{
	// Annule le precedent tri
	this._TriAnnule();

	// Memorise le tri
	var tabColonnes = this.m_tabColonnes;
	var bCroissant = true;
	var i;
	var nLimiteI;
	switch (sSensColonnes)
	{
	case "-":
		bCroissant = false;
		// Pas de break
	case "+":
		// Tri sur tous les attributs
		nLimiteI = this._nGetNbColonnes();
		for (i = 0; i < nLimiteI; i++)
		{
			this.m_tabTri.push({ m_fCompare : tabColonnes[i].fGetCompare(true), m_nColonne: i, m_bCroissant : bCroissant });
		}
		break;
	default:
		var tabSensColonnes = sSensColonnes.split("\t");
		nLimiteI = tabSensColonnes.length;
		for (i = 0; i < nLimiteI; i++)
		{
			var sAliasColonne = tabSensColonnes[i];
			bCroissant = true;
			switch(sAliasColonne.substring(0, 1))
			{
			case "-":
				bCroissant = false;
				// Pas de break
			case "+":
				sAliasColonne = sAliasColonne.substring(1);
				break;
			default:
				break;
			}
			var nColonne = this._nGetColonneSelonAlias(sAliasColonne);
			if (nColonne !== undefined)
			{
				this.m_tabTri.push({ m_fCompare: tabColonnes[nColonne].fGetCompare(true), m_nColonne: nColonne, m_bCroissant: bCroissant });
			}
		}
		break;
	}

	// Retri
	this._TriEncore();
};

// Retri
WDZRNavigateur.prototype._TriEncore = function _TriEncore ()
{
	// Uniquement si on a un tri
	if (0 < this.m_tabTri.length)
	{
		var oThis = this;
		this.m_tabLignes.sort(function() { return oThis.__nTriCompare(arguments[0], arguments[1]); });
	}
};

// Annule le tri
WDZRNavigateur.prototype._TriAnnule = function _TriAnnule ()
{
	this.m_tabTri = [];
};

// Recherche une ligne
WDZRNavigateur.prototype._nLigneCherche = function _nLigneCherche (sAliasColonne, sRecherche, bCommencePar, nLigneDebut)
{
	// Trouve l'indice de la rupture
	var nColonne = this._nGetColonneSelonAlias(sAliasColonne);
	var nLigneResultat = this.ms_nLigneInvalide;
	if (nColonne !== undefined)
	{
		// Effectue la recherche
		nLigneResultat = this.__nLigneCherche(nColonne, sRecherche, bCommencePar, nLigneDebut);
	}

	// Conversion en numero de ligne WL
	return this._nLigneLigneWL(nLigneResultat);
};

// Enroule/deroule une ligne
// inverse si bDeroule n'est pas defini
WDZRNavigateur.prototype._EnrouleDerouleI = function _EnrouleDerouleI(nLigne, nRupture, bDeroule, bRecursif, bAvecAffichage)
{
	var oLigne = this.m_tabLignes[nLigne];

	// Force le recalcul des ruptures sur la ligne
	this.__RupturesEntreLignes(this.m_tabLignes[nLigne - 1], oLigne, nLigne - 1, nLigne);

	// Uniquement si on a une rupture sur cette ligne
	if (oLigne.bGetRupture(nRupture, true))
	{
		// Enroule deroule la rupture sur la ligne (si la rupture declenche a la ligne)
		oLigne.EnrouleDeroule(nRupture, bDeroule, bRecursif);

		// Il faut enrouler toutes les lignes de la rupture
		var oLignePrecedente = oLigne;
		var i;
		var nLimiteI = this._nGetNbLignes();
		for (i = nLigne + 1; i < nLimiteI; i++)
		{
			// Force le recalcul des ruptures sur la ligne
			var oLigneSuivante = this.m_tabLignes[i];
			this.__RupturesEntreLignes(oLignePrecedente, oLigneSuivante, i - 1, i);

			// Si il n'y a pas de rupture
			if (!oLigneSuivante.bGetRupture(nRupture, true))
			{
				oLigneSuivante.EnrouleDeroule(nRupture, bDeroule, bRecursif);
				oLignePrecedente = oLigneSuivante;
			}
			else
			{
				break;
			}
		}

		// Reaffiche la table si demande
		if (bAvecAffichage)
		{
			this._LigneAffiche(nLigne);
		}
	}
};
WDZRNavigateur.prototype._EnrouleDeroule = function _EnrouleDeroule(nLigneWL, sAliasRupture, bDeroule)
{
	var nLigne = this._nLigneWLLigne(nLigneWL, this._nGetSelection());
	if (nLigne !== undefined)
	{
		// Trouve l'indice de la rupture
		var nRupture;
		var bRecursif;
		if (sAliasRupture === undefined)
		{
			// Pour faire comme en code serveur et en WinDev : enroule depuis la rupture externe
			nRupture = (0 < this._nGetNbRuptures()) ? 0 : undefined;
			bRecursif = true;
		}
		else
		{
			nRupture = this._nGetRuptureSelonAlias(sAliasRupture);
			bRecursif = false;
		}
		if ((nRupture !== undefined) && (0 <= nRupture))
		{
			this._EnrouleDerouleI(nLigne, nRupture, bDeroule, bRecursif, true);
		}
	}
};

// Enroule/deroule toutes les lignes
WDZRNavigateur.prototype._EnrouleDerouleTout = function _EnrouleDerouleTout(bDeroule)
{
	var i;
	var nLimiteI = this._nGetNbLignes();
	for (i = 0; i < nLimiteI; i++)
	{
		var j;
		var nLimiteJ = this._nGetNbRuptures();
		for (j = 0; j < nLimiteJ; j++)
		{
			// Sans affichage et avec recalcul uniquement pour la premiere rupture
			this._EnrouleDerouleI(i, j, bDeroule, true, false);
		}
	}

	// Reaffiche la table
	this._LigneAffiche(0);
};

// Conversion d'un numero de ligne WL en numero de ligne interne
WDZRNavigateur.prototype._nLigneWLLigne = function _nLigneWLLigne(nLigneWL, nLigneSiUndefined, nLigneSiInvalide, bAccepteLigneSelectionnee)
{
	if (bAccepteLigneSelectionnee && (nLigneWL === -1))
	{
		// Retourne l'indice interne
		nLigneWL = this._nGetSelection();
	}
	else if (nLigneWL === undefined)
	{
		// Si l'indice indefini
		nLigneWL = nLigneSiUndefined;
	}
	else
	{
		// Force la conversion en entier
		nLigneWL = parseInt(nLigneWL, 10);
		if (!isNaN(nLigneWL))
		{
			nLigneWL--;
		}
	}

	// Si la valeur est definie (ou transformee en definie depuis indefinie)
	if (nLigneWL !== undefined)
	{
		// Si la valeur est valide et dans les bornes
		if (!isNaN(nLigneWL) && (this._nGetNbLignes() > nLigneWL) && (0 <= nLigneWL))
		{
			return nLigneWL;
		}
		return nLigneSiInvalide;
	}
	else
	{
		return nLigneWL;
	}
};

// Conversion d'un numero de ligne interne en numero de ligne WL
WDZRNavigateur.prototype._nLigneLigneWL = function _nLigneLigneWL(nLigne)
{
	return (this.ms_nLigneInvalide != nLigne) ? (nLigne + 1) : this.ms_nLigneInvalide;
};

//////////////////////////////////////////////////////////////////////////
// Interface pour le WL

// Ajoute une ligne avec une chaine de valeurs
WDZRNavigateur.prototype.Ajoute = function Ajoute (sValeur)
{
	return (this.ms_nLigneInvalide != this._nLigneInsere(true, ("" + sValeur).split("\t")));
};

// Ajoute une ligne avec une serie de valeurs
WDZRNavigateur.prototype.AjouteLigne = function AjouteLigne ()
{
	return this._nLigneInsere(true, this.__tabArgumentsVersTableau(arguments, 0));
};

// Modifie une ligne avec une chaine de valeurs
WDZRNavigateur.prototype.Modifie = function Modifie (sValeur, nLigneWL)
{
	this._LigneModifie(("" + sValeur).split("\t"), nLigneWL);
};

// Modifie une ligne avec une serie de valeurs
WDZRNavigateur.prototype.ModifieLigne = function ModifieLigne (nLigneWL)
{
	this._LigneModifie(this.__tabArgumentsVersTableau(arguments, 1), nLigneWL);
};

// Insere une ligne avec une chaine de valeurs
WDZRNavigateur.prototype.Insere = function Insere (sValeur, nLigneWL)
{
	// Pas de valeur de retour
	return (this.ms_nLigneInvalide != this._nLigneInsere(false, ("" + sValeur).split("\t"), nLigneWL));
};

// Insere une ligne avec une serie de valeurs
WDZRNavigateur.prototype.InsereLigne = function InsereLigne (nLigneWL)
{
	this._nLigneInsere(false, this.__tabArgumentsVersTableau(arguments, 1), nLigneWL);
};

// Deplace une ligne
WDZRNavigateur.prototype.DeplaceLigne = function DeplaceLigne(nSourceWL, nDestinationWL, nOperation)
{
	var nLigneSource = this._nLigneWLLigne(nSourceWL, undefined, undefined, true);
	var nLigneDestination = this._nLigneWLLigne(nDestinationWL, undefined, undefined, true);
	if ((nLigneSource !== undefined) && (nLigneDestination !== undefined) && (nLigneSource != nLigneDestination))
	{
		return this._nLigneDeplace(nLigneSource, nLigneDestination, 0 != (nOperation & 0x80000000), 0 != (nOperation & 65536));
	}
	else
	{
		// Erreur (pas this.ms_nLigneInvalide mais 0 pour cette fonction)
		return 0;
	}
};

// Supprime une ligne
WDZRNavigateur.prototype.Supprime = function Supprime(nLigneWL)
{
	var nLigne = this._nLigneWLLigne(nLigneWL, this._nGetSelection());
	if (nLigne !== undefined)
	{
		this._LigneSupprime(nLigne);
	}
};

// Supprime toutes les lignes
WDZRNavigateur.prototype.SupprimeTout = function SupprimeTout()
{
	this._LigneSupprimeTout();
};

// Nombre d'occurrence de la zone repetee
WDZRNavigateur.prototype.Occurrence = function Occurrence(nIndicateur)
{
	// Valeur par defaut = Nb colonnes
	if (nIndicateur === undefined)
	{
		nIndicateur = 1
	}
	switch (nIndicateur)
	{
	case 1:
		// toTotal
		return this._nGetNbLignes();
	case 2:
		// toColonne
		return this._nGetNbColonnes();
	default:
		return this.ms_nLigneInvalide;
	}
};

// Informations sur les ruptures
WDZRNavigateur.prototype.IndiceRupture = function IndiceRupture(sAliasRupture, nLigneWL)
{
	var nLigne = this._nLigneWLLigne(nLigneWL, this._nGetSelection());
	if (nLigne !== undefined)
	{
		return this._nIndiceRupture(sAliasRupture, nLigne);
	}
	else
	{
		return this.ms_nLigneInvalide
	}
};

// Tri
WDZRNavigateur.prototype.Trie = function Trie(sSensColonnes, bTrie)
{
	if (bTrie)
	{
		this._Tri(sSensColonnes);
	}
	else
	{
		this._TriAnnule();
	}
};

// Recherche
WDZRNavigateur.prototype.Cherche = function Cherche(sAliasColonne, sRecherche, nTypeRecherche, nLigneDebutWL)
{
	var nLigneDebut = this._nLigneWLLigne(nLigneDebutWL, 0, 0);
	return this._nLigneCherche(sAliasColonne, sRecherche, (0 == nTypeRecherche), nLigneDebut);
};

// Enroule une rupture
WDZRNavigateur.prototype.Enroule = function Enroule(nLigneWL, sAliasRupture)
{
	this._EnrouleDeroule(nLigneWL, sAliasRupture, false);
};

// Enroule tout
WDZRNavigateur.prototype.EnrouleTout = function EnrouleTout()
{
	this._EnrouleDerouleTout(false);
};

// Deroule une rupture
WDZRNavigateur.prototype.Deroule = function Deroule(nLigneWL, sAliasRupture)
{
	this._EnrouleDeroule(nLigneWL, sAliasRupture, true);
};

// Deroule tout
WDZRNavigateur.prototype.DerouleTout = function DerouleTout()
{
	this._EnrouleDerouleTout(true);
};

// Inverse l'enroulement
WDZRNavigateur.prototype.EnrouleDeroule = function EnrouleDeroule(nLigneWL, sAliasRupture)
{
	this._EnrouleDeroule(nLigneWL, sAliasRupture);
};

// Acces WL au valeur des colonnes (lecture)
WDZRNavigateur.prototype.oGetValeurColonne = function oGetValeurColonne(sAliasColonne, nLigneWL)
{
	var nLigne = this._nLigneWLLigne(nLigneWL, this._nGetSelection());
	var nColonne = this._nGetColonneSelonAlias(sAliasColonne);
	// Si la ligne et la colonne sont valides
	if ((nColonne !== undefined) && (nLigne !== undefined))
	{
		return this._oGetValeurColonne(nColonne, nLigne);
	}
	else
	{
		return "";
	}
};
// Acces WL au lignes (ecriture)
WDZRNavigateur.prototype.tabGetLigneSet = function tabGetLigneSet(nLigneWL)
{
	var nLigne = this._nLigneWLLigne(nLigneWL, this._nGetSelection());
	// Si la ligne et la colonne sont valides
	if (nLigne !== undefined)
	{
		// Note la MAJ de la ligne (provoque le reaffichage)
		this.__OnLigneModification(nLigne);

		// Note la ligne pour le rafraichissement en fin de PCode
		return this.m_tabLignes[nLigne].tabGetValeurs();
	}
	else
	{
		return [];
	}
};

// Demande l'affichage immediat de la table
WDZRNavigateur.prototype.OnChange = function OnChange()
{
	// Si on n'est pas deja en PCode d'affichage (donc en redessin)
	if (this.m_nPCodeAffichageLigne === undefined)
	{
		this._Affiche();
	}
};

//////////////////////////////////////////////////////////////////////////
// Generateur HTML

// Parse le HTML
WDZRNavigateur.prototype.__HTMLParse = function __HTMLParse()
{
	// m_tabElementsHTML est un tableau d'objets :
	// - Balise fixe :			{ vVersHTML : this.VersHTML_Fixe, m_sValeur : (Valeur chaine) }
	// - Balise dynamique		{ vVersHTML : this.VersHTML_Propriete, m_oPropriete : { <m_nColonne> <, m_ePropriete> <, m_eConversion> }
	//																					^				^				^
	//																			Si sur attribut			^			Si conversion
	//																						Si propriete (sur ZR)
	// - Balise condition		{ vVersHTML : this.VersHTML_Condition, m_sValeur : (Valeur chaine a tester), m_bDifferent : <!= au lieu de ==>, m_tabElementsHTML: <Tableau interne>, m_oPropriete : <Idem balise dynamique> }
	this.m_tabElementsHTML = [];
	var sHTML = clWDUtil.sGetHTMLDansCommentaire(this.m_oHote);

	// Parse le HTML avec le version interne (factorisation avec le code des [%SI%])
	this.__nHTMLParseInterne(sHTML, 0, this.m_tabElementsHTML);
};

// Parse le HTML (version interne :factorisation avec le code des [%SI%])
WDZRNavigateur.prototype.__nHTMLParseInterne = function __nHTMLParseInterne(sHTML, nDebut, tabElementsHTML)
{
	while (1)
	{
		// Trouve le prochain [%
		var nPosition = sHTML.indexOf(this.ms_sDynO, nDebut);
		// Ajoute un bloc fixe si besoin
		nDebut = this.__nHTMLParseFixe(sHTML, nDebut, nPosition, tabElementsHTML)
		// Si on n'a plus de bloc : fini
		if (-1 == nPosition)
		{
			// Ici normalement nDebut == sHTML.length
			return nDebut;
		}
		// Ici normalement nDebut == nPosition
		// Si on a un [%FIN%] => fin du parsing de la condition
		if (sHTML.substr(nPosition, this.ms_sDynFin.length) == this.ms_sDynFin)
		{
			return nPosition + this.ms_sDynFin.length;
		}
		// Si on est sur un [%SI%]
		else if (sHTML.substr(nPosition, this.ms_sDynSi.length) == this.ms_sDynSi)
		{
			// Et parse la condition
			nDebut = this.__nHTMLParseSi(sHTML, nPosition, tabElementsHTML)
		}
		// Parse la valeur
		else
		{
			nDebut = this.__nHTMLParsePropriete(sHTML, nPosition, tabElementsHTML)
		}
	}
};

// - Balise fixe :			{ vVersHTML : this.VersHTML_Fixe, m_sValeur : (Valeur chaine) }
WDZRNavigateur.prototype.__nHTMLParseFixe = function __nHTMLParseFixe(sHTML, nDebut, nPosition, tabElementsHTML)
{
	var sValeur;
	if (-1 != nPosition)
	{
		sValeur = sHTML.substring(nDebut, nPosition);
	}
	else
	{
		sValeur = sHTML.substring(nDebut);
	}
	// Uniquement si on a une valeur
	if (sValeur.length > 0)
	{
		tabElementsHTML.push({ vVersHTML : this.VersHTML_Fixe, m_sValeur : sValeur });
	}
	return nDebut + sValeur.length;
};

// - Balise condition		{ vVersHTML : this.VersHTML_Condition, m_sValeur : (Valeur chaine a tester), m_bDifferent : <!= au lieu de ==>, m_tabElementsHTML: <Tableau interne>, m_oPropriete : <Idem balise dynamique> }
WDZRNavigateur.prototype.__nHTMLParseSi = function __nHTMLParseSi(sHTML, nDebut, tabElementsHTML)
{
	var oElement = { vVersHTML: this.VersHTML_Condition, m_sValeur: "", m_bDifferent: false, m_tabElementsHTML: [], m_oPropriete: null };

	// Ignore le [%SI%]
	nDebut += this.ms_sDynSi.length;
	// Trouve le [%ALORS%]
	var nPositionAlors = sHTML.indexOf(this.ms_sDynAlors, nDebut);
	// Parse la condition
	var sCondition = sHTML.substring(nDebut, nPositionAlors);
	var nPositionCondition = sCondition.indexOf(this.ms_sConditionDifferent);
	var nPositionConditionFin;
	if (-1 == nPositionCondition)
	{
		nPositionCondition = sCondition.indexOf(this.ms_sConditionEgal);
		// Ne sera pas utilise si nPosition est invalide
		nPositionConditionFin = nPositionCondition + this.ms_sConditionEgal.length;
		oElement.m_bDifferent = false;
	}
	else
	{
		nPositionConditionFin = nPositionCondition + this.ms_sConditionDifferent.length;
		oElement.m_bDifferent = true;
	}
	if (-1 != nPositionConditionFin)
	{
		oElement.m_oPropriete = this.__oParsePropriete(sCondition.substring(0, nPositionCondition));
		oElement.m_sValeur = sCondition.substring(nPositionConditionFin, nPositionAlors);

		tabElementsHTML.push(oElement);
	}
	// Et analyse le contenu
	return this.__nHTMLParseInterne(sHTML, nPositionAlors + this.ms_sDynAlors.length, oElement.m_tabElementsHTML);
};

// Parse une propriete [%ALIAS_ZR<;format>%], [%ALIAS_ZR..PROP<;format>%], [%ALIAS_ATTRIBUT<;format>%]
// - Balise dynamique		{ vVersHTML : this.VersHTML_Propriete, m_oPropriete : { <m_nColonne> <, m_ePropriete> <, m_eConversion> }
//																					^				^				^
//																			Si sur attribut			^			Si conversion
//																					Si propriete (sur ZR)
WDZRNavigateur.prototype.__nHTMLParsePropriete = function __nHTMLParsePropriete(sHTML, nDebut, tabElementsHTML)
{
	// Ignore le [%
	nDebut += this.ms_sDynO.length;
	// Trouve le %]
	var nPosition = sHTML.indexOf(this.ms_sDynF, nDebut);
	// Parse la propriete
	tabElementsHTML.push({ vVersHTML : this.VersHTML_Propriete, m_oPropriete : this.__oParsePropriete(sHTML.substring(nDebut, nPosition)) });
	return nPosition + this.ms_sDynF.length;
};

// { <m_nColonne> <, m_ePropriete> <, m_eConversion> }
WDZRNavigateur.prototype.__oParsePropriete = function __oParsePropriete(sPropriete)
{
	var oPropriete = { m_ePropriete: this.XML_CHAMP_PROP_NUM_VALEUR };
	// Extrait la conversion
	// sPropriete est de la forme : ALIAS, ALIAS..PROP, ALIAS..PROP;CONV
	var nPositionConversion = sPropriete.indexOf(this.ms_sConversion);
	if (-1 != nPositionConversion)
	{
		oPropriete.m_eConversion = parseInt(sPropriete.substring(nPositionConversion + this.ms_sConversion.length), 10);
		// Extrait la conversion : pour n'avoir que deux formes : ALIAS, ALIAS..PROP
		sPropriete = sPropriete.substring(0, nPositionConversion);
	}
	// Extrait la propriete
	// sPropriete est de la forme : ALIAS, ALIAS..PROP
	var nPositionPropriete = sPropriete.indexOf(this.ms_sPropriete);
	if (-1 != nPositionPropriete)
	{
		var tabPourParametresOut = [];
		oPropriete.m_ePropriete = this.__eParsePPPropriete(sPropriete.substring(nPositionPropriete + this.ms_sPropriete.length), tabPourParametresOut);
		if (tabPourParametresOut[0] !== undefined)
		{
			oPropriete.m_nParametre = tabPourParametresOut[0];
		}
		// Extrait la propriete : pour n'avoir que une formes : ALIAS
		sPropriete = sPropriete.substring(0, nPositionPropriete);
	}
	// Alias
	// sPropriete est de la forme : ALIAS
	oPropriete.m_nColonne = this._nGetColonneSelonAlias(sPropriete);
	return oPropriete;
};
WDZRNavigateur.prototype.__eParsePPPropriete = function __eParsePPPropriete(sPropriete, tabPourParametresOut)
{
	switch (sPropriete)
	{
	case "COULEURFOND":
		return this.XML_CHAMP_PROP_NUM_COULEURFOND;
	case "RUPTURELIGNE_DEBUT":
		return this.ms_nAttributRuptureLigneDebut;
	case "RUPTURELIGNE_FIN":
		return this.ms_nAttributRuptureLigneFin;
	case "LIGNEREPLIEE":
		return this.ms_nAttributLigneRepliee;
	default:
		if (this.__bParsePPProprieteDouble(sPropriete, tabPourParametresOut, this.ms_sInclureHautRupture))
		{
			return this.ms_nAttributIncludeHautRupture;
		}
		else if (this.__bParsePPProprieteDouble(sPropriete, tabPourParametresOut, this.ms_sInclureBasRupture))
		{
			return this.ms_nAttributIncludeBasRupture;
		}
		// @@@
//		alert(sPropriete);
		return this.XML_CHAMP_PROP_NUM_VALEUR;
	}
};
WDZRNavigateur.prototype.__bParsePPProprieteDouble = function __bParsePPProprieteDouble(sPropriete, tabPourParametresOut, sNomPropriete)
{
	if (sPropriete.substr(0, sNomPropriete.length) == sNomPropriete)
	{
		tabPourParametresOut[0] = parseInt(sPropriete.substr(sNomPropriete.length), 10);
		return true;
	}
	return false;
};

// Genere le HTML
WDZRNavigateur.prototype.__HTMLGenere = function __HTMLGenere(nLigne, oLigne, tabElementsHTML, tabHTML)
{
	var i;
	var nLimiteI = tabElementsHTML.length;
	for (i = 0; i < nLimiteI; i++)
	{
		tabElementsHTML[i].vVersHTML.apply(this, [nLigne, oLigne, tabElementsHTML[i], tabHTML]);
	}
};

// Fonctions specialises pour les sous objets
WDZRNavigateur.prototype.VersHTML_Fixe = function VersHTML_Fixe(nLigne, oLigne, oElement, tabHTML)
{
	tabHTML.push(oElement.m_sValeur);
};
WDZRNavigateur.prototype.VersHTML_Propriete = function VersHTML_Propriete (nLigne, oLigne, oElement, tabHTML)
{
	// Trouve la valeur pour la ligne courante
	tabHTML.push(this.__sGetPropriete(nLigne, oLigne, oElement.m_oPropriete, false));
};
WDZRNavigateur.prototype.VersHTML_Condition = function VersHTML_Condition(nLigne, oLigne, oElement, tabHTML)
{
	var bRes = (oElement.m_sValeur == this.__sGetPropriete(nLigne, oLigne, oElement.m_oPropriete, true));
	if (oElement.m_bDifferent ? !bRes : bRes)
	{
		this.__HTMLGenere(nLigne, oLigne, oElement.m_tabElementsHTML, tabHTML);
	}
};

// Trouve la valeur d'une propriete (factorisation entre VersHTML_Propriete et VersHTML_Condition)
WDZRNavigateur.prototype.__sGetPropriete = function __sGetPropriete(nLigne, oLigne, oPropriete, bPourCondition)
{
	// { <m_nColonne> <, m_ePropriete> <, m_eConversion> }
	var sValeur
	if (oPropriete.m_nColonne !== undefined)
	{
		sValeur = this.__oGetValeurColonne(oPropriete.m_nColonne, oLigne);
	}
	else
	{
		sValeur = this.__sLitPropriete(nLigne, oLigne, oPropriete.m_ePropriete, oPropriete.m_nParametre, bPourCondition);
	}

	return this.__sConversion(sValeur, this.m_eConversion);
};

// Conversion en ecriture
WDZRNavigateur.prototype.__sConversion = function __sConversion(sValeur, eConversion)
{
	if (eConversion !== undefined)
	{
		switch (eConversion)
		{
		// @@@
		default:
		}
	}
	return sValeur;
};
